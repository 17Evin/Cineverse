import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import type { MediaType, MetadataSource } from './src/types/media.ts';
import {
  discoverTitles,
  getCatalogUpdates,
  getFranchises,
  getHomeFeed,
  getRandomTitle,
  getTitleDetail,
  isTmdbConfigured,
  searchAll,
} from './src/server/providers.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = Number(process.env.PORT) || 3000;

  app.use(express.json({ limit: '1mb' }));

  // Health & API provider configuration status (never leaks secrets)
  app.get('/api/status', (_req, res) => {
    res.json({
      ok: true,
      tmdbConfigured: isTmdbConfigured(),
      providers: {
        tmdb: isTmdbConfigured(),
        jikan: true,
        tvmaze: true,
      },
    });
  });

  // Home dashboard aggregated feeds
  app.get('/api/home', async (_req, res) => {
    try {
      const feed = await getHomeFeed();
      res.json(feed);
    } catch (error) {
      console.error('Error building home feed:', error);
      res.status(502).json({ error: 'Unable to reach external entertainment providers right now.' });
    }
  });

  // Global discovery with filters & pagination
  app.get('/api/discover', async (req, res) => {
    try {
      const mediaTypeParam = String(req.query.mediaType || 'all');
      const mediaType = ['all', 'movie', 'tv', 'anime'].includes(mediaTypeParam)
        ? (mediaTypeParam as 'all' | 'movie' | 'tv' | 'anime')
        : 'all';

      const sortParam = String(req.query.sortBy || 'popularity');
      const sortBy = ['popularity', 'rating', 'release_date', 'title'].includes(sortParam)
        ? (sortParam as 'popularity' | 'rating' | 'release_date' | 'title')
        : 'popularity';

      const minRatingRaw = req.query.minRating ? Number(req.query.minRating) : undefined;
      const minRating =
        typeof minRatingRaw === 'number' && !Number.isNaN(minRatingRaw) && minRatingRaw >= 0 && minRatingRaw <= 10
          ? minRatingRaw
          : undefined;

      const data = await discoverTitles({
        mediaType,
        country: req.query.country ? String(req.query.country).slice(0, 4) : undefined,
        language: req.query.language ? String(req.query.language).slice(0, 10) : undefined,
        genre: req.query.genre ? String(req.query.genre).slice(0, 40) : undefined,
        year: req.query.year ? String(req.query.year).slice(0, 4) : undefined,
        minRating,
        status: req.query.status ? String(req.query.status).slice(0, 20) : undefined,
        provider: req.query.provider ? String(req.query.provider).slice(0, 20) : undefined,
        region: req.query.region ? String(req.query.region).slice(0, 4) : 'IN',
        sortBy,
        page: req.query.page ? Number(req.query.page) : 1,
      });

      res.json(data);
    } catch (error) {
      console.error('Error in /api/discover:', error);
      res.status(502).json({ error: 'Failed to load discovery catalog.' });
    }
  });

  // Universal Search
  app.get('/api/search', async (req, res) => {
    try {
      const q = String(req.query.q || '').trim().slice(0, 120);
      const data = await searchAll(q);
      res.json(data);
    } catch (error) {
      console.error('Error in /api/search:', error);
      res.status(502).json({ error: 'Search providers are temporarily unavailable.' });
    }
  });

  // Title Detail + Seasons + Episodes + Regional Streaming Availability
  app.get('/api/title/:source/:mediaType/:externalId', async (req, res) => {
    try {
      const source = req.params.source as MetadataSource;
      const mediaType = req.params.mediaType as MediaType;
      const externalId = String(req.params.externalId || '').replace(/[^a-zA-Z0-9_-]/g, '');
      const region = String(req.query.region || 'IN')
        .toUpperCase()
        .replace(/[^A-Z]/g, '')
        .slice(0, 4) || 'IN';

      if (!['tmdb', 'jikan', 'tvmaze'].includes(source) || !['movie', 'tv', 'anime'].includes(mediaType) || !externalId) {
        return res.status(400).json({ error: 'Invalid title identifier.' });
      }

      const detail = await getTitleDetail(source, mediaType, externalId, region);
      if (!detail) {
        return res.status(404).json({ error: 'Title metadata is currently unavailable from the provider.' });
      }

      res.json(detail);
    } catch (error) {
      console.error('Error in /api/title:', error);
      res.status(502).json({ error: 'Failed to retrieve title metadata.' });
    }
  });

  // Franchises & Viewing Orders
  app.get('/api/franchises', async (req, res) => {
    try {
      const id = req.query.id ? String(req.query.id).slice(0, 80) : undefined;
      const region = String(req.query.region || 'IN')
        .toUpperCase()
        .replace(/[^A-Z]/g, '')
        .slice(0, 4) || 'IN';
      const franchises = await getFranchises(id, region);
      res.json({ franchises });
    } catch (error) {
      console.error('Error in /api/franchises:', error);
      res.status(502).json({ error: 'Failed to load franchise data.' });
    }
  });

  app.get('/api/franchises/:id', async (req, res) => {
    try {
      const id = String(req.params.id || '').slice(0, 80);
      const region = String(req.query.region || 'IN')
        .toUpperCase()
        .replace(/[^A-Z]/g, '')
        .slice(0, 4) || 'IN';
      const list = await getFranchises(id, region);
      if (list.length === 0) {
        return res.status(404).json({ error: 'Franchise guide not found.' });
      }
      res.json({ franchise: list[0] });
    } catch (error) {
      console.error('Error in /api/franchises/:id:', error);
      res.status(502).json({ error: 'Failed to load franchise guide.' });
    }
  });

  // Live Catalog Updates (New Movies, Series, Dramas, Anime) & Franchise Detection
  app.get('/api/updates', async (req, res) => {
    try {
      const region = String(req.query.region || 'IN')
        .toUpperCase()
        .replace(/[^A-Z]/g, '')
        .slice(0, 4) || 'IN';
      const forceRefresh = req.query.refresh === '1' || req.query.refresh === 'true';
      const data = await getCatalogUpdates({ region, forceRefresh });
      res.json(data);
    } catch (error) {
      console.error('Error in /api/updates:', error);
      res.status(502).json({ error: 'Unable to fetch live catalog updates right now.' });
    }
  });

  app.post('/api/updates/refresh', async (req, res) => {
    try {
      const region = String(req.query.region || req.body?.region || 'IN')
        .toUpperCase()
        .replace(/[^A-Z]/g, '')
        .slice(0, 4) || 'IN';
      const data = await getCatalogUpdates({ region, forceRefresh: true });
      res.json(data);
    } catch (error) {
      console.error('Error in POST /api/updates/refresh:', error);
      res.status(502).json({ error: 'Unable to refresh live catalog updates right now.' });
    }
  });

  // Random discovery endpoint
  app.get('/api/random', async (req, res) => {
    try {
      const exclude = req.query.exclude
        ? String(req.query.exclude)
            .split(',')
            .map((s) => s.trim())
            .filter(Boolean)
            .slice(0, 200)
        : [];
      const item = await getRandomTitle(exclude);
      if (!item) {
        return res.status(404).json({ error: 'No titles available for random discovery right now.' });
      }
      res.json(item);
    } catch (error) {
      console.error('Error in /api/random:', error);
      res.status(502).json({ error: 'Unable to fetch a random title.' });
    }
  });

  // Vite middleware for development; static dist serving for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CINÉVERSE server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
