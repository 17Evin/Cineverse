# CINÉVERSE Security Specification (Phase 0 — Payload-First TDD)

## 1. Data Invariants
1. **Strict Ownership Isolation**: Every user document (`users/{userId}`) and subcollection document (`library`, `episodeProgress`, `collections`) is strictly readable and writable ONLY by the verified user whose `request.auth.uid == userId` and `request.auth.token.email_verified == true`.
2. **No Duplicate Tracking**: `library/{titleKey}` and `episodeProgress/{episodeKey}` enforce `incoming().titleKey == titleKey` and `incoming().episodeKey == episodeKey`, preventing duplicate status/episode records.
3. **Immutable Ownership & Timestamps**: `uid`, `userId`, `id`, `franchiseId`, and `createdAt` can never be mutated on update; `createdAt`, `updatedAt`, and `watchedAt` must strictly equal `request.time`.
4. **Master Gate Relational Sync**: All subcollection creates require the parent document to exist (`exists()` for user subcollections, `existsAfter()` for batched franchise subcollection writes).
5. **Admin-Only Franchise Curation**: Writes (`create`, `update`, `delete`) to `/franchises/{franchiseId}`, `/franchises/{franchiseId}/entries/{entryId}`, and `/franchises/{franchiseId}/watchOrders/{orderEntryId}` require verified admin privileges (`email_verified == true` and either the bootstrapped admin email or `/admins/{uid}` document).
6. **Secure Published Franchise List Queries**: `allow list` on `/franchises` and its subcollections evaluates `resource.data.isPublished == true || isBootstrappedAdmin()` with zero `get()`/`exists()` calls inside `allow list`.
7. **Bounded Strings & Arrays**: Every string enforces `.size() <= MAX` and every array enforces `.size() <= MAX` with element type checks to prevent Denial-of-Wallet attacks.
8. **Zero Shadow Fields**: All writes enforce `keys().hasAll(...) && keys().hasOnly(...)` on create and `affectedKeys().hasOnly(...)` on update.

## 2. The Dirty Dozen Adversarial Payloads
1. **Cross-Tenant Profile Read**: User B attempts `get` on `/users/userA`. Must fail (`PERMISSION_DENIED`).
2. **Cross-Tenant Library List**: User B attempts `list` on `/users/userA/library`. Must fail (`PERMISSION_DENIED`).
3. **Identity Spoofing on Create**: User A writes `/users/userA/library/jikan_anime_1` with `userId: "userB"`. Must fail.
4. **Shadow Field Injection (Ghost Field)**: User A adds `isAdmin: true` to `/users/userA` or admin adds `ghostField: true` to `/franchises/mcu`. Must fail (`hasOnly`).
5. **Unverified Email Admin Spoof**: Attacker signs in with matching admin email but `email_verified: false` and attempts to write `/franchises/mcu`. Must fail.
6. **Non-Admin Franchise Tampering**: Regular verified user attempts to create/update/delete `/franchises/mcu` or `/franchises/mcu/watchOrders/rec_1`. Must fail.
7. **Unpublished Franchise Scraping**: Non-admin user attempts `get` or `list` on an unpublished draft franchise (`isPublished: false`). Must fail.
8. **Self-Assigned Admin Escalation**: Regular user attempts to write `/admins/{theirUid}`. Must fail (`allow write: if false`).
9. **Backdated Timestamp Forgery**: User or admin creates a record with `createdAt` / `watchedAt` set to a client timestamp instead of `request.time`. Must fail.
10. **ID Poisoning Attack**: Attacker attempts to create `/franchises/../../../evil$id` or a 200-char ID. Must fail (`isValidSlug` / `isValidId`).
11. **Resource Exhaustion / Array Flood**: Admin or user submits 50 `searchAliases` (> 30 max) or 5000-char `notes` (> 2000 max). Must fail.
12. **Orphaned Franchise Entry Write**: Admin attempts to create `/franchises/nonexistent/entries/tmdb_movie_1` when parent `/franchises/nonexistent` does not exist. Must fail (`existsAfter`).
