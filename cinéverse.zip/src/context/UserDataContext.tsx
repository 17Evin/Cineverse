import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { auth, db, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import type {
  EpisodeItem,
  MediaDetail,
  MediaSummary,
  SeasonGroup,
  UserCollectionRecord,
  UserEpisodeRecord,
  UserProfile,
  UserTitleRecord,
  WatchStatus,
} from '../types/media';

export interface ToastMessage {
  id: string;
  text: string;
  tone: 'default' | 'success' | 'error';
}

interface UserDataContextValue {
  user: User | null;
  authReady: boolean;
  profile: UserProfile | null;
  preferredRegion: string;
  setGuestRegion: (region: string) => void;
  library: Record<string, UserTitleRecord>;
  libraryList: UserTitleRecord[];
  episodeProgress: Record<string, UserEpisodeRecord>;
  episodeList: UserEpisodeRecord[];
  collections: UserCollectionRecord[];
  toasts: ToastMessage[];
  notify: (text: string, tone?: ToastMessage['tone']) => void;
  dismissToast: (id: string) => void;
  signInWithGoogle: () => Promise<void>;
  signOutUser: () => Promise<void>;
  upsertTitleStatus: (
    media: MediaSummary | MediaDetail,
    updates: Partial<{
      status: WatchStatus;
      isFavorite: boolean;
      personalRating: number;
      notes: string;
      startedAt: string;
      completedAt: string;
    }>
  ) => Promise<void>;
  removeTitleFromLibrary: (titleKey: string) => Promise<void>;
  toggleEpisodeWatched: (detail: MediaDetail, episode: EpisodeItem) => Promise<void>;
  markSeasonWatched: (detail: MediaDetail, season: SeasonGroup, markCompleted: boolean) => Promise<void>;
  createCollection: (name: string, description: string) => Promise<string | null>;
  updateCollection: (
    collectionId: string,
    updates: Partial<{ name: string; description: string; titleKeys: string[] }>
  ) => Promise<void>;
  deleteCollection: (collectionId: string) => Promise<void>;
  toggleTitleInCollection: (collectionId: string, titleKey: string) => Promise<void>;
  updateProfilePreferences: (
    updates: Partial<{
      displayName: string;
      preferredRegion: string;
      preferredLanguage: string;
      favoriteGenres: string[];
      preferredCountries: string[];
      excludeCompletedRecs: boolean;
    }>
  ) => Promise<void>;
}

const UserDataContext = createContext<UserDataContextValue | null>(null);

function sanitizeString(val: string | null | undefined, maxLen: number): string {
  return String(val ?? '').trim().slice(0, maxLen);
}

function clampNumber(val: number | null | undefined, min: number, max: number): number {
  const n = Number(val ?? 0);
  if (Number.isNaN(n)) return min;
  return Math.max(min, Math.min(max, n));
}

function formatEpisodeCode(ep: EpisodeItem): string {
  if (ep.isSpecial) return `SP${ep.episodeNumber}`;
  return `S${String(ep.seasonNumber).padStart(2, '0')}E${String(ep.episodeNumber).padStart(2, '0')}`;
}

function todayIsoDate(): string {
  return new Date().toISOString().slice(0, 10);
}

function currentMonthKey(): string {
  return new Date().toISOString().slice(0, 7);
}

export function UserDataProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [guestRegion, setGuestRegionState] = useState<string>(() => {
    try {
      return localStorage.getItem('cineverse_region') || 'IN';
    } catch {
      return 'IN';
    }
  });
  const [library, setLibrary] = useState<Record<string, UserTitleRecord>>({});
  const [episodeProgress, setEpisodeProgress] = useState<Record<string, UserEpisodeRecord>>({});
  const [collections, setCollections] = useState<UserCollectionRecord[]>([]);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const notify = useCallback((text: string, tone: ToastMessage['tone'] = 'default') => {
    const id = `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    setToasts((prev) => [...prev.slice(-3), { id, text, tone }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3600);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const setGuestRegion = useCallback((region: string) => {
    const clean = region.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 4) || 'IN';
    setGuestRegionState(clean);
    try {
      localStorage.setItem('cineverse_region', clean);
    } catch {
      // ignore storage failure
    }
  }, []);

  // Auth listener
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
      setAuthReady(true);
      if (!firebaseUser) {
        setProfile(null);
        setLibrary({});
        setEpisodeProgress({});
        setCollections([]);
      }
    });
    return unsub;
  }, []);

  // Ensure profile doc exists & subscribe to user's private collections
  useEffect(() => {
    if (!authReady || !user) return;

    let cancelled = false;
    let unsubProfile: (() => void) | undefined;
    let unsubLibrary: (() => void) | undefined;
    let unsubEpisodes: (() => void) | undefined;
    let unsubCollections: (() => void) | undefined;

    const uid = user.uid;
    const profileRef = doc(db, 'users', uid);

    async function bootstrapUser() {
      try {
        const snap = await getDoc(profileRef);
        if (!snap.exists()) {
          const initialProfile = {
            uid,
            displayName: sanitizeString(user?.displayName || user?.email?.split('@')[0] || 'Cinephile', 100) || 'Cinephile',
            preferredRegion: guestRegion || 'IN',
            preferredLanguage: 'en',
            favoriteGenres: [] as string[],
            preferredCountries: ['IN', 'KR', 'JP'] as string[],
            excludeCompletedRecs: true,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          };
          await setDoc(profileRef, initialProfile);
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${uid}`);
      }

      if (cancelled) return;

      unsubProfile = onSnapshot(
        profileRef,
        (snap) => {
          if (snap.exists()) {
            setProfile(snap.data() as UserProfile);
          }
        },
        (err) => handleFirestoreError(err, OperationType.GET, `users/${uid}`)
      );

      const libQuery = query(collection(db, 'users', uid, 'library'), where('userId', '==', uid));
      unsubLibrary = onSnapshot(
        libQuery,
        (snap) => {
          const next: Record<string, UserTitleRecord> = {};
          snap.forEach((d) => {
            const data = d.data() as UserTitleRecord;
            next[data.titleKey] = data;
          });
          setLibrary(next);
        },
        (err) => handleFirestoreError(err, OperationType.LIST, `users/${uid}/library`)
      );

      const epQuery = query(collection(db, 'users', uid, 'episodeProgress'), where('userId', '==', uid));
      unsubEpisodes = onSnapshot(
        epQuery,
        (snap) => {
          const next: Record<string, UserEpisodeRecord> = {};
          snap.forEach((d) => {
            const data = d.data() as UserEpisodeRecord;
            next[data.episodeKey] = data;
          });
          setEpisodeProgress(next);
        },
        (err) => handleFirestoreError(err, OperationType.LIST, `users/${uid}/episodeProgress`)
      );

      const colQuery = query(collection(db, 'users', uid, 'collections'), where('userId', '==', uid));
      unsubCollections = onSnapshot(
        colQuery,
        (snap) => {
          const next: UserCollectionRecord[] = [];
          snap.forEach((d) => {
            next.push({ id: d.id, ...(d.data() as Omit<UserCollectionRecord, 'id'>) });
          });
          setCollections(next);
        },
        (err) => handleFirestoreError(err, OperationType.LIST, `users/${uid}/collections`)
      );
    }

    bootstrapUser();

    return () => {
      cancelled = true;
      unsubProfile?.();
      unsubLibrary?.();
      unsubEpisodes?.();
      unsubCollections?.();
    };
  }, [authReady, user, guestRegion]);

  const signInWithGoogle = useCallback(async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      notify('Signed in to CINÉVERSE', 'success');
    } catch (err: any) {
      if (err?.code === 'auth/popup-closed-by-user') return;
      notify(err?.message || 'Unable to sign in right now.', 'error');
    }
  }, [notify]);

  const signOutUser = useCallback(async () => {
    try {
      await signOut(auth);
      notify('Signed out', 'default');
    } catch {
      notify('Could not sign out.', 'error');
    }
  }, [notify]);

  const ensureAuthenticated = useCallback((): User | null => {
    if (!user) {
      notify('Sign in with Google to save watchlist items and episode progress.', 'default');
      return null;
    }
    return user;
  }, [user, notify]);

  const upsertTitleStatus = useCallback(
    async (
      media: MediaSummary | MediaDetail,
      updates: Partial<{
        status: WatchStatus;
        isFavorite: boolean;
        personalRating: number;
        notes: string;
        startedAt: string;
        completedAt: string;
      }>
    ) => {
      const activeUser = ensureAuthenticated();
      if (!activeUser) return;

      const uid = activeUser.uid;
      const titleKey = media.titleKey;
      const docRef = doc(db, 'users', uid, 'library', titleKey);
      const existing = library[titleKey];

      const totalReleasedFromDetail =
        'seasons' in media && Array.isArray(media.seasons)
          ? media.seasons
              .filter((s) => !s.isSpecials)
              .reduce((acc, s) => acc + s.releasedEpisodeCount, 0)
          : media.totalEpisodes || 0;

      const completedCountForTitle = Object.values(episodeProgress).filter(
        (ep) => ep.titleKey === titleKey && !ep.isSpecial
      ).length;

      try {
        if (!existing) {
          const status: WatchStatus = updates.status || 'want_to_watch';
          const payload = {
            userId: uid,
            titleKey,
            source: media.source,
            mediaType: media.mediaType,
            externalId: sanitizeString(media.externalId, 64),
            title: sanitizeString(media.title, 200) || 'Untitled',
            originalTitle: sanitizeString(media.originalTitle, 200),
            posterUrl: sanitizeString(media.posterUrl || '', 500),
            releaseYear: clampNumber(media.releaseYear || 0, 0, 2100),
            country: sanitizeString(media.country || 'Unknown', 64),
            language: sanitizeString(media.language || 'Unknown', 32),
            genres: (media.genres || []).slice(0, 10).map((g) => sanitizeString(g, 40)),
            runtimeMinutes: clampNumber(media.runtimeMinutes || 0, 0, 10000),
            totalReleasedEpisodes: clampNumber(totalReleasedFromDetail, 0, 5000),
            completedEpisodesCount: clampNumber(completedCountForTitle, 0, 5000),
            status,
            isFavorite: Boolean(updates.isFavorite ?? false),
            personalRating: clampNumber(updates.personalRating ?? 0, 0, 10),
            notes: sanitizeString(updates.notes ?? '', 2000),
            startedAt: sanitizeString(
              updates.startedAt ?? (status === 'watching' || status === 'completed' ? todayIsoDate() : ''),
              32
            ),
            completedAt: sanitizeString(
              updates.completedAt ?? (status === 'completed' ? todayIsoDate() : ''),
              32
            ),
            lastWatchedEpisodeCode: '',
            lastWatchedEpisodeName: '',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          };
          await setDoc(docRef, payload);
          notify(`Added "${media.title}" to your library`, 'success');
        } else {
          const nextStatus = updates.status ?? existing.status;
          const patch: Record<string, unknown> = {
            status: nextStatus,
            isFavorite: updates.isFavorite ?? existing.isFavorite,
            personalRating: clampNumber(updates.personalRating ?? existing.personalRating, 0, 10),
            notes: sanitizeString(updates.notes ?? existing.notes, 2000),
            startedAt: sanitizeString(
              updates.startedAt !== undefined
                ? updates.startedAt
                : !existing.startedAt && (nextStatus === 'watching' || nextStatus === 'completed')
                  ? todayIsoDate()
                  : existing.startedAt,
              32
            ),
            completedAt: sanitizeString(
              updates.completedAt !== undefined
                ? updates.completedAt
                : nextStatus === 'completed' && !existing.completedAt
                  ? todayIsoDate()
                  : nextStatus !== 'completed' && updates.status !== undefined
                    ? ''
                    : existing.completedAt,
              32
            ),
            totalReleasedEpisodes: clampNumber(
              totalReleasedFromDetail > 0 ? totalReleasedFromDetail : existing.totalReleasedEpisodes,
              0,
              5000
            ),
            posterUrl: sanitizeString(media.posterUrl || existing.posterUrl, 500),
            runtimeMinutes: clampNumber(media.runtimeMinutes || existing.runtimeMinutes, 0, 10000),
            updatedAt: serverTimestamp(),
          };
          await updateDoc(docRef, patch);
          notify(`Updated "${media.title}"`, 'success');
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${uid}/library/${titleKey}`);
      }
    },
    [ensureAuthenticated, library, episodeProgress, notify]
  );

  const removeTitleFromLibrary = useCallback(
    async (titleKey: string) => {
      const activeUser = ensureAuthenticated();
      if (!activeUser) return;
      const uid = activeUser.uid;
      try {
        await deleteDoc(doc(db, 'users', uid, 'library', titleKey));
        notify('Removed from library', 'default');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `users/${uid}/library/${titleKey}`);
      }
    },
    [ensureAuthenticated, notify]
  );

  const syncTitleEpisodeSummary = useCallback(
    async (
      uid: string,
      detail: MediaDetail,
      nextWatchedMap: Record<string, boolean>,
      lastToggledEp?: EpisodeItem
    ) => {
      const nonSpecialReleased = detail.seasons
        .filter((s) => !s.isSpecials)
        .flatMap((s) => s.episodes)
        .filter((e) => e.isReleased);

      const completedRegularCount = nonSpecialReleased.filter((e) => nextWatchedMap[e.episodeKey]).length;
      const totalReleased = nonSpecialReleased.length;
      const existing = library[detail.titleKey];

      let nextStatus: WatchStatus = existing?.status || 'watching';
      if (completedRegularCount > 0 && totalReleased > 0 && completedRegularCount >= totalReleased) {
        nextStatus = 'completed';
      } else if (completedRegularCount > 0 && (nextStatus === 'want_to_watch' || nextStatus === 'completed')) {
        nextStatus = 'watching';
      }

      const libRef = doc(db, 'users', uid, 'library', detail.titleKey);
      const lastCode = lastToggledEp ? formatEpisodeCode(lastToggledEp) : existing?.lastWatchedEpisodeCode || '';
      const lastName = lastToggledEp ? sanitizeString(lastToggledEp.name, 200) : existing?.lastWatchedEpisodeName || '';

      if (!existing) {
        await setDoc(libRef, {
          userId: uid,
          titleKey: detail.titleKey,
          source: detail.source,
          mediaType: detail.mediaType,
          externalId: sanitizeString(detail.externalId, 64),
          title: sanitizeString(detail.title, 200) || 'Untitled',
          originalTitle: sanitizeString(detail.originalTitle, 200),
          posterUrl: sanitizeString(detail.posterUrl || '', 500),
          releaseYear: clampNumber(detail.releaseYear || 0, 0, 2100),
          country: sanitizeString(detail.country || 'Unknown', 64),
          language: sanitizeString(detail.language || 'Unknown', 32),
          genres: (detail.genres || []).slice(0, 10).map((g) => sanitizeString(g, 40)),
          runtimeMinutes: clampNumber(detail.runtimeMinutes || 0, 0, 10000),
          totalReleasedEpisodes: clampNumber(totalReleased, 0, 5000),
          completedEpisodesCount: clampNumber(completedRegularCount, 0, 5000),
          status: nextStatus,
          isFavorite: false,
          personalRating: 0,
          notes: '',
          startedAt: todayIsoDate(),
          completedAt: nextStatus === 'completed' ? todayIsoDate() : '',
          lastWatchedEpisodeCode: sanitizeString(lastCode, 32),
          lastWatchedEpisodeName: lastName,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } else {
        await updateDoc(libRef, {
          status: nextStatus,
          totalReleasedEpisodes: clampNumber(totalReleased, 0, 5000),
          completedEpisodesCount: clampNumber(completedRegularCount, 0, 5000),
          startedAt: existing.startedAt || todayIsoDate(),
          completedAt: nextStatus === 'completed' ? existing.completedAt || todayIsoDate() : '',
          lastWatchedEpisodeCode: sanitizeString(lastCode, 32),
          lastWatchedEpisodeName: lastName,
          updatedAt: serverTimestamp(),
        });
      }
    },
    [library]
  );

  const toggleEpisodeWatched = useCallback(
    async (detail: MediaDetail, episode: EpisodeItem) => {
      const activeUser = ensureAuthenticated();
      if (!activeUser) return;

      if (!episode.isReleased) {
        notify('Unreleased episodes cannot be marked as watched yet.', 'error');
        return;
      }

      const uid = activeUser.uid;
      const epRef = doc(db, 'users', uid, 'episodeProgress', episode.episodeKey);
      const isCurrentlyWatched = Boolean(episodeProgress[episode.episodeKey]);

      const nextWatchedMap: Record<string, boolean> = {};
      for (const key of Object.keys(episodeProgress)) {
        if (episodeProgress[key].titleKey === detail.titleKey) {
          nextWatchedMap[key] = true;
        }
      }

      try {
        if (isCurrentlyWatched) {
          await deleteDoc(epRef);
          delete nextWatchedMap[episode.episodeKey];
          await syncTitleEpisodeSummary(uid, detail, nextWatchedMap);
          notify(`Unmarked ${formatEpisodeCode(episode)}`, 'default');
        } else {
          const now = new Date();
          await setDoc(epRef, {
            userId: uid,
            titleKey: detail.titleKey,
            episodeKey: episode.episodeKey,
            seasonNumber: clampNumber(episode.seasonNumber, 0, 200),
            episodeNumber: clampNumber(episode.episodeNumber, 0, 5000),
            isSpecial: Boolean(episode.isSpecial),
            episodeTitle: sanitizeString(episode.name, 200),
            runtimeMinutes: clampNumber(episode.runtimeMinutes || detail.runtimeMinutes || 0, 0, 600),
            watchedAt: serverTimestamp(),
            watchedMonth: currentMonthKey(),
            watchedYear: now.getFullYear(),
          });
          nextWatchedMap[episode.episodeKey] = true;
          await syncTitleEpisodeSummary(uid, detail, nextWatchedMap, episode);
          notify(`Marked ${formatEpisodeCode(episode)} watched`, 'success');
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${uid}/episodeProgress/${episode.episodeKey}`);
      }
    },
    [ensureAuthenticated, episodeProgress, syncTitleEpisodeSummary, notify]
  );

  const markSeasonWatched = useCallback(
    async (detail: MediaDetail, season: SeasonGroup, markCompleted: boolean) => {
      const activeUser = ensureAuthenticated();
      if (!activeUser) return;

      const releasedEps = season.episodes.filter((e) => e.isReleased);
      if (releasedEps.length === 0) {
        notify('No released episodes in this season yet.', 'default');
        return;
      }

      const uid = activeUser.uid;
      const nextWatchedMap: Record<string, boolean> = {};
      for (const key of Object.keys(episodeProgress)) {
        if (episodeProgress[key].titleKey === detail.titleKey) {
          nextWatchedMap[key] = true;
        }
      }

      try {
        // Chunk writes in batches of 400 (Firestore max 500)
        const now = new Date();
        const month = currentMonthKey();
        const year = now.getFullYear();

        for (let i = 0; i < releasedEps.length; i += 400) {
          const chunk = releasedEps.slice(i, i + 400);
          const batch = writeBatch(db);
          for (const ep of chunk) {
            const epRef = doc(db, 'users', uid, 'episodeProgress', ep.episodeKey);
            if (markCompleted) {
              if (!episodeProgress[ep.episodeKey]) {
                batch.set(epRef, {
                  userId: uid,
                  titleKey: detail.titleKey,
                  episodeKey: ep.episodeKey,
                  seasonNumber: clampNumber(ep.seasonNumber, 0, 200),
                  episodeNumber: clampNumber(ep.episodeNumber, 0, 5000),
                  isSpecial: Boolean(ep.isSpecial),
                  episodeTitle: sanitizeString(ep.name, 200),
                  runtimeMinutes: clampNumber(ep.runtimeMinutes || detail.runtimeMinutes || 0, 0, 600),
                  watchedAt: serverTimestamp(),
                  watchedMonth: month,
                  watchedYear: year,
                });
              }
              nextWatchedMap[ep.episodeKey] = true;
            } else {
              if (episodeProgress[ep.episodeKey]) {
                batch.delete(epRef);
              }
              delete nextWatchedMap[ep.episodeKey];
            }
          }
          await batch.commit();
        }

        const lastEp = markCompleted ? releasedEps[releasedEps.length - 1] : undefined;
        await syncTitleEpisodeSummary(uid, detail, nextWatchedMap, lastEp);
        notify(
          markCompleted
            ? `Marked ${releasedEps.length} released episodes in ${season.name} watched`
            : `Cleared ${season.name} progress`,
          'success'
        );
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `users/${uid}/episodeProgress`);
      }
    },
    [ensureAuthenticated, episodeProgress, syncTitleEpisodeSummary, notify]
  );

  const createCollection = useCallback(
    async (name: string, description: string): Promise<string | null> => {
      const activeUser = ensureAuthenticated();
      if (!activeUser) return null;
      const cleanName = sanitizeString(name, 100);
      if (!cleanName) {
        notify('Please enter a collection name.', 'error');
        return null;
      }

      const uid = activeUser.uid;
      const colId = `col_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      const colRef = doc(db, 'users', uid, 'collections', colId);
      try {
        await setDoc(colRef, {
          userId: uid,
          name: cleanName,
          description: sanitizeString(description, 500),
          titleKeys: [],
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        notify(`Created collection "${cleanName}"`, 'success');
        return colId;
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `users/${uid}/collections/${colId}`);
      }
    },
    [ensureAuthenticated, notify]
  );

  const updateCollection = useCallback(
    async (
      collectionId: string,
      updates: Partial<{ name: string; description: string; titleKeys: string[] }>
    ) => {
      const activeUser = ensureAuthenticated();
      if (!activeUser) return;
      const uid = activeUser.uid;
      const existing = collections.find((c) => c.id === collectionId);
      if (!existing) return;

      const colRef = doc(db, 'users', uid, 'collections', collectionId);
      try {
        await updateDoc(colRef, {
          name: sanitizeString(updates.name ?? existing.name, 100) || existing.name,
          description: sanitizeString(updates.description ?? existing.description, 500),
          titleKeys: (updates.titleKeys ?? existing.titleKeys).slice(0, 100),
          updatedAt: serverTimestamp(),
        });
        notify('Collection updated', 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${uid}/collections/${collectionId}`);
      }
    },
    [ensureAuthenticated, collections, notify]
  );

  const deleteCollection = useCallback(
    async (collectionId: string) => {
      const activeUser = ensureAuthenticated();
      if (!activeUser) return;
      const uid = activeUser.uid;
      try {
        await deleteDoc(doc(db, 'users', uid, 'collections', collectionId));
        notify('Collection deleted', 'default');
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `users/${uid}/collections/${collectionId}`);
      }
    },
    [ensureAuthenticated, notify]
  );

  const toggleTitleInCollection = useCallback(
    async (collectionId: string, titleKey: string) => {
      const col = collections.find((c) => c.id === collectionId);
      if (!col) return;
      const exists = col.titleKeys.includes(titleKey);
      const nextKeys = exists
        ? col.titleKeys.filter((k) => k !== titleKey)
        : [...col.titleKeys, titleKey].slice(0, 100);
      await updateCollection(collectionId, { titleKeys: nextKeys });
    },
    [collections, updateCollection]
  );

  const updateProfilePreferences = useCallback(
    async (
      updates: Partial<{
        displayName: string;
        preferredRegion: string;
        preferredLanguage: string;
        favoriteGenres: string[];
        preferredCountries: string[];
        excludeCompletedRecs: boolean;
      }>
    ) => {
      const activeUser = ensureAuthenticated();
      if (!activeUser || !profile) return;
      const uid = activeUser.uid;
      const profileRef = doc(db, 'users', uid);

      const nextRegion = (updates.preferredRegion ?? profile.preferredRegion)
        .toUpperCase()
        .replace(/[^A-Z]/g, '')
        .slice(0, 4) || 'IN';

      try {
        await updateDoc(profileRef, {
          displayName: sanitizeString(updates.displayName ?? profile.displayName, 100) || profile.displayName,
          preferredRegion: nextRegion,
          preferredLanguage: sanitizeString(updates.preferredLanguage ?? profile.preferredLanguage, 10) || 'en',
          favoriteGenres: (updates.favoriteGenres ?? profile.favoriteGenres).slice(0, 12),
          preferredCountries: (updates.preferredCountries ?? profile.preferredCountries).slice(0, 12),
          excludeCompletedRecs: updates.excludeCompletedRecs ?? profile.excludeCompletedRecs,
          updatedAt: serverTimestamp(),
        });
        setGuestRegion(nextRegion);
        notify('Preferences saved', 'success');
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `users/${uid}`);
      }
    },
    [ensureAuthenticated, profile, setGuestRegion, notify]
  );

  const preferredRegion = profile?.preferredRegion || guestRegion || 'IN';
  const libraryList = useMemo(() => Object.values(library), [library]);
  const episodeList = useMemo(() => Object.values(episodeProgress), [episodeProgress]);

  const value: UserDataContextValue = {
    user,
    authReady,
    profile,
    preferredRegion,
    setGuestRegion,
    library,
    libraryList,
    episodeProgress,
    episodeList,
    collections,
    toasts,
    notify,
    dismissToast,
    signInWithGoogle,
    signOutUser,
    upsertTitleStatus,
    removeTitleFromLibrary,
    toggleEpisodeWatched,
    markSeasonWatched,
    createCollection,
    updateCollection,
    deleteCollection,
    toggleTitleInCollection,
    updateProfilePreferences,
  };

  return <UserDataContext.Provider value={value}>{children}</UserDataContext.Provider>;
}

export function useUserData(): UserDataContextValue {
  const ctx = useContext(UserDataContext);
  if (!ctx) {
    throw new Error('useUserData must be used inside UserDataProvider');
  }
  return ctx;
}
