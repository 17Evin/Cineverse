import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowRight, Layers, User } from 'lucide-react';
import type { FranchiseSearchMatch, SearchResponse } from '../types/media';
import { getFranchiseRoute, searchAllApi } from '../services/api';
import { fetchFirestoreFranchises, matchCustomFranchisesClient } from '../lib/franchiseStore';
import { TitleCard, TitleCardSkeleton } from '../components/TitleCard';
import { PosterImage } from '../components/PosterImage';

export function SearchPage() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const [data, setData] = useState<SearchResponse | null>(null);
  const [customMatches, setCustomMatches] = useState<FranchiseSearchMatch[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [retryTick, setRetryTick] = useState(0);

  useEffect(() => {
    if (!query.trim()) {
      setData(null);
      setCustomMatches([]);
      setLoading(false);
      setError(null);
      return;
    }
    const controller = new AbortController();
    let active = true;
    setLoading(true);
    setError(null);

    Promise.all([
      searchAllApi(query, controller.signal),
      fetchFirestoreFranchises({ includeDrafts: false }).catch(() => []),
    ])
      .then(([res, customFranchises]) => {
        if (active) {
          setData(res);
          setCustomMatches(matchCustomFranchisesClient(query, customFranchises));
          setLoading(false);
        }
      })
      .catch((err: any) => {
        if (err?.name === 'AbortError') return;
        if (active) {
          setError(err?.message || 'Search failed. Please try again.');
          setLoading(false);
        }
      });
    return () => {
      active = false;
      controller.abort();
    };
  }, [query, retryTick]);

  const mergedFranchiseMatches = useMemo(() => {
    const map = new Map<string, FranchiseSearchMatch>();
    for (const m of data?.franchiseMatches || []) map.set(m.id, m);
    for (const m of customMatches) {
      const existing = map.get(m.id);
      map.set(m.id, { ...m, posterUrl: m.posterUrl || existing?.posterUrl || null });
    }
    return Array.from(map.values());
  }, [data?.franchiseMatches, customMatches]);

  return (
    <div className="space-y-8">
      <div className="pb-4 border-b border-white/[0.06]">
        <p className="text-xs uppercase tracking-[0.16em] text-[#D6B477] mb-1">Universal Search</p>
        <h1 className="font-serif text-3xl font-semibold text-[#F5F3FA]">
          {query ? `Results for “${query}”` : 'Search CINÉVERSE'}
        </h1>
        {!loading && data && (
          <p className="mt-1.5 text-sm text-[#A1A1B2] tabular-nums">
            {mergedFranchiseMatches.length} franchise guides · {data.results.length} titles ·{' '}
            {data.peopleMatches.length} cast &amp; crew
          </p>
        )}
      </div>

      {error && (
        <div className="rounded-xl bg-[#191C27] border border-red-500/30 p-5 flex items-center justify-between gap-4 text-sm text-[#F5F3FA]">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => setRetryTick((t) => t + 1)}
            className="px-4 py-2 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold hover:bg-[#b89efc] whitespace-nowrap"
          >
            Retry Search
          </button>
        </div>
      )}

      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-5">
          {Array.from({ length: 12 }).map((_, i) => (
            <TitleCardSkeleton key={i} />
          ))}
        </div>
      ) : !query.trim() ? (
        <div className="rounded-xl bg-[#11131B] border border-white/[0.06] p-12 text-center text-sm text-[#A1A1B2]">
          Enter a movie title, character, franchise, universe, actor, director, or country in the search bar above.
        </div>
      ) : data &&
        data.results.length === 0 &&
        data.peopleMatches.length === 0 &&
        mergedFranchiseMatches.length === 0 ? (
        <div className="rounded-xl bg-[#11131B] border border-white/[0.06] p-12 text-center space-y-2">
          <h2 className="font-serif text-xl text-[#F5F3FA]">No matches found</h2>
          <p className="text-sm text-[#A1A1B2]">
            Try searching by English title, original romaji/native title, franchise name, or exploring by country.
          </p>
        </div>
      ) : (
        <div className="space-y-10">
          {/* Dedicated Franchise & Universe Guides Spotlight (ABOVE individual titles) */}
          {mergedFranchiseMatches.length > 0 && (
            <section className="space-y-4">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#D6B477]">
                    Verified Watch Order Guides
                  </p>
                  <h2 className="font-serif text-2xl font-semibold text-[#F5F3FA] mt-0.5">
                    Franchise &amp; Universe Guides
                  </h2>
                </div>
                <Link
                  to="/franchises"
                  className="text-xs font-medium text-[#A78BFA] hover:text-[#c4b0ff] transition-colors whitespace-nowrap"
                >
                  Browse all franchises →
                </Link>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {mergedFranchiseMatches.map((fr) => (
                  <Link
                    key={fr.id}
                    to={getFranchiseRoute(fr.id)}
                    className="group flex items-start gap-4 p-4 sm:p-5 rounded-2xl bg-[#11131B] border border-[#D6B477]/20 hover:border-[#A78BFA]/60 transition-colors"
                  >
                    {fr.posterUrl ? (
                      <div className="w-16 sm:w-20 aspect-[2/3] rounded-lg overflow-hidden border border-white/10 shrink-0">
                        <PosterImage src={fr.posterUrl} alt={fr.name} className="w-full h-full" />
                      </div>
                    ) : (
                      <div className="w-16 sm:w-20 aspect-[2/3] rounded-lg bg-[#191C27] border border-white/10 flex items-center justify-center shrink-0">
                        <Layers className="w-6 h-6 text-[#D6B477]" />
                      </div>
                    )}

                    <div className="min-w-0 flex-1 space-y-1.5">
                      <p className="text-[11px] font-medium text-[#D6B477] truncate">
                        {fr.matchReason} · {fr.orderAttribution}
                      </p>
                      <h3 className="font-serif text-lg sm:text-xl font-semibold text-[#F5F3FA] group-hover:text-[#A78BFA] transition-colors leading-snug">
                        {fr.name}
                      </h3>
                      <p className="text-xs text-[#A1A1B2] line-clamp-2 leading-relaxed">
                        {fr.description}
                      </p>
                      <div className="pt-1.5 flex flex-wrap items-center justify-between gap-2 text-xs">
                        <span className="text-[#A1A1B2] tabular-nums">
                          {fr.movieCount > 0 ? `${fr.movieCount} films` : ''}
                          {fr.movieCount > 0 && fr.seriesCount > 0 ? ' · ' : ''}
                          {fr.seriesCount > 0 ? `${fr.seriesCount} series` : ''}
                          {fr.movieCount === 0 && fr.seriesCount === 0 ? `${fr.entryCount} entries` : ''} ·{' '}
                          {fr.originCountry}
                        </span>
                        <span className="inline-flex items-center gap-1 font-medium text-[#A78BFA] whitespace-nowrap">
                          <span>Open Viewing Guide</span>
                          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                        </span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </section>
          )}

          {data && data.results.length > 0 && (
            <section className="space-y-4">
              <h2 className="font-serif text-xl font-semibold text-[#F5F3FA]">Individual Titles</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-5">
                {data.results.map((item) => (
                  <TitleCard key={item.titleKey} item={item} />
                ))}
              </div>
            </section>
          )}

          {data && data.peopleMatches.length > 0 && (
            <section className="space-y-4">
              <h2 className="font-serif text-xl font-semibold text-[#F5F3FA]">Cast &amp; Crew</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {data.peopleMatches.map((person) => (
                  <div
                    key={person.id}
                    className="p-3.5 rounded-xl bg-[#11131B] border border-white/[0.06] flex items-center gap-3"
                  >
                    <div className="w-11 h-11 rounded-full bg-[#191C27] overflow-hidden flex items-center justify-center shrink-0">
                      {person.imageUrl ? (
                        <img
                          src={person.imageUrl}
                          alt={person.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <User className="w-5 h-5 text-[#A1A1B2]" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-[#F5F3FA] truncate">{person.name}</p>
                      <p className="text-xs text-[#A1A1B2] truncate">{person.role}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}
