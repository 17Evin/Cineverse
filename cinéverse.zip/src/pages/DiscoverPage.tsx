import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { RotateCcw, SlidersHorizontal } from 'lucide-react';
import type { DiscoverResponse, MediaSummary } from '../types/media';
import {
  CONFIGURABLE_PROVIDERS,
  GLOBAL_COUNTRIES,
  GLOBAL_GENRES,
  LANGUAGES_LIST,
} from '../constants/catalog';
import { discoverTitlesApi } from '../services/api';
import { useUserData } from '../context/UserDataContext';
import { TitleCard, TitleCardSkeleton } from '../components/TitleCard';

interface DiscoverPageProps {
  lockedMediaType?: 'movie' | 'tv' | 'anime';
  heading?: string;
  subheading?: string;
}

export function DiscoverPage({ lockedMediaType, heading, subheading }: DiscoverPageProps) {
  const [searchParams, setSearchParams] = useSearchParams();
  const { preferredRegion } = useUserData();

  const mediaType = (lockedMediaType || searchParams.get('mediaType') || 'all') as
    | 'all'
    | 'movie'
    | 'tv'
    | 'anime';
  const country = searchParams.get('country') || '';
  const language = searchParams.get('language') || '';
  const genre = searchParams.get('genre') || '';
  const year = searchParams.get('year') || '';
  const minRating = Number(searchParams.get('minRating') || 0);
  const status = searchParams.get('status') || '';
  const provider = searchParams.get('provider') || '';
  const sortBy = (searchParams.get('sortBy') || 'popularity') as
    | 'popularity'
    | 'rating'
    | 'release_date'
    | 'title';

  const [items, setItems] = useState<MediaSummary[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(false);
  const [totalResults, setTotalResults] = useState(0);
  const [sourceNotice, setSourceNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(true);

  const updateParam = (key: string, value: string) => {
    const next = new URLSearchParams(searchParams);
    if (!value || value === 'all' || value === '0') {
      next.delete(key);
    } else {
      next.set(key, value);
    }
    setSearchParams(next, { replace: true });
  };

  const resetFilters = () => {
    setSearchParams({}, { replace: true });
  };

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    setError(null);
    setPage(1);

    discoverTitlesApi(
      {
        mediaType,
        country: country || undefined,
        language: language || undefined,
        genre: genre || undefined,
        year: year || undefined,
        minRating: minRating > 0 ? minRating : undefined,
        status: status || undefined,
        provider: provider || undefined,
        region: preferredRegion,
        sortBy,
        page: 1,
      },
      controller.signal
    )
      .then((res: DiscoverResponse) => {
        setItems(res.items);
        setHasMore(res.hasMore);
        setTotalResults(res.totalResults);
        setSourceNotice(res.sourceNotice);
      })
      .catch((err: any) => {
        if (err?.name !== 'AbortError') {
          setError(err?.message || 'Unable to load discovery catalog.');
        }
      })
      .finally(() => setLoading(false));

    return () => controller.abort();
  }, [mediaType, country, language, genre, year, minRating, status, provider, sortBy, preferredRegion]);

  const handleLoadMore = async () => {
    const nextPage = page + 1;
    setLoadingMore(true);
    try {
      const res = await discoverTitlesApi({
        mediaType,
        country: country || undefined,
        language: language || undefined,
        genre: genre || undefined,
        year: year || undefined,
        minRating: minRating > 0 ? minRating : undefined,
        status: status || undefined,
        provider: provider || undefined,
        region: preferredRegion,
        sortBy,
        page: nextPage,
      });
      setItems((prev) => {
        const seen = new Set(prev.map((p) => p.titleKey));
        const uniqueNew = res.items.filter((x) => !seen.has(x.titleKey));
        return [...prev, ...uniqueNew];
      });
      setPage(nextPage);
      setHasMore(res.hasMore);
    } catch (err: any) {
      setError(err?.message || 'Could not load additional pages.');
    } finally {
      setLoadingMore(false);
    }
  };

  const hasActiveFilters = Boolean(
    (!lockedMediaType && mediaType !== 'all') ||
      country ||
      language ||
      genre ||
      year ||
      minRating > 0 ||
      status ||
      provider
  );

  const pageTitle =
    heading ||
    (lockedMediaType === 'movie'
      ? 'Movies'
      : lockedMediaType === 'tv'
        ? 'Television Series & Global Dramas'
        : lockedMediaType === 'anime'
          ? 'Anime Catalog'
          : 'Global Discovery');

  const pageSubheading =
    subheading ||
    'Filter fiction entertainment across countries, original languages, genres, release years, ratings, and streaming providers.';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-4 border-b border-white/[0.06]">
        <div>
          <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#F5F3FA]">
            {pageTitle}
          </h1>
          <p className="mt-1.5 text-sm text-[#A1A1B2] max-w-2xl">{pageSubheading}</p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          {!lockedMediaType && (
            <div className="flex items-center p-1 rounded-lg bg-[#11131B] border border-white/[0.08]">
              {(['all', 'movie', 'tv', 'anime'] as const).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => updateParam('mediaType', t)}
                  className={`px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                    mediaType === t
                      ? 'bg-[#A78BFA] text-[#08090D]'
                      : 'text-[#A1A1B2] hover:text-[#F5F3FA]'
                  }`}
                >
                  {t === 'all' ? 'All' : t === 'movie' ? 'Movies' : t === 'tv' ? 'Series' : 'Anime'}
                </button>
              ))}
            </div>
          )}

          <button
            type="button"
            onClick={() => setShowFilters((v) => !v)}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-[#11131B] border border-white/[0.08] text-xs font-medium text-[#F5F3FA] hover:border-white/20 whitespace-nowrap"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#A78BFA]" />
            <span>{showFilters ? 'Hide Filters' : 'Filters'}</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      {showFilters && (
        <div className="rounded-xl bg-[#11131B] border border-white/[0.06] p-4 sm:p-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
            <div>
              <label htmlFor="filter-country" className="block text-xs text-[#A1A1B2] mb-1.5">
                Country
              </label>
              <select
                id="filter-country"
                value={country}
                onChange={(e) => updateParam('country', e.target.value)}
                className="w-full h-9 px-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
              >
                <option value="">All Countries</option>
                {GLOBAL_COUNTRIES.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="filter-language" className="block text-xs text-[#A1A1B2] mb-1.5">
                Original Language
              </label>
              <select
                id="filter-language"
                value={language}
                onChange={(e) => updateParam('language', e.target.value)}
                className="w-full h-9 px-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
              >
                <option value="">All Languages</option>
                {LANGUAGES_LIST.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="filter-genre" className="block text-xs text-[#A1A1B2] mb-1.5">
                Genre
              </label>
              <select
                id="filter-genre"
                value={genre}
                onChange={(e) => updateParam('genre', e.target.value)}
                className="w-full h-9 px-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
              >
                <option value="">All Genres</option>
                {GLOBAL_GENRES.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="filter-year" className="block text-xs text-[#A1A1B2] mb-1.5">
                Release Year
              </label>
              <input
                id="filter-year"
                type="number"
                min={1920}
                max={2030}
                placeholder="e.g. 2023"
                value={year}
                onChange={(e) => updateParam('year', e.target.value)}
                className="w-full h-9 px-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] placeholder:text-[#A1A1B2]/50 focus:outline-none focus:border-[#A78BFA] tabular-nums"
              />
            </div>

            <div>
              <label htmlFor="filter-rating" className="block text-xs text-[#A1A1B2] mb-1.5">
                Minimum Rating
              </label>
              <select
                id="filter-rating"
                value={String(minRating)}
                onChange={(e) => updateParam('minRating', e.target.value)}
                className="w-full h-9 px-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
              >
                <option value="0">Any Rating</option>
                <option value="6">6.0 and above</option>
                <option value="7">7.0 and above</option>
                <option value="8">8.0 and above</option>
                <option value="8.5">8.5 and above</option>
              </select>
            </div>

            <div>
              <label htmlFor="filter-status" className="block text-xs text-[#A1A1B2] mb-1.5">
                Release Status
              </label>
              <select
                id="filter-status"
                value={status}
                onChange={(e) => updateParam('status', e.target.value)}
                className="w-full h-9 px-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
              >
                <option value="">Any Status</option>
                <option value="airing">Currently Airing</option>
                <option value="completed">Completed / Ended</option>
                <option value="upcoming">Upcoming</option>
              </select>
            </div>

            <div>
              <label htmlFor="filter-provider" className="block text-xs text-[#A1A1B2] mb-1.5">
                Streaming Provider ({preferredRegion})
              </label>
              <select
                id="filter-provider"
                value={provider}
                onChange={(e) => updateParam('provider', e.target.value)}
                className="w-full h-9 px-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
              >
                <option value="">All Providers</option>
                {CONFIGURABLE_PROVIDERS.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="filter-sort" className="block text-xs text-[#A1A1B2] mb-1.5">
                Sort By
              </label>
              <select
                id="filter-sort"
                value={sortBy}
                onChange={(e) => updateParam('sortBy', e.target.value)}
                className="w-full h-9 px-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
              >
                <option value="popularity">Popularity</option>
                <option value="rating">Highest Rated</option>
                <option value="release_date">Newest Release</option>
                <option value="title">Alphabetical (A–Z)</option>
              </select>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-white/[0.06] text-xs text-[#A1A1B2]">
            <span className="tabular-nums">
              {loading ? 'Loading catalog...' : `${totalResults.toLocaleString()} titles indexed`}
            </span>
            {hasActiveFilters && (
              <button
                type="button"
                onClick={resetFilters}
                className="inline-flex items-center gap-1.5 text-[#A78BFA] hover:text-[#c4b0ff] transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset filters</span>
              </button>
            )}
          </div>
        </div>
      )}

      {sourceNotice && (
        <div className="rounded-xl bg-[#11131B] border border-[#D6B477]/25 px-4 py-3 text-xs text-[#D6B477]/90 leading-relaxed">
          {sourceNotice}
        </div>
      )}

      {error && (
        <div className="rounded-xl bg-[#191C27] border border-red-500/30 p-5 text-sm text-[#F5F3FA]">
          {error}
        </div>
      )}

      {/* Results Grid */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-5">
          {Array.from({ length: 12 }).map((_, i) => (
            <TitleCardSkeleton key={i} />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-xl bg-[#11131B] border border-white/[0.06] py-16 px-6 text-center space-y-3">
          <h2 className="font-serif text-xl text-[#F5F3FA]">No matching titles found</h2>
          <p className="text-sm text-[#A1A1B2] max-w-md mx-auto">
            No verified records matched this exact filter combination. Try clearing one or more filters to broaden your search.
          </p>
          {hasActiveFilters && (
            <button
              type="button"
              onClick={resetFilters}
              className="mt-2 px-4 py-2 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold hover:bg-[#b89efc]"
            >
              Clear All Filters
            </button>
          )}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-5">
            {items.map((item) => (
              <TitleCard key={item.titleKey} item={item} />
            ))}
          </div>

          {hasMore && (
            <div className="pt-4 flex justify-center">
              <button
                type="button"
                disabled={loadingMore}
                onClick={handleLoadMore}
                className="px-6 py-2.5 rounded-lg bg-[#11131B] border border-white/15 text-sm font-medium text-[#F5F3FA] hover:border-[#A78BFA] hover:text-[#A78BFA] transition-colors disabled:opacity-50"
              >
                {loadingMore ? 'Loading more titles...' : 'Load More Titles'}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
