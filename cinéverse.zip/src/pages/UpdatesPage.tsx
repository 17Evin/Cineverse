import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  Bookmark,
  Check,
  Film,
  Layers,
  Plus,
  RefreshCw,
  Sparkles,
  Star,
  Tv,
} from 'lucide-react';
import type {
  CatalogUpdatesResponse,
  FranchiseDetail,
  NewReleaseItem,
  ReleaseCategory,
} from '../types/media';
import { STREAMING_REGIONS } from '../constants/catalog';
import {
  getCatalogUpdatesApi,
  getFranchisesApi,
  getFranchiseRoute,
  getTitleRoute,
  refreshCatalogUpdatesApi,
} from '../services/api';
import {
  appendReleaseToFranchise,
  batchSyncReleasesToFranchises,
  checkIsAdminUser,
  fetchFirestoreFranchises,
  mergeFranchiseLists,
} from '../lib/franchiseStore';
import { useUserData } from '../context/UserDataContext';
import { PosterImage } from '../components/PosterImage';

type CategoryFilter = 'all' | ReleaseCategory;
type TimingFilter = 'all' | 'current' | 'upcoming';

const CATEGORY_TABS: Array<{ key: CategoryFilter; label: string }> = [
  { key: 'all', label: 'All Updates' },
  { key: 'movie', label: 'Movies' },
  { key: 'series', label: 'Series' },
  { key: 'drama', label: 'Dramas' },
  { key: 'anime', label: 'Anime' },
];

export function UpdatesPage() {
  const { user, preferredRegion, setGuestRegion, library, upsertTitleStatus, notify } = useUserData();
  const [region, setRegion] = useState(preferredRegion || 'IN');
  const [data, setData] = useState<CatalogUpdatesResponse | null>(null);
  const [allFranchises, setAllFranchises] = useState<FranchiseDetail[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [syncingAll, setSyncingAll] = useState(false);
  const [addingKey, setAddingKey] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [category, setCategory] = useState<CategoryFilter>('all');
  const [timing, setTiming] = useState<TimingFilter>('all');
  const [onlyFranchiseRelated, setOnlyFranchiseRelated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [manualAssignTarget, setManualAssignTarget] = useState<Record<string, string>>({});

  useEffect(() => {
    setRegion(preferredRegion || 'IN');
  }, [preferredRegion]);

  useEffect(() => {
    let active = true;
    checkIsAdminUser(user).then((res) => {
      if (active) setIsAdmin(res);
    });
    return () => {
      active = false;
    };
  }, [user]);

  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    setLoading(true);
    setError(null);

    Promise.all([
      getCatalogUpdatesApi(region, controller.signal),
      getFranchisesApi(undefined, region, controller.signal).catch(() => []),
      fetchFirestoreFranchises({ includeDrafts: isAdmin }).catch(() => []),
    ])
      .then(([updatesRes, apiFranchises, customFranchises]) => {
        if (!active) return;
        setData(updatesRes);
        setAllFranchises(mergeFranchiseLists(apiFranchises, customFranchises));
      })
      .catch((err: any) => {
        if (err?.name !== 'AbortError' && active) {
          setError(err?.message || 'Unable to load live catalog updates.');
        }
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
      controller.abort();
    };
  }, [region, isAdmin]);

  // Fast membership lookup across ALL franchises (including newly saved Firestore overrides)
  const franchiseMembershipMap = useMemo(() => {
    const map = new Map<string, { id: string; name: string }>();
    for (const fr of allFranchises) {
      for (const entry of fr.orders.complete || []) {
        if (!map.has(entry.titleKey)) {
          map.set(entry.titleKey, { id: fr.id, name: fr.name });
        }
      }
    }
    return map;
  }, [allFranchises]);

  // Enrich items with live Firestore franchise membership state
  const itemsWithLiveState = useMemo(() => {
    const raw = data?.items || [];
    return raw.map((item) => {
      const existingFr = franchiseMembershipMap.get(item.titleKey);
      if (item.detectedFranchise) {
        const isInTarget =
          existingFr?.id === item.detectedFranchise.franchiseId ||
          allFranchises
            .find((f) => f.id === item.detectedFranchise?.franchiseId)
            ?.orders.complete.some((e) => e.titleKey === item.titleKey);
        return {
          ...item,
          detectedFranchise: {
            ...item.detectedFranchise,
            alreadyInFranchise: Boolean(isInTarget || item.detectedFranchise.alreadyInFranchise),
          },
          linkedFranchise: existingFr || null,
        };
      }
      return {
        ...item,
        linkedFranchise: existingFr || null,
      };
    });
  }, [data?.items, franchiseMembershipMap, allFranchises]);

  const pendingFranchiseReleases = useMemo(
    () =>
      itemsWithLiveState.filter(
        (item) => item.detectedFranchise && !item.detectedFranchise.alreadyInFranchise
      ),
    [itemsWithLiveState]
  );

  const franchiseSpotlightItems = useMemo(
    () => itemsWithLiveState.filter((item) => Boolean(item.detectedFranchise)),
    [itemsWithLiveState]
  );

  const filteredItems = useMemo(() => {
    return itemsWithLiveState.filter((item) => {
      if (category !== 'all' && item.category !== category) return false;
      if (timing === 'current' && item.releaseBucket === 'upcoming') return false;
      if (timing === 'upcoming' && item.releaseBucket !== 'upcoming') return false;
      if (onlyFranchiseRelated && !item.detectedFranchise && !item.linkedFranchise) return false;
      return true;
    });
  }, [itemsWithLiveState, category, timing, onlyFranchiseRelated]);

  const handleRefreshCatalog = async () => {
    setRefreshing(true);
    setError(null);
    try {
      const fresh = await refreshCatalogUpdatesApi(region);
      setData(fresh);
      notify(
        `Catalog updated: ${fresh.counts.total} releases scanned, ${fresh.counts.franchiseRelated} franchise-linked.`,
        'success'
      );
    } catch (err: any) {
      setError(err?.message || 'Unable to refresh live catalog updates.');
      notify('Unable to refresh catalog right now.', 'error');
    } finally {
      setRefreshing(false);
    }
  };

  const handleAddSingleToFranchise = async (
    item: NewReleaseItem,
    targetFranchiseId: string
  ) => {
    if (!user || !isAdmin) {
      notify('Verified admin sign-in is required to update shared franchise guides.', 'error');
      return;
    }
    setAddingKey(`${item.titleKey}_${targetFranchiseId}`);
    try {
      const { franchise, added } = await appendReleaseToFranchise(user, targetFranchiseId, item, {
        region,
      });
      setAllFranchises((prev) => mergeFranchiseLists(prev, [franchise]));
      if (added) {
        notify(`Added "${item.title}" to ${franchise.name}.`, 'success');
      } else {
        notify(`"${item.title}" is already in ${franchise.name}.`, 'default');
      }
    } catch (err: any) {
      notify(err?.message || 'Could not add release to franchise.', 'error');
    } finally {
      setAddingKey(null);
    }
  };

  const handleSyncAllRelated = async () => {
    if (!user || !isAdmin) return;
    if (pendingFranchiseReleases.length === 0) {
      notify('All detected franchise-related releases are already synced.', 'default');
      return;
    }
    setSyncingAll(true);
    try {
      const { syncedCount, updatedFranchises } = await batchSyncReleasesToFranchises(
        user,
        pendingFranchiseReleases,
        region
      );
      if (updatedFranchises.length > 0) {
        setAllFranchises((prev) => mergeFranchiseLists(prev, updatedFranchises));
      }
      if (syncedCount > 0) {
        notify(
          `Synced ${syncedCount} new ${syncedCount === 1 ? 'release' : 'releases'} across ${updatedFranchises.length} ${updatedFranchises.length === 1 ? 'franchise' : 'franchises'}.`,
          'success'
        );
      } else {
        notify('All detected releases were already present in their franchises.', 'default');
      }
    } catch (err: any) {
      notify(err?.message || 'Failed to batch-sync franchise additions.', 'error');
    } finally {
      setSyncingAll(false);
    }
  };

  const syncedTimeLabel = useMemo(() => {
    if (!data?.syncedAt) return null;
    try {
      return new Date(data.syncedAt).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return null;
    }
  }, [data?.syncedAt]);

  return (
    <div className="space-y-8">
      {/* Header Bar */}
      <section className="flex flex-col lg:flex-row lg:items-end justify-between gap-5 pb-5 border-b border-white/[0.06]">
        <div className="space-y-1.5 max-w-2xl">
          <p className="text-xs font-medium tracking-[0.16em] uppercase text-[#D6B477]">
            Live Catalog &amp; Franchise Sync
          </p>
          <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#F5F3FA]">
            New Movies, Series &amp; Dramas
          </h1>
          <p className="text-sm text-[#A1A1B2] leading-relaxed">
            Automatically pulls newly released, currently airing, and upcoming movies, television series, global dramas, and anime — and detects verified franchise connections so related releases can be added directly to their viewing guides.
          </p>
          {syncedTimeLabel && (
            <p className="text-xs text-[#A1A1B2]/80 tabular-nums">
              Last live sync: {syncedTimeLabel} · Region {region}
            </p>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <select
            aria-label="Updates region"
            value={region}
            onChange={(e) => {
              setRegion(e.target.value);
              setGuestRegion(e.target.value);
            }}
            className="h-9 px-3 rounded-lg bg-[#11131B] border border-white/10 text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
          >
            {STREAMING_REGIONS.map((r) => (
              <option key={r.code} value={r.code} className="bg-[#11131B]">
                {r.name} ({r.code})
              </option>
            ))}
          </select>

          <button
            type="button"
            disabled={refreshing || loading}
            onClick={handleRefreshCatalog}
            className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-[#191C27] border border-white/10 hover:border-[#A78BFA]/60 text-xs font-medium text-[#F5F3FA] disabled:opacity-50 transition-colors whitespace-nowrap"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#A78BFA] ${refreshing ? 'animate-spin' : ''}`} />
            <span>{refreshing ? 'Checking Providers…' : 'Check for Updates'}</span>
          </button>

          {isAdmin && pendingFranchiseReleases.length > 0 && (
            <button
              type="button"
              disabled={syncingAll}
              onClick={handleSyncAllRelated}
              className="inline-flex items-center gap-2 h-9 px-4 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold hover:bg-[#b89efc] disabled:opacity-50 transition-colors whitespace-nowrap"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>
                {syncingAll
                  ? 'Syncing Franchises…'
                  : `Auto-Add ${pendingFranchiseReleases.length} to Franchises`}
              </span>
            </button>
          )}
        </div>
      </section>

      {error && (
        <div className="rounded-xl bg-[#191C27] border border-red-500/30 p-5 text-sm text-[#F5F3FA]">
          {error}
        </div>
      )}

      {/* 4-Column Summary Strip */}
      {!loading && data && (
        <section className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="p-4 rounded-xl bg-[#11131B] border border-white/[0.06]">
            <p className="text-xs text-[#A1A1B2]">New &amp; Upcoming Movies</p>
            <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-[#F5F3FA]">
              {data.counts.movies}
            </p>
          </div>
          <div className="p-4 rounded-xl bg-[#11131B] border border-white/[0.06]">
            <p className="text-xs text-[#A1A1B2]">New Series &amp; Anime</p>
            <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-[#F5F3FA]">
              {data.counts.series + data.counts.anime}
            </p>
          </div>
          <div className="p-4 rounded-xl bg-[#11131B] border border-white/[0.06]">
            <p className="text-xs text-[#A1A1B2]">Global Dramas</p>
            <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-[#F5F3FA]">
              {data.counts.dramas}
            </p>
          </div>
          <div className="p-4 rounded-xl bg-[#11131B] border border-[#D6B477]/25">
            <p className="text-xs text-[#D6B477]">Franchise-Related Detected</p>
            <p className="mt-1 font-mono text-2xl font-semibold tabular-nums text-[#F5F3FA]">
              {franchiseSpotlightItems.length}
              {pendingFranchiseReleases.length > 0 && (
                <span className="ml-2 text-xs font-sans font-medium text-[#A78BFA]">
                  ({pendingFranchiseReleases.length} new to add)
                </span>
              )}
            </p>
          </div>
        </section>
      )}

      {/* Detected Franchise Additions Spotlight */}
      {!loading && franchiseSpotlightItems.length > 0 && (
        <section className="space-y-4">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#D6B477]">
                Automatic Franchise Detection
              </p>
              <h2 className="font-serif text-2xl font-semibold text-[#F5F3FA] mt-0.5">
                Related Franchise Releases
              </h2>
            </div>
            <Link
              to="/franchises"
              className="text-xs font-medium text-[#A78BFA] hover:text-[#c4b0ff] whitespace-nowrap"
            >
              Open Franchise Guides →
            </Link>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {franchiseSpotlightItems.slice(0, 8).map((item) => {
              const det = item.detectedFranchise!;
              const busy = addingKey === `${item.titleKey}_${det.franchiseId}`;
              return (
                <div
                  key={`spot_${item.titleKey}`}
                  className="flex items-start gap-4 p-4 rounded-2xl bg-[#11131B] border border-[#D6B477]/20 hover:border-white/20 transition-colors"
                >
                  <Link
                    to={getTitleRoute(item)}
                    className="w-16 sm:w-20 aspect-[2/3] rounded-lg overflow-hidden border border-white/10 shrink-0"
                  >
                    <PosterImage src={item.posterUrl} alt={item.title} className="w-full h-full" />
                  </Link>

                  <div className="flex-1 min-w-0 space-y-1.5">
                    <p className="text-[11px] font-medium text-[#D6B477] truncate">
                      {det.matchReason} · {item.releaseBucket === 'upcoming' ? 'Upcoming' : 'Recent Release'}
                    </p>
                    <Link
                      to={getTitleRoute(item)}
                      className="block font-serif text-lg font-semibold text-[#F5F3FA] hover:text-[#A78BFA] transition-colors truncate"
                    >
                      {item.title}
                    </Link>
                    <p className="text-xs text-[#A1A1B2] tabular-nums">
                      {item.releaseDate || item.releaseYear || 'TBA'} · {item.country} ·{' '}
                      {item.category === 'movie'
                        ? 'Movie'
                        : item.category === 'drama'
                          ? 'Drama'
                          : item.category === 'anime'
                            ? 'Anime'
                            : 'Series'}
                    </p>
                    <p className="text-xs text-[#F5F3FA]/80">
                      Franchise:{' '}
                      <Link
                        to={getFranchiseRoute(det.franchiseId)}
                        className="text-[#A78BFA] hover:underline font-medium"
                      >
                        {det.franchiseName}
                      </Link>
                    </p>

                    <div className="pt-2 flex flex-wrap items-center gap-2">
                      {det.alreadyInFranchise ? (
                        <Link
                          to={getFranchiseRoute(det.franchiseId)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#191C27] border border-[#D6B477]/35 text-xs font-medium text-[#D6B477] whitespace-nowrap"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>In Franchise Guide</span>
                          <ArrowRight className="w-3 h-3" />
                        </Link>
                      ) : isAdmin ? (
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => handleAddSingleToFranchise(item, det.franchiseId)}
                          className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold hover:bg-[#b89efc] disabled:opacity-50 transition-colors whitespace-nowrap"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>{busy ? 'Adding…' : `Add to ${det.franchiseName.split(' (')[0]}`}</span>
                        </button>
                      ) : (
                        <Link
                          to={getFranchiseRoute(det.franchiseId)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#191C27] border border-white/10 text-xs font-medium text-[#F5F3FA] hover:border-[#A78BFA]/60 whitespace-nowrap"
                        >
                          <span>View Franchise Guide</span>
                          <ArrowRight className="w-3 h-3 text-[#A78BFA]" />
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Filter Controls for Full Catalog Feed */}
      <section className="space-y-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-white/[0.06]">
          <div className="flex flex-wrap items-center gap-1.5">
            {CATEGORY_TABS.map((tab) => (
              <button
                key={tab.key}
                type="button"
                onClick={() => setCategory(tab.key)}
                className={`px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                  category === tab.key
                    ? 'bg-[#A78BFA] text-[#08090D]'
                    : 'bg-[#191C27] text-[#A1A1B2] hover:text-[#F5F3FA]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <select
              aria-label="Release timing filter"
              value={timing}
              onChange={(e) => setTiming(e.target.value as TimingFilter)}
              className="h-9 px-3 rounded-lg bg-[#11131B] border border-white/10 text-xs text-[#F5F3FA]"
            >
              <option value="all">All Timing</option>
              <option value="current">New &amp; Currently Airing</option>
              <option value="upcoming">Upcoming Releases</option>
            </select>

            <label className="inline-flex items-center gap-2 text-xs text-[#F5F3FA] cursor-pointer select-none">
              <input
                type="checkbox"
                checked={onlyFranchiseRelated}
                onChange={(e) => setOnlyFranchiseRelated(e.target.checked)}
                className="accent-[#A78BFA]"
              />
              <span>Franchise-related only</span>
            </label>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="h-36 rounded-xl bg-[#11131B] animate-pulse" />
            ))}
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="rounded-xl bg-[#11131B] border border-white/[0.06] p-10 text-center text-sm text-[#A1A1B2]">
            No releases match the active filters. Try switching category or clearing the franchise-only filter.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredItems.map((item) => {
              const saved = library[item.titleKey];
              const det = item.detectedFranchise;
              const linked = item.linkedFranchise;
              const chosenFranchiseId = manualAssignTarget[item.titleKey] || '';
              const busyAuto = det ? addingKey === `${item.titleKey}_${det.franchiseId}` : false;
              const busyManual = chosenFranchiseId
                ? addingKey === `${item.titleKey}_${chosenFranchiseId}`
                : false;

              return (
                <article
                  key={item.titleKey}
                  className="flex items-start gap-4 p-4 rounded-xl bg-[#11131B] border border-white/[0.06] hover:border-white/15 transition-colors"
                >
                  <Link
                    to={getTitleRoute(item)}
                    className="w-16 sm:w-20 aspect-[2/3] rounded-lg overflow-hidden border border-white/10 shrink-0"
                  >
                    <PosterImage src={item.posterUrl} alt={item.title} className="w-full h-full" />
                  </Link>

                  <div className="flex-1 min-w-0 space-y-1.5">
                    <div className="flex items-center justify-between gap-2 text-[11px]">
                      <span className="text-[#D6B477] font-medium inline-flex items-center gap-1">
                        {item.category === 'movie' ? (
                          <Film className="w-3 h-3" />
                        ) : item.category === 'anime' ? (
                          <Sparkles className="w-3 h-3" />
                        ) : (
                          <Tv className="w-3 h-3" />
                        )}
                        <span>
                          {item.category === 'movie'
                            ? 'Movie'
                            : item.category === 'drama'
                              ? 'Drama'
                              : item.category === 'anime'
                                ? 'Anime'
                                : 'Series'}
                        </span>
                        <span className="text-[#A1A1B2]">
                          ·{' '}
                          {item.releaseBucket === 'upcoming'
                            ? 'Upcoming'
                            : item.releaseBucket === 'airing_now'
                              ? 'Airing Now'
                              : 'New Release'}
                        </span>
                      </span>

                      {item.rating !== null && item.rating > 0 && (
                        <span className="inline-flex items-center gap-1 font-mono text-[#D6B477] tabular-nums shrink-0">
                          <Star className="w-3 h-3 fill-[#D6B477]" />
                          {item.rating.toFixed(1)}
                        </span>
                      )}
                    </div>

                    <Link
                      to={getTitleRoute(item)}
                      className="block text-base font-serif font-semibold text-[#F5F3FA] hover:text-[#A78BFA] transition-colors truncate"
                    >
                      {item.title}
                    </Link>

                    <p className="text-xs text-[#A1A1B2] tabular-nums truncate">
                      {item.releaseDate || item.releaseYear || 'Date TBA'} · {item.country}
                      {item.genres.length > 0 ? ` · ${item.genres.slice(0, 2).join(', ')}` : ''}
                    </p>

                    {item.synopsis && (
                      <p className="text-xs text-[#A1A1B2]/85 line-clamp-2 leading-relaxed">
                        {item.synopsis}
                      </p>
                    )}

                    {/* Action Footer: Watchlist + Franchise Sync */}
                    <div className="pt-2 flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          upsertTitleStatus(item, {
                            status: saved ? saved.status : 'want_to_watch',
                          })
                        }
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-[11px] font-medium border transition-colors whitespace-nowrap ${
                          saved
                            ? 'bg-[#191C27] border-[#A78BFA]/50 text-[#A78BFA]'
                            : 'bg-[#191C27] border-white/10 text-[#F5F3FA] hover:border-white/25'
                        }`}
                      >
                        <Bookmark className="w-3 h-3" />
                        <span>{saved ? 'In Library' : 'Watchlist'}</span>
                      </button>

                      {det && !det.alreadyInFranchise && isAdmin ? (
                        <button
                          type="button"
                          disabled={busyAuto}
                          onClick={() => handleAddSingleToFranchise(item, det.franchiseId)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-[11px] font-semibold hover:bg-[#b89efc] disabled:opacity-50 whitespace-nowrap"
                        >
                          <Plus className="w-3 h-3" />
                          <span>{busyAuto ? 'Adding…' : `Add to ${det.franchiseName.split(' (')[0]}`}</span>
                        </button>
                      ) : linked ? (
                        <Link
                          to={getFranchiseRoute(linked.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#191C27] border border-[#D6B477]/35 text-[11px] text-[#D6B477] hover:border-[#D6B477] whitespace-nowrap"
                        >
                          <Check className="w-3 h-3" />
                          <span className="truncate max-w-[160px]">{linked.name}</span>
                        </Link>
                      ) : isAdmin ? (
                        <div className="inline-flex items-center gap-1.5">
                          <select
                            aria-label={`Assign ${item.title} to franchise`}
                            value={chosenFranchiseId}
                            onChange={(e) =>
                              setManualAssignTarget((prev) => ({
                                ...prev,
                                [item.titleKey]: e.target.value,
                              }))
                            }
                            className="h-7 max-w-[150px] px-2 rounded-lg bg-[#08090D] border border-white/10 text-[11px] text-[#A1A1B2] focus:outline-none focus:border-[#A78BFA]"
                          >
                            <option value="">Link to franchise…</option>
                            {allFranchises.map((f) => (
                              <option key={f.id} value={f.id}>
                                {f.name}
                              </option>
                            ))}
                          </select>
                          {chosenFranchiseId && (
                            <button
                              type="button"
                              disabled={busyManual}
                              onClick={() => handleAddSingleToFranchise(item, chosenFranchiseId)}
                              className="h-7 px-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-[11px] font-semibold hover:bg-[#b89efc] disabled:opacity-50 whitespace-nowrap"
                            >
                              {busyManual ? '…' : 'Add'}
                            </button>
                          )}
                        </div>
                      ) : null}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
