import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  Info,
  Layers,
  Play,
  Plus,
  RefreshCw,
  Search,
  Settings2,
} from 'lucide-react';
import type { FranchiseDetail, FranchiseEntry, NewReleaseItem } from '../types/media';
import { GENERATED_ASSETS, STREAMING_REGIONS } from '../constants/catalog';
import {
  getCatalogUpdatesApi,
  getFranchiseDetailApi,
  getFranchisesApi,
  getFranchiseRoute,
  getTitleRoute,
} from '../services/api';
import {
  appendReleaseToFranchise,
  checkIsAdminUser,
  fetchFirestoreFranchises,
  mergeFranchiseLists,
} from '../lib/franchiseStore';
import { useUserData } from '../context/UserDataContext';
import { PosterImage } from '../components/PosterImage';
import { FranchiseEntryRow } from '../components/FranchiseEntryRow';

type ViewingOrderTab =
  | 'recommended'
  | 'release'
  | 'chronological'
  | 'complete'
  | 'movies_only'
  | 'series_and_specials';

const TAB_CONFIG: Array<{ key: ViewingOrderTab; label: string }> = [
  { key: 'recommended', label: 'Recommended Order' },
  { key: 'release', label: 'Release Order' },
  { key: 'chronological', label: 'Chronological Order' },
  { key: 'complete', label: 'Complete Universe' },
  { key: 'movies_only', label: 'Movies Only' },
  { key: 'series_and_specials', label: 'Series & Specials' },
];

function computeEntriesForTab(franchise: FranchiseDetail | null, tab: ViewingOrderTab): FranchiseEntry[] {
  if (!franchise) return [];
  if (tab === 'recommended') return franchise.orders.recommended || [];
  if (tab === 'release') return franchise.orders.release || [];
  if (tab === 'chronological') return franchise.orders.chronological || [];
  if (tab === 'complete') return franchise.orders.complete || [];

  const sourceList =
    franchise.orders.complete.length > 0
      ? franchise.orders.complete
      : franchise.orders.recommended;

  if (tab === 'movies_only') {
    return sourceList
      .filter((e) => e.mediaType === 'movie')
      .map((e, idx) => ({ ...e, position: idx + 1 }));
  }

  // series_and_specials
  return sourceList
    .filter(
      (e) =>
        e.mediaType !== 'movie' ||
        e.entryType.toLowerCase().includes('special') ||
        (e.relationships || []).some((r) => r.toLowerCase().includes('special'))
    )
    .map((e, idx) => ({ ...e, position: idx + 1 }));
}

export function FranchisesPage() {
  const { id: routeId } = useParams<{ id?: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const { user, preferredRegion, setGuestRegion, library, notify } = useUserData();
  const [region, setRegion] = useState(preferredRegion || 'IN');
  const [franchises, setFranchises] = useState<FranchiseDetail[]>([]);
  const [activeDetail, setActiveDetail] = useState<FranchiseDetail | null>(null);
  const [loadingList, setLoadingList] = useState(true);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<ViewingOrderTab>('recommended');
  const [filterQuery, setFilterQuery] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);
  const [highlightedKey, setHighlightedKey] = useState<string | null>(null);
  const [autoExpandKey, setAutoExpandKey] = useState<string | null>(null);
  const [catalogUpdates, setCatalogUpdates] = useState<NewReleaseItem[]>([]);
  const [addingUpdateKey, setAddingUpdateKey] = useState<string | null>(null);

  const rowRefs = useRef<Record<string, HTMLDivElement | null>>({});

  const selectedId = routeId || searchParams.get('id') || '';
  const hasExplicitSelection = Boolean(selectedId);

  useEffect(() => {
    setRegion(preferredRegion || 'IN');
  }, [preferredRegion]);

  useEffect(() => {
    let active = true;
    checkIsAdminUser(user).then((res) => {
      if (active) setIsAdmin(res);
    });
    return () => {
      active = false;
    };
  }, [user]);

  // Reset transient highlights and scroll to top whenever a particular universe is opened
  useEffect(() => {
    setHighlightedKey(null);
    setAutoExpandKey(null);
    if (selectedId) {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [selectedId]);

  // Load directory (built-in verified + Firestore admin-curated)
  useEffect(() => {
    const controller = new AbortController();
    let active = true;
    setLoadingList(true);
    setError(null);

    Promise.all([
      getFranchisesApi(undefined, region, controller.signal),
      fetchFirestoreFranchises({ includeDrafts: isAdmin }),
      getCatalogUpdatesApi(region, controller.signal).catch(() => null),
    ])
      .then(([apiList, customList, updatesRes]) => {
        if (!active) return;
        const merged = mergeFranchiseLists(apiList, customList);
        setFranchises(merged);
        if (updatesRes?.items) {
          setCatalogUpdates(updatesRes.items);
        }
      })
      .catch((err: any) => {
        if (err?.name !== 'AbortError' && active) {
          setError(err?.message || 'Unable to load franchise viewing orders.');
        }
      })
      .finally(() => {
        if (active) setLoadingList(false);
      });

    return () => {
      active = false;
      controller.abort();
    };
  }, [region, isAdmin]);

  const activeDirectoryFranchise = useMemo(
    () => franchises.find((f) => f.id === selectedId) || franchises[0] || null,
    [franchises, selectedId]
  );

  // Fetch live-enriched detail (posters, backdrops, runtimes, seasons/episodes, regional streaming providers) for the active franchise
  useEffect(() => {
    if (!activeDirectoryFranchise) {
      setActiveDetail(null);
      return;
    }

    if (activeDirectoryFranchise.isCustom) {
      setActiveDetail(activeDirectoryFranchise);
      return;
    }

    const controller = new AbortController();
    let active = true;
    setLoadingDetail(true);
    setActiveDetail(activeDirectoryFranchise);

    getFranchiseDetailApi(activeDirectoryFranchise.id, region, controller.signal)
      .then((enriched) => {
        if (active && enriched) {
          setActiveDetail(enriched);
        }
      })
      .catch(() => {
        // Keep directory copy gracefully if detail enrichment times out
      })
      .finally(() => {
        if (active) setLoadingDetail(false);
      });

    return () => {
      active = false;
      controller.abort();
    };
  }, [activeDirectoryFranchise?.id, activeDirectoryFranchise?.isCustom, region]);

  // Guard against stale activeDetail from a previously selected franchise during route transitions
  const displayFranchise =
    activeDetail && activeDetail.id === activeDirectoryFranchise?.id
      ? activeDetail
      : activeDirectoryFranchise;

  // Compute available verified tabs (never show empty/unverified tabs)
  const availableTabs = useMemo(() => {
    if (!displayFranchise) return [] as Array<{ key: ViewingOrderTab; label: string; count: number }>;
    return TAB_CONFIG.map((t) => ({
      ...t,
      count: computeEntriesForTab(displayFranchise, t.key).length,
    })).filter((t) => t.count > 0);
  }, [displayFranchise]);

  // Keep activeTab valid when switching franchises
  useEffect(() => {
    if (availableTabs.length === 0) return;
    if (!availableTabs.some((t) => t.key === activeTab)) {
      setActiveTab(availableTabs[0].key);
    }
  }, [displayFranchise?.id, availableTabs, activeTab]);

  const activeEntries = useMemo(
    () => computeEntriesForTab(displayFranchise, activeTab),
    [displayFranchise, activeTab]
  );

  const completedInActiveTab = useMemo(
    () => activeEntries.filter((e) => library[e.titleKey]?.status === 'completed').length,
    [activeEntries, library]
  );

  const activePct =
    activeEntries.length > 0 ? Math.round((completedInActiveTab / activeEntries.length) * 100) : 0;

  // Next unwatched entry in the active viewing order
  const nextUnwatchedEntry = useMemo(
    () => activeEntries.find((e) => library[e.titleKey]?.status !== 'completed') || null,
    [activeEntries, library]
  );

  const relatedFranchises = useMemo(() => {
    if (!displayFranchise?.relatedFranchiseIds?.length) return [];
    return displayFranchise.relatedFranchiseIds
      .map((rid) => franchises.find((f) => f.id === rid))
      .filter((x): x is FranchiseDetail => Boolean(x));
  }, [displayFranchise, franchises]);

  const filteredDirectory = useMemo(() => {
    const q = filterQuery.trim().toLowerCase();
    if (!q) return franchises;
    return franchises.filter(
      (f) =>
        f.name.toLowerCase().includes(q) ||
        f.originCountry.toLowerCase().includes(q) ||
        (f.searchAliases || []).some((a) => a.toLowerCase().includes(q))
    );
  }, [franchises, filterQuery]);

  const handleResumeNext = () => {
    if (!nextUnwatchedEntry) return;
    setHighlightedKey(nextUnwatchedEntry.titleKey);
    if (nextUnwatchedEntry.mediaType !== 'movie') {
      setAutoExpandKey(nextUnwatchedEntry.titleKey);
    }
    const targetEl = rowRefs.current[nextUnwatchedEntry.titleKey];
    if (targetEl) {
      targetEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const pendingReleasesForActive = useMemo(() => {
    if (!displayFranchise) return [] as NewReleaseItem[];
    const existingKeys = new Set((displayFranchise.orders.complete || []).map((e) => e.titleKey));
    return catalogUpdates.filter(
      (item) =>
        item.detectedFranchise?.franchiseId === displayFranchise.id &&
        !existingKeys.has(item.titleKey)
    );
  }, [displayFranchise, catalogUpdates]);

  const handleAddDetectedRelease = async (item: NewReleaseItem) => {
    if (!user || !isAdmin || !displayFranchise) return;
    setAddingUpdateKey(item.titleKey);
    try {
      const { franchise, added } = await appendReleaseToFranchise(user, displayFranchise.id, item, {
        region,
      });
      setFranchises((prev) => mergeFranchiseLists(prev, [franchise]));
      setActiveDetail(franchise);
      if (added) {
        notify(`Added "${item.title}" to ${franchise.name}.`, 'success');
      }
    } catch (err: any) {
      notify(err?.message || 'Unable to add release to this franchise.', 'error');
    } finally {
      setAddingUpdateKey(null);
    }
  };

  const activeOrderNote =
    displayFranchise?.orderNotes &&
    (activeTab === 'recommended' ||
      activeTab === 'release' ||
      activeTab === 'chronological' ||
      activeTab === 'complete')
      ? displayFranchise.orderNotes[activeTab]
      : null;

  return (
    <div className="space-y-8">
      {/* Top Header Strip */}
      <section className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-5 border-b border-white/[0.06]">
        <div className="space-y-1.5 max-w-2xl">
          <p className="text-xs font-medium tracking-[0.16em] uppercase text-[#D6B477]">
            Franchises &amp; Verified Viewing Guides
          </p>
          <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#F5F3FA]">
            Follow Every Universe in Order
          </h1>
          <p className="text-sm text-[#A1A1B2] leading-relaxed">
            Switch between recommended, release, chronological, movies-only, and series guides while keeping your watched progress synchronized across every timeline.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <label className="inline-flex items-center gap-2 text-xs text-[#A1A1B2]">
            <span>Region</span>
            <select
              aria-label="Streaming region"
              value={region}
              onChange={(e) => {
                setRegion(e.target.value);
                setGuestRegion(e.target.value);
              }}
              className="h-9 px-3 rounded-lg bg-[#11131B] border border-white/10 text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
            >
              {STREAMING_REGIONS.map((r) => (
                <option key={r.code} value={r.code} className="bg-[#11131B]">
                  {r.name} ({r.code})
                </option>
              ))}
            </select>
          </label>

          <Link
            to="/updates"
            className="inline-flex items-center gap-1.5 h-9 px-3.5 rounded-lg bg-[#191C27] border border-white/10 text-xs font-medium text-[#F5F3FA] hover:border-[#A78BFA]/60 transition-colors whitespace-nowrap"
          >
            <RefreshCw className="w-3.5 h-3.5 text-[#A78BFA]" />
            <span>New Updates</span>
          </Link>

          {isAdmin && (
            <Link
              to="/franchises/admin"
              className="inline-flex items-center gap-1.5 h-9 px-3.5 rounded-lg bg-[#191C27] border border-[#D6B477]/40 text-xs font-medium text-[#D6B477] hover:bg-[#D6B477]/10 transition-colors whitespace-nowrap"
            >
              <Settings2 className="w-3.5 h-3.5" />
              <span>Curate Orders</span>
            </Link>
          )}
        </div>
      </section>

      {error && (
        <div className="rounded-xl bg-[#191C27] border border-red-500/30 p-5 text-sm text-[#F5F3FA]">
          {error}
        </div>
      )}

      {loadingList ? (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
          <div className="xl:col-span-4 space-y-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-20 rounded-xl bg-[#11131B] animate-pulse" />
            ))}
          </div>
          <div className="hidden xl:block xl:col-span-8 h-[520px] rounded-2xl bg-[#11131B] animate-pulse" />
        </div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
          {/* Directory Column:
              - On < xl: visible when browsing /franchises (no selection); hides cleanly when a franchise is opened so the detail page opens right at the top.
              - On >= xl: always visible as sticky left master list. */}
          <aside
            className={`${
              hasExplicitSelection ? 'hidden xl:block' : 'block'
            } xl:col-span-4 space-y-4 xl:sticky xl:top-20`}
          >
            <div className="relative">
              <Search
                className="w-4 h-4 text-[#A1A1B2] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                placeholder="Filter franchises or characters..."
                aria-label="Filter franchises"
                className="w-full h-10 pl-9 pr-3 rounded-lg bg-[#11131B] border border-white/[0.08] text-xs sm:text-sm text-[#F5F3FA] placeholder:text-[#A1A1B2]/65 focus:outline-none focus:border-[#A78BFA]/70"
              />
            </div>

            <div className="flex items-center justify-between px-1 text-[11px] uppercase tracking-[0.14em] text-[#A1A1B2]">
              <span>Select a Universe</span>
              <span className="font-mono tabular-nums">{filteredDirectory.length}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-1 gap-2.5 xl:max-h-[68vh] xl:overflow-y-auto xl:pr-1">
              {filteredDirectory.map((fr) => {
                const active = hasExplicitSelection
                  ? fr.id === displayFranchise?.id
                  : fr.id === displayFranchise?.id;
                const completeList = fr.orders.complete || [];
                const done = completeList.filter(
                  (e) => library[e.titleKey]?.status === 'completed'
                ).length;

                return (
                  <Link
                    key={fr.id}
                    to={getFranchiseRoute(fr.id)}
                    className={`group w-full flex items-center gap-3 text-left p-3 rounded-xl border transition-colors cursor-pointer touch-manipulation ${
                      active
                        ? 'bg-[#191C27] xl:border-[#A78BFA]/70 border-white/[0.12] hover:border-[#A78BFA]/70'
                        : 'bg-[#11131B] border-white/[0.06] hover:border-[#A78BFA]/50 hover:bg-[#191C27]/60'
                    }`}
                  >
                    {fr.posterUrl ? (
                      <div className="w-11 h-16 rounded-md overflow-hidden border border-white/10 shrink-0">
                        <PosterImage src={fr.posterUrl} alt={fr.name} className="w-full h-full" />
                      </div>
                    ) : (
                      <div className="w-11 h-16 rounded-md bg-[#191C27] border border-white/10 flex items-center justify-center shrink-0">
                        <Layers className="w-4 h-4 text-[#D6B477]" />
                      </div>
                    )}

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] text-[#D6B477] truncate">
                          {fr.originCountry}
                        </span>
                        <span className="text-[11px] font-mono tabular-nums text-[#A1A1B2] shrink-0">
                          {done}/{completeList.length}
                        </span>
                      </div>
                      <p className="mt-0.5 text-sm font-semibold text-[#F5F3FA] group-hover:text-[#A78BFA] transition-colors truncate">
                        {fr.name}
                      </p>
                      <div className="mt-0.5 flex items-center justify-between gap-2 text-[11px] text-[#A1A1B2] tabular-nums">
                        <span className="truncate">
                          {fr.confirmedMovieCount > 0 ? `${fr.confirmedMovieCount} films` : ''}
                          {fr.confirmedMovieCount > 0 && fr.confirmedSeriesCount > 0 ? ' · ' : ''}
                          {fr.confirmedSeriesCount > 0 ? `${fr.confirmedSeriesCount} series` : ''}
                        </span>
                        <span className="xl:hidden text-[#A78BFA] font-medium shrink-0 inline-flex items-center gap-0.5">
                          <span>Open</span>
                          <ArrowRight className="w-3 h-3" />
                        </span>
                      </div>
                    </div>
                  </Link>
                );
              })}

              {filteredDirectory.length === 0 && (
                <div className="sm:col-span-2 xl:col-span-1 p-6 rounded-xl bg-[#11131B] border border-white/[0.06] text-center text-xs text-[#A1A1B2]">
                  No franchises match &ldquo;{filterQuery}&rdquo;.
                </div>
              )}
            </div>
          </aside>

          {/* Franchise Detail & Complete Watch Order Column:
              - On < xl: opens cleanly at the top when a universe is selected, with Back + Quick Switcher bar.
              - On >= xl: always visible alongside the directory sidebar. */}
          {displayFranchise && (
            <div
              className={`${
                hasExplicitSelection ? 'block' : 'hidden xl:block'
              } xl:col-span-8 space-y-6 min-w-0`}
            >
              {/* Mobile / Compact Back & Quick Universe Switcher Bar */}
              <div className="xl:hidden flex flex-wrap items-center justify-between gap-3">
                <Link
                  to="/franchises"
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#191C27] border border-white/10 text-xs font-medium text-[#F5F3FA] hover:border-[#A78BFA]/60 transition-colors whitespace-nowrap"
                >
                  <ArrowLeft className="w-3.5 h-3.5 text-[#A78BFA]" />
                  <span>All Universes ({franchises.length})</span>
                </Link>

                <select
                  aria-label="Switch franchise universe"
                  value={displayFranchise.id}
                  onChange={(e) => navigate(getFranchiseRoute(e.target.value))}
                  className="h-9 max-w-[230px] px-3 rounded-lg bg-[#11131B] border border-white/10 text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
                >
                  {franchises.map((f) => (
                    <option key={f.id} value={f.id} className="bg-[#11131B]">
                      {f.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Hero Header Card */}
              <div className="relative rounded-2xl overflow-hidden bg-[#11131B] border border-white/[0.08]">
                <div className="absolute inset-0">
                  <PosterImage
                    src={
                      displayFranchise.backdropUrl ||
                      displayFranchise.posterUrl ||
                      GENERATED_ASSETS.franchiseBanner
                    }
                    alt={displayFranchise.name}
                    variant="backdrop"
                    className="w-full h-full opacity-35"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#11131B] via-[#11131B]/85 to-[#08090D]/60" />
                </div>

                <div className="relative z-10 p-6 sm:p-7 space-y-5">
                  <div className="flex flex-col sm:flex-row gap-5 items-start">
                    {displayFranchise.posterUrl && (
                      <div className="w-24 sm:w-28 aspect-[2/3] rounded-xl overflow-hidden border border-white/15 shadow-2xl shrink-0">
                        <PosterImage
                          src={displayFranchise.posterUrl}
                          alt={displayFranchise.name}
                          className="w-full h-full"
                        />
                      </div>
                    )}

                    <div className="flex-1 min-w-0 space-y-2">
                      <p className="text-xs text-[#D6B477] font-medium">
                        {displayFranchise.orderAttribution} · {displayFranchise.originCountry} ·{' '}
                        {displayFranchise.mediaScope}
                      </p>
                      <h2 className="font-serif text-2xl sm:text-3xl font-semibold text-[#F5F3FA] leading-tight">
                        {displayFranchise.name}
                      </h2>
                      <p className="text-sm text-[#F5F3FA]/80 leading-relaxed">
                        {displayFranchise.description}
                      </p>
                    </div>
                  </div>

                  {/* Verified Franchise Count Strip (4 metrics) */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 border-t border-white/[0.08]">
                    <div className="p-3 rounded-xl bg-[#08090D]/55 border border-white/[0.06]">
                      <p className="text-[11px] text-[#A1A1B2]">Confirmed Movies</p>
                      <p className="mt-1 font-mono text-xl font-semibold tabular-nums text-[#F5F3FA]">
                        {displayFranchise.confirmedMovieCount}
                      </p>
                    </div>
                    <div className="p-3 rounded-xl bg-[#08090D]/55 border border-white/[0.06]">
                      <p className="text-[11px] text-[#A1A1B2]">Confirmed Series</p>
                      <p className="mt-1 font-mono text-xl font-semibold tabular-nums text-[#F5F3FA]">
                        {displayFranchise.confirmedSeriesCount}
                      </p>
                    </div>
                    <div className="p-3 rounded-xl bg-[#08090D]/55 border border-white/[0.06]">
                      <p className="text-[11px] text-[#A1A1B2]">Related Spin-offs</p>
                      <p className="mt-1 font-mono text-xl font-semibold tabular-nums text-[#F5F3FA]">
                        {displayFranchise.spinoffCount}
                      </p>
                    </div>
                    <div className="p-3 rounded-xl bg-[#08090D]/55 border border-white/[0.06]">
                      <p className="text-[11px] text-[#A1A1B2]">Prequels &amp; Sequels</p>
                      <p className="mt-1 font-mono text-xl font-semibold tabular-nums text-[#F5F3FA]">
                        {displayFranchise.prequelSequelCount}
                      </p>
                    </div>
                  </div>

                  {/* Related Companion Universe Links */}
                  {relatedFranchises.length > 0 && (
                    <div className="flex flex-wrap items-center gap-2.5 text-xs">
                      <span className="text-[#A1A1B2]">Connected Guides:</span>
                      {relatedFranchises.map((rel) => (
                        <Link
                          key={rel.id}
                          to={getFranchiseRoute(rel.id)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#191C27] border border-white/10 hover:border-[#A78BFA]/60 text-[#F5F3FA] transition-colors whitespace-nowrap"
                        >
                          <span>{rel.name}</span>
                          <ArrowRight className="w-3 h-3 text-[#A78BFA]" />
                        </Link>
                      ))}
                    </div>
                  )}

                  {/* Attribution + Disputed / Ambiguous Order Notes */}
                  <div className="space-y-2.5">
                    {displayFranchise.sourceNote && (
                      <div className="flex items-start gap-2.5 text-xs text-[#A1A1B2] bg-[#191C27]/70 border border-white/[0.06] rounded-lg p-3.5">
                        <Info className="w-4 h-4 text-[#D6B477] shrink-0 mt-0.5" aria-hidden="true" />
                        <span>{displayFranchise.sourceNote}</span>
                      </div>
                    )}

                    {displayFranchise.disputedOrderNote && (
                      <div className="flex items-start gap-2.5 text-xs text-[#F5F3FA]/85 bg-[#D6B477]/[0.07] border border-[#D6B477]/25 rounded-lg p-3.5">
                        <AlertTriangle
                          className="w-4 h-4 text-[#D6B477] shrink-0 mt-0.5"
                          aria-hidden="true"
                        />
                        <div>
                          <span className="font-semibold text-[#D6B477]">
                            Viewing Order Note:{' '}
                          </span>
                          <span>{displayFranchise.disputedOrderNote}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Personal Progress Bar + Resume Next Unwatched Button */}
                  <div className="rounded-xl bg-[#08090D]/60 border border-white/[0.06] p-4 space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                      <div className="space-y-0.5">
                        <p className="text-xs font-medium text-[#F5F3FA]">
                          Your Progress — {TAB_CONFIG.find((t) => t.key === activeTab)?.label}
                        </p>
                        <p className="text-xs text-[#A1A1B2] tabular-nums">
                          {completedInActiveTab} of {activeEntries.length} completed ({activePct}%) ·
                          Progress stays synchronized across all viewing orders
                        </p>
                      </div>

                      {nextUnwatchedEntry ? (
                        <button
                          type="button"
                          onClick={handleResumeNext}
                          className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold hover:bg-[#b89efc] transition-colors whitespace-nowrap shrink-0"
                        >
                          <Play className="w-3.5 h-3.5 fill-[#08090D]" />
                          <span>
                            Resume #{String(nextUnwatchedEntry.position).padStart(2, '0')}:{' '}
                            {nextUnwatchedEntry.title.length > 26
                              ? `${nextUnwatchedEntry.title.slice(0, 26)}…`
                              : nextUnwatchedEntry.title}
                          </span>
                        </button>
                      ) : activeEntries.length > 0 ? (
                        <span className="text-xs font-medium text-[#D6B477] whitespace-nowrap">
                          All entries completed
                        </span>
                      ) : null}
                    </div>

                    <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                      <div
                        className="h-full bg-[#A78BFA] rounded-full transition-all duration-300"
                        style={{ width: `${activePct}%` }}
                      />
                    </div>
                  </div>

                  {/* 6 Verified Viewing Order Tabs (only renders tabs with verified entries) */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-white/[0.06]">
                    {availableTabs.map((tab) => (
                      <button
                        key={tab.key}
                        type="button"
                        onClick={() => {
                          setActiveTab(tab.key);
                          setHighlightedKey(null);
                        }}
                        className={`px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-colors tabular-nums ${
                          activeTab === tab.key
                            ? 'bg-[#A78BFA] text-[#08090D]'
                            : 'bg-[#191C27] text-[#A1A1B2] hover:text-[#F5F3FA]'
                        }`}
                      >
                        {tab.label} ({tab.count})
                      </button>
                    ))}
                  </div>

                  {activeOrderNote && (
                    <p className="text-xs text-[#A1A1B2] leading-relaxed">{activeOrderNote}</p>
                  )}
                </div>
              </div>

              {/* Live Enrichment Subtle Indicator */}
              {loadingDetail && (
                <p className="text-xs text-[#A1A1B2] px-1">
                  Refreshing live posters, episode counts, and {region} streaming availability…
                </p>
              )}

              {/* Newly Detected Related Releases Banner */}
              {pendingReleasesForActive.length > 0 && (
                <div className="rounded-xl bg-[#11131B] border border-[#A78BFA]/35 p-4 sm:p-5 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[#D6B477]">
                        Live Catalog Radar
                      </p>
                      <p className="text-sm font-medium text-[#F5F3FA]">
                        {pendingReleasesForActive.length} new related{' '}
                        {pendingReleasesForActive.length === 1 ? 'release' : 'releases'} detected for this universe
                      </p>
                    </div>
                    <Link
                      to="/updates"
                      className="text-xs text-[#A78BFA] hover:underline whitespace-nowrap"
                    >
                      View all updates →
                    </Link>
                  </div>

                  <div className="space-y-2">
                    {pendingReleasesForActive.map((rel) => (
                      <div
                        key={`pending_${rel.titleKey}`}
                        className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg bg-[#08090D]/70 border border-white/[0.06]"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <PosterImage
                            src={rel.posterUrl}
                            alt={rel.title}
                            className="w-9 h-13 rounded shrink-0"
                          />
                          <div className="min-w-0">
                            <Link
                              to={getTitleRoute(rel)}
                              className="text-sm font-medium text-[#F5F3FA] hover:text-[#A78BFA] truncate block"
                            >
                              {rel.title}
                            </Link>
                            <p className="text-xs text-[#A1A1B2] tabular-nums truncate">
                              {rel.releaseDate || rel.releaseYear || 'TBA'} ·{' '}
                              {rel.detectedFranchise?.matchReason}
                            </p>
                          </div>
                        </div>

                        {isAdmin ? (
                          <button
                            type="button"
                            disabled={addingUpdateKey === rel.titleKey}
                            onClick={() => handleAddDetectedRelease(rel)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold hover:bg-[#b89efc] disabled:opacity-50 whitespace-nowrap shrink-0"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>
                              {addingUpdateKey === rel.titleKey ? 'Adding…' : 'Add to Watch Order'}
                            </span>
                          </button>
                        ) : (
                          <Link
                            to={getTitleRoute(rel)}
                            className="text-xs text-[#A78BFA] hover:underline whitespace-nowrap shrink-0"
                          >
                            View Title →
                          </Link>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Ordered Entries List */}
              <div className="space-y-3">
                {activeEntries.map((entry) => (
                  <FranchiseEntryRow
                    key={`${displayFranchise.id}_${activeTab}_${entry.position}_${entry.titleKey}`}
                    entry={entry}
                    originCountry={displayFranchise.originCountry}
                    region={region}
                    isHighlighted={
                      highlightedKey === entry.titleKey ||
                      (!highlightedKey && nextUnwatchedEntry?.titleKey === entry.titleKey)
                    }
                    autoExpandEpisodes={autoExpandKey === entry.titleKey}
                    rowRef={(el) => {
                      rowRefs.current[entry.titleKey] = el;
                    }}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
