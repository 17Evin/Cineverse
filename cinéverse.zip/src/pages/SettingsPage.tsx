import React, { useEffect, useState } from 'react';
import { LogIn, LogOut, Save, ShieldCheck } from 'lucide-react';
import {
  GLOBAL_COUNTRIES,
  GLOBAL_GENRES,
  LANGUAGES_LIST,
  STREAMING_REGIONS,
} from '../constants/catalog';
import { useUserData } from '../context/UserDataContext';

export function SettingsPage() {
  const {
    user,
    profile,
    preferredRegion,
    setGuestRegion,
    signInWithGoogle,
    signOutUser,
    updateProfilePreferences,
  } = useUserData();

  const [displayName, setDisplayName] = useState('');
  const [region, setRegion] = useState(preferredRegion || 'IN');
  const [language, setLanguage] = useState('en');
  const [favoriteGenres, setFavoriteGenres] = useState<string[]>([]);
  const [preferredCountries, setPreferredCountries] = useState<string[]>([]);
  const [excludeCompletedRecs, setExcludeCompletedRecs] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (profile) {
      setDisplayName(profile.displayName || '');
      setRegion(profile.preferredRegion || 'IN');
      setLanguage(profile.preferredLanguage || 'en');
      setFavoriteGenres(profile.favoriteGenres || []);
      setPreferredCountries(profile.preferredCountries || []);
      setExcludeCompletedRecs(profile.excludeCompletedRecs ?? true);
    } else {
      setRegion(preferredRegion || 'IN');
    }
  }, [profile, preferredRegion]);

  const toggleItem = (list: string[], value: string, max: number) => {
    if (list.includes(value)) return list.filter((x) => x !== value);
    if (list.length >= max) return list;
    return [...list, value];
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setGuestRegion(region);
      return;
    }
    setSaving(true);
    try {
      await updateProfilePreferences({
        displayName,
        preferredRegion: region,
        preferredLanguage: language,
        favoriteGenres,
        preferredCountries,
        excludeCompletedRecs,
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-3xl space-y-8">
      <div className="pb-4 border-b border-white/[0.06]">
        <p className="text-xs font-medium tracking-[0.16em] uppercase text-[#D6B477] mb-1">
          Account & Personalization
        </p>
        <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#F5F3FA]">
          Profile & Settings
        </h1>
        <p className="mt-1.5 text-sm text-[#A1A1B2]">
          Manage your streaming region, favorite genres, preferred countries, and account session.
        </p>
      </div>

      {/* Authentication Card */}
      <section className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {user ? (
          <>
            <div className="flex items-center gap-4 min-w-0">
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={profile?.displayName || 'Profile'}
                  referrerPolicy="no-referrer"
                  className="w-14 h-14 rounded-full object-cover border border-white/15 shrink-0"
                />
              ) : (
                <div className="w-14 h-14 rounded-full bg-[#A78BFA]/20 text-[#A78BFA] font-serif text-xl font-semibold flex items-center justify-center shrink-0">
                  {(profile?.displayName || user.displayName || 'C')[0].toUpperCase()}
                </div>
              )}
              <div className="min-w-0">
                <p className="text-base font-semibold text-[#F5F3FA] truncate">
                  {profile?.displayName || user.displayName || 'CINÉVERSE Member'}
                </p>
                <p className="text-xs text-[#A1A1B2] truncate">{user.email}</p>
                <p className="mt-1 inline-flex items-center gap-1 text-[11px] text-[#D6B477]">
                  <ShieldCheck className="w-3.5 h-3.5" aria-hidden="true" />
                  <span>Cloud sync active · Private account isolation</span>
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={signOutUser}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#191C27] border border-white/10 text-xs font-medium text-[#F5F3FA] hover:border-red-500/40 hover:text-red-300 transition-colors self-start sm:self-auto whitespace-nowrap"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out</span>
            </button>
          </>
        ) : (
          <>
            <div>
              <h2 className="font-serif text-xl font-semibold text-[#F5F3FA]">Sign In to CINÉVERSE</h2>
              <p className="text-xs text-[#A1A1B2] mt-1">
                Browse public entertainment metadata freely, or sign in with Google to synchronize your watchlist, episodes, collections, and statistics.
              </p>
            </div>
            <button
              type="button"
              onClick={signInWithGoogle}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-sm font-semibold hover:bg-[#b89efc] whitespace-nowrap self-start sm:self-auto"
            >
              <LogIn className="w-4 h-4" />
              <span>Sign In with Google</span>
            </button>
          </>
        )}
      </section>

      {/* Preferences Form */}
      <form
        onSubmit={handleSave}
        className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-6 space-y-6"
      >
        <h2 className="font-serif text-xl font-semibold text-[#F5F3FA]">
          Regional & Recommendation Preferences
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {user && (
            <div>
              <label htmlFor="pref-name" className="block text-xs text-[#A1A1B2] mb-1.5">
                Display Name
              </label>
              <input
                id="pref-name"
                type="text"
                maxLength={100}
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full h-10 px-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-sm text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
              />
            </div>
          )}

          <div>
            <label htmlFor="pref-region" className="block text-xs text-[#A1A1B2] mb-1.5">
              Default Streaming Region (Initial default: India)
            </label>
            <select
              id="pref-region"
              value={region}
              onChange={(e) => {
                setRegion(e.target.value);
                if (!user) setGuestRegion(e.target.value);
              }}
              className="w-full h-10 px-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-sm text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
            >
              {STREAMING_REGIONS.map((r) => (
                <option key={r.code} value={r.code}>
                  {r.name} ({r.code})
                </option>
              ))}
            </select>
          </div>

          {user && (
            <div>
              <label htmlFor="pref-lang" className="block text-xs text-[#A1A1B2] mb-1.5">
                Preferred Original Language
              </label>
              <select
                id="pref-lang"
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="w-full h-10 px-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-sm text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
              >
                {LANGUAGES_LIST.map((l) => (
                  <option key={l.code} value={l.code}>
                    {l.name}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {user && (
          <>
            <div className="space-y-2.5">
              <p className="text-xs text-[#A1A1B2]">
                Favorite Genres ({favoriteGenres.length}/12 selected — shapes personalized recommendations)
              </p>
              <div className="flex flex-wrap gap-2">
                {GLOBAL_GENRES.map((g) => {
                  const active = favoriteGenres.includes(g);
                  return (
                    <button
                      key={g}
                      type="button"
                      onClick={() => setFavoriteGenres((prev) => toggleItem(prev, g, 12))}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                        active
                          ? 'bg-[#A78BFA] text-[#08090D] border-[#A78BFA]'
                          : 'bg-[#191C27] text-[#A1A1B2] border-white/[0.08] hover:text-[#F5F3FA]'
                      }`}
                    >
                      {g}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-2.5">
              <p className="text-xs text-[#A1A1B2]">
                Preferred Production Countries ({preferredCountries.length}/12 selected)
              </p>
              <div className="flex flex-wrap gap-2">
                {GLOBAL_COUNTRIES.map((c) => {
                  const active = preferredCountries.includes(c.code);
                  return (
                    <button
                      key={c.code}
                      type="button"
                      onClick={() => setPreferredCountries((prev) => toggleItem(prev, c.code, 12))}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
                        active
                          ? 'bg-[#D6B477] text-[#08090D] border-[#D6B477]'
                          : 'bg-[#191C27] text-[#A1A1B2] border-white/[0.08] hover:text-[#F5F3FA]'
                      }`}
                    >
                      {c.name}
                    </button>
                  );
                })}
              </div>
            </div>

            <label className="flex items-center gap-3 text-sm text-[#F5F3FA] cursor-pointer">
              <input
                type="checkbox"
                checked={excludeCompletedRecs}
                onChange={(e) => setExcludeCompletedRecs(e.target.checked)}
                className="w-4 h-4 accent-[#A78BFA] rounded"
              />
              <span>Exclude titles I have already completed or dropped from personalized recommendations</span>
            </label>

            <div className="pt-2">
              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-sm font-semibold hover:bg-[#b89efc] transition-colors disabled:opacity-50"
              >
                <Save className="w-4 h-4" />
                <span>{saving ? 'Saving...' : 'Save Preferences'}</span>
              </button>
            </div>
          </>
        )}
      </form>
    </div>
  );
}
