import { Link } from 'react-router-dom';
import { ArrowRight, LogIn, PlayCircle } from 'lucide-react';
import { useUserData } from '../context/UserDataContext';
import { PosterImage } from '../components/PosterImage';

export function ContinueWatchingPage() {
  const { user, libraryList, signInWithGoogle } = useUserData();

  if (!user) {
    return (
      <div className="max-w-lg mx-auto my-12 rounded-2xl bg-[#11131B] border border-white/[0.08] p-8 sm:p-10 text-center space-y-4">
        <PlayCircle className="w-8 h-8 text-[#A78BFA] mx-auto" />
        <h1 className="font-serif text-2xl sm:text-3xl font-semibold text-[#F5F3FA]">
          Continue Watching
        </h1>
        <p className="text-sm text-[#A1A1B2] leading-relaxed">
          Sign in to track individual episodes and jump back into every series or anime in progress.
        </p>
        <button
          type="button"
          onClick={signInWithGoogle}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-sm font-semibold hover:bg-[#b89efc]"
        >
          <LogIn className="w-4 h-4" />
          <span>Sign In with Google</span>
        </button>
      </div>
    );
  }

  const activeItems = libraryList
    .filter((item) => item.status === 'watching')
    .sort((a, b) => (b.completedEpisodesCount || 0) - (a.completedEpisodesCount || 0));

  return (
    <div className="space-y-7">
      <div className="pb-4 border-b border-white/[0.06]">
        <p className="text-xs font-medium tracking-[0.16em] uppercase text-[#D6B477] mb-1">
          In Progress
        </p>
        <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#F5F3FA]">
          Continue Watching
        </h1>
        <p className="mt-1.5 text-sm text-[#A1A1B2]">
          Resume any series, drama, or anime and check off your next released episode.
        </p>
      </div>

      {activeItems.length === 0 ? (
        <div className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-12 text-center space-y-3">
          <h2 className="font-serif text-xl text-[#F5F3FA]">Nothing currently in progress</h2>
          <p className="text-sm text-[#A1A1B2] max-w-md mx-auto">
            Mark any title as &ldquo;Currently Watching&rdquo; or check off an episode to see your active progress here.
          </p>
          <Link
            to="/series"
            className="inline-block mt-2 px-5 py-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold hover:bg-[#b89efc]"
          >
            Explore Series & Dramas
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {activeItems.map((item) => {
            const total = item.totalReleasedEpisodes || 0;
            const done = item.completedEpisodesCount || 0;
            const remaining = Math.max(0, total - done);
            const pct = total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0;
            const detailUrl = `/title/${item.source}/${item.mediaType}/${item.externalId}`;

            return (
              <Link
                key={item.titleKey}
                to={detailUrl}
                className="group flex gap-5 p-5 rounded-2xl bg-[#11131B] border border-white/[0.06] hover:border-[#A78BFA]/50 transition-colors"
              >
                <PosterImage
                  src={item.posterUrl}
                  alt={item.title}
                  className="w-24 aspect-[2/3] rounded-xl shrink-0 border border-white/10"
                />
                <div className="flex-1 min-w-0 flex flex-col justify-between">
                  <div>
                    <p className="text-xs text-[#D6B477]">
                      {item.country} · {item.mediaType === 'anime' ? 'Anime' : item.mediaType === 'movie' ? 'Film' : 'Series'}
                    </p>
                    <h2 className="mt-1 font-serif text-xl font-semibold text-[#F5F3FA] group-hover:text-[#A78BFA] transition-colors truncate">
                      {item.title}
                    </h2>
                    <p className="mt-1.5 text-xs text-[#A1A1B2] truncate">
                      {item.lastWatchedEpisodeCode
                        ? `Last watched: ${item.lastWatchedEpisodeCode}${item.lastWatchedEpisodeName ? ` — ${item.lastWatchedEpisodeName}` : ''}`
                        : 'Ready to begin Episode 1'}
                    </p>
                  </div>

                  <div className="space-y-2 mt-4">
                    <div className="flex items-center justify-between text-xs font-mono tabular-nums">
                      <span className="text-[#F5F3FA]">
                        {done} / {total || '?'} released watched
                      </span>
                      <span className="text-[#A78BFA]">{pct}%</span>
                    </div>
                    <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                      <div
                        className="h-full bg-[#A78BFA] rounded-full transition-all duration-300"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-xs text-[#A1A1B2] pt-1">
                      <span className="tabular-nums">
                        {total > 0 ? `${remaining} remaining` : 'Open to load episodes'}
                      </span>
                      <span className="inline-flex items-center gap-1 text-[#A78BFA] font-medium">
                        Resume <ArrowRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
