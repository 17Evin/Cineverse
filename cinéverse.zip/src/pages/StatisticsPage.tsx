import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { BarChart3, LogIn } from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useUserData } from '../context/UserDataContext';

export function StatisticsPage() {
  const { user, libraryList, episodeList, signInWithGoogle } = useUserData();

  const stats = useMemo(() => {
    const completedTitles = libraryList.filter((t) => t.status === 'completed');
    const moviesCompleted = completedTitles.filter((t) => t.mediaType === 'movie');
    const seriesCompleted = completedTitles.filter((t) => t.mediaType === 'tv');
    const animeCompleted = completedTitles.filter((t) => t.mediaType === 'anime');

    // Only count explicitly watched episodes + completed movies
    const totalEpisodesCompleted = episodeList.length;
    const episodeMinutes = episodeList.reduce((acc, ep) => acc + (ep.runtimeMinutes || 0), 0);
    const movieMinutes = moviesCompleted.reduce((acc, m) => acc + (m.runtimeMinutes || 0), 0);
    const estimatedWatchHours = Math.round(((episodeMinutes + movieMinutes) / 60) * 10) / 10;

    // Country, language, genre counts from tracked completed/watching titles
    const activeTitles = libraryList.filter(
      (t) => t.status === 'completed' || t.status === 'watching'
    );
    const countryCounts = new Map<string, number>();
    const languageCounts = new Map<string, number>();
    const genreCounts = new Map<string, number>();

    for (const item of activeTitles) {
      if (item.country) {
        countryCounts.set(item.country, (countryCounts.get(item.country) || 0) + 1);
      }
      if (item.language) {
        languageCounts.set(item.language, (languageCounts.get(item.language) || 0) + 1);
      }
      for (const g of item.genres || []) {
        genreCounts.set(g, (genreCounts.get(g) || 0) + 1);
      }
    }

    const topOf = (map: Map<string, number>) => {
      const sorted = Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
      return sorted[0]?.[0] || 'No data yet';
    };

    // Monthly activity (last 6 months + any recorded months)
    const monthCounts = new Map<string, number>();
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      monthCounts.set(key, 0);
    }
    for (const ep of episodeList) {
      if (ep.watchedMonth) {
        monthCounts.set(ep.watchedMonth, (monthCounts.get(ep.watchedMonth) || 0) + 1);
      }
    }
    const monthlyActivity = Array.from(monthCounts.entries())
      .sort((a, b) => a[0].localeCompare(b[0]))
      .slice(-12)
      .map(([month, episodes]) => ({ month, episodes }));

    // Yearly activity
    const yearCounts = new Map<number, number>();
    for (const ep of episodeList) {
      if (ep.watchedYear) {
        yearCounts.set(ep.watchedYear, (yearCounts.get(ep.watchedYear) || 0) + 1);
      }
    }
    const yearlyActivity = Array.from(yearCounts.entries())
      .sort((a, b) => b[0] - a[0])
      .map(([year, episodes]) => ({ year, episodes }));

    const topGenres = Array.from(genreCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([name, count]) => ({ name, count }));

    const topCountries = Array.from(countryCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([name, count]) => ({ name, count }));

    const completionHistory = [...completedTitles].sort((a, b) =>
      (b.completedAt || '').localeCompare(a.completedAt || '')
    );

    return {
      moviesCompleted: moviesCompleted.length,
      episodesCompleted: totalEpisodesCompleted,
      seriesCompleted: seriesCompleted.length,
      animeCompleted: animeCompleted.length,
      estimatedWatchHours,
      mostWatchedCountry: topOf(countryCounts),
      mostWatchedLanguage: topOf(languageCounts),
      favoriteGenre: topOf(genreCounts),
      monthlyActivity,
      yearlyActivity,
      topGenres,
      topCountries,
      completionHistory,
    };
  }, [libraryList, episodeList]);

  if (!user) {
    return (
      <div className="max-w-lg mx-auto my-12 rounded-2xl bg-[#11131B] border border-white/[0.08] p-8 sm:p-10 text-center space-y-4">
        <BarChart3 className="w-8 h-8 text-[#A78BFA] mx-auto" />
        <h1 className="font-serif text-2xl sm:text-3xl font-semibold text-[#F5F3FA]">
          Personal Watching Statistics
        </h1>
        <p className="text-sm text-[#A1A1B2] leading-relaxed">
          Sign in to visualize your completed movies, tracked episodes, watch hours, favorite countries, languages, and monthly viewing history.
        </p>
        <button
          type="button"
          onClick={signInWithGoogle}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-sm font-semibold hover:bg-[#b89efc]"
        >
          <LogIn className="w-4 h-4" />
          <span>Sign In with Google</span>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="pb-4 border-b border-white/[0.06]">
        <p className="text-xs font-medium tracking-[0.16em] uppercase text-[#D6B477] mb-1">
          Viewing Analytics
        </p>
        <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#F5F3FA]">
          Personal Statistics
        </h1>
        <p className="mt-1.5 text-sm text-[#A1A1B2]">
          Computed exclusively from your confirmed completed movies and individually checked episodes. Unwatched and unreleased episodes are never counted.
        </p>
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        {[
          { label: 'Episodes Completed', value: stats.episodesCompleted.toLocaleString() },
          { label: 'Movies Completed', value: stats.moviesCompleted.toLocaleString() },
          { label: 'Series Completed', value: stats.seriesCompleted.toLocaleString() },
          { label: 'Anime Completed', value: stats.animeCompleted.toLocaleString() },
          { label: 'Estimated Watch Hours', value: `${stats.estimatedWatchHours.toLocaleString()} h` },
        ].map((kpi) => (
          <div
            key={kpi.label}
            className="p-5 rounded-xl bg-[#11131B] border border-white/[0.06]"
          >
            <p className="text-xs text-[#A1A1B2]">{kpi.label}</p>
            <p className="mt-2 font-mono tabular-nums text-2xl sm:text-3xl font-semibold text-[#F5F3FA]">
              {kpi.value}
            </p>
          </div>
        ))}
      </div>

      {/* Taste Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-xl bg-[#11131B] border border-white/[0.06]">
          <p className="text-xs text-[#A1A1B2]">Most Watched Country</p>
          <p className="mt-1.5 font-serif text-2xl font-semibold text-[#D6B477]">
            {stats.mostWatchedCountry}
          </p>
        </div>
        <div className="p-5 rounded-xl bg-[#11131B] border border-white/[0.06]">
          <p className="text-xs text-[#A1A1B2]">Most Watched Language</p>
          <p className="mt-1.5 font-serif text-2xl font-semibold text-[#F5F3FA]">
            {stats.mostWatchedLanguage}
          </p>
        </div>
        <div className="p-5 rounded-xl bg-[#11131B] border border-white/[0.06]">
          <p className="text-xs text-[#A1A1B2]">Favorite Genre</p>
          <p className="mt-1.5 font-serif text-2xl font-semibold text-[#A78BFA]">
            {stats.favoriteGenre}
          </p>
        </div>
      </div>

      {/* Monthly Episode Activity Chart + Yearly Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 rounded-2xl bg-[#11131B] border border-white/[0.06] p-6 space-y-4">
          <div>
            <h2 className="font-serif text-xl font-semibold text-[#F5F3FA]">Monthly Episode Activity</h2>
            <p className="text-xs text-[#A1A1B2] mt-0.5">
              Number of episodes marked watched per calendar month
            </p>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.monthlyActivity} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" vertical={false} />
                <XAxis dataKey="month" stroke="#A1A1B2" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="#A1A1B2" fontSize={11} tickLine={false} axisLine={false} allowDecimals={false} />
                <Tooltip
                  cursor={{ fill: 'rgba(167,139,250,0.08)' }}
                  contentStyle={{
                    backgroundColor: '#191C27',
                    border: '1px solid rgba(255,255,255,0.12)',
                    borderRadius: '8px',
                    color: '#F5F3FA',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="episodes" name="Episodes" fill="#A78BFA" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-4 rounded-2xl bg-[#11131B] border border-white/[0.06] p-6 space-y-5">
          <div>
            <h2 className="font-serif text-xl font-semibold text-[#F5F3FA]">Yearly Activity</h2>
            <p className="text-xs text-[#A1A1B2] mt-0.5">Episodes logged by year</p>
          </div>
          {stats.yearlyActivity.length === 0 ? (
            <p className="text-xs text-[#A1A1B2]">
              Check off your first watched episode to start recording yearly history.
            </p>
          ) : (
            <div className="space-y-3">
              {stats.yearlyActivity.map((row) => (
                <div
                  key={row.year}
                  className="flex items-center justify-between py-2 border-b border-white/[0.06] text-sm"
                >
                  <span className="font-mono tabular-nums text-[#F5F3FA]">{row.year}</span>
                  <span className="font-mono tabular-nums text-[#D6B477]">
                    {row.episodes} episode{row.episodes === 1 ? '' : 's'}
                  </span>
                </div>
              ))}
            </div>
          )}

          {stats.topGenres.length > 0 && (
            <div className="pt-2 space-y-2.5">
              <h3 className="text-xs font-medium uppercase tracking-wider text-[#A1A1B2]">
                Top Genres
              </h3>
              {stats.topGenres.map((g) => (
                <div key={g.name} className="flex items-center justify-between text-xs">
                  <span className="text-[#F5F3FA]">{g.name}</span>
                  <span className="font-mono tabular-nums text-[#A1A1B2]">{g.count}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Completion History Table */}
      <section className="rounded-2xl bg-[#11131B] border border-white/[0.06] overflow-hidden">
        <div className="p-6 border-b border-white/[0.06]">
          <h2 className="font-serif text-xl font-semibold text-[#F5F3FA]">Completion History</h2>
          <p className="text-xs text-[#A1A1B2] mt-0.5">
            Completed films, television series, dramas, and anime
          </p>
        </div>

        {stats.completionHistory.length === 0 ? (
          <div className="p-10 text-center text-sm text-[#A1A1B2]">
            No completed titles recorded yet.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-white/[0.06] text-[#A1A1B2] text-xs">
                  <th className="py-3 px-6 font-medium">Title</th>
                  <th className="py-3 px-4 font-medium">Type</th>
                  <th className="py-3 px-4 font-medium">Country</th>
                  <th className="py-3 px-4 font-medium text-right">Rating</th>
                  <th className="py-3 px-6 font-medium text-right">Completed</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.06]">
                {stats.completionHistory.map((item) => (
                  <tr key={item.titleKey} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3.5 px-6 font-medium text-[#F5F3FA]">
                      <Link
                        to={`/title/${item.source}/${item.mediaType}/${item.externalId}`}
                        className="hover:text-[#A78BFA] transition-colors"
                      >
                        {item.title}
                      </Link>
                    </td>
                    <td className="py-3.5 px-4 text-[#A1A1B2] capitalize">{item.mediaType}</td>
                    <td className="py-3.5 px-4 text-[#A1A1B2]">{item.country}</td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums text-[#D6B477]">
                      {item.personalRating > 0 ? `${item.personalRating}/10` : '—'}
                    </td>
                    <td className="py-3.5 px-6 text-right font-mono tabular-nums text-[#A1A1B2]">
                      {item.completedAt || '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
