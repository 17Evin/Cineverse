import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Bookmark, Heart, LogIn, Star, Trash2 } from 'lucide-react';
import type { UserTitleRecord, WatchStatus } from '../types/media';
import { WATCH_STATUS_LABELS } from '../constants/catalog';
import { useUserData } from '../context/UserDataContext';
import { PosterImage } from '../components/PosterImage';
import { ConfirmDialog } from '../components/ConfirmDialog';

type LibraryTab = 'all' | WatchStatus | 'favorites';

const TABS: { id: LibraryTab; label: string }[] = [
  { id: 'all', label: 'All Titles' },
  { id: 'want_to_watch', label: 'Want to Watch' },
  { id: 'watching', label: 'Currently Watching' },
  { id: 'completed', label: 'Completed' },
  { id: 'on_hold', label: 'On Hold' },
  { id: 'dropped', label: 'Dropped' },
  { id: 'favorites', label: 'Favorites' },
];

export function WatchlistPage() {
  const { user, libraryList, signInWithGoogle, upsertTitleStatus, removeTitleFromLibrary } =
    useUserData();
  const [activeTab, setActiveTab] = useState<LibraryTab>('all');
  const [pendingDelete, setPendingDelete] = useState<UserTitleRecord | null>(null);

  const filtered = useMemo(() => {
    return libraryList
      .filter((item) => {
        if (activeTab === 'all') return true;
        if (activeTab === 'favorites') return item.isFavorite;
        return item.status === activeTab;
      })
      .sort((a, b) => a.title.localeCompare(b.title));
  }, [libraryList, activeTab]);

  if (!user) {
    return (
      <div className="max-w-lg mx-auto my-12 rounded-2xl bg-[#11131B] border border-white/[0.08] p-8 sm:p-10 text-center space-y-4">
        <Bookmark className="w-8 h-8 text-[#D6B477] mx-auto" />
        <h1 className="font-serif text-2xl sm:text-3xl font-semibold text-[#F5F3FA]">
          Your Personal Watchlist
        </h1>
        <p className="text-sm text-[#A1A1B2] leading-relaxed">
          Sign in to organize movies, series, dramas, and anime across Want to Watch, Currently Watching, Completed, On Hold, Dropped, and Favorites.
        </p>
        <button
          type="button"
          onClick={signInWithGoogle}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-sm font-semibold hover:bg-[#b89efc] transition-colors"
        >
          <LogIn className="w-4 h-4" />
          <span>Sign In with Google</span>
        </button>
      </div>
    );
  }

  const countFor = (tab: LibraryTab) => {
    if (tab === 'all') return libraryList.length;
    if (tab === 'favorites') return libraryList.filter((i) => i.isFavorite).length;
    return libraryList.filter((i) => i.status === tab).length;
  };

  return (
    <div className="space-y-7">
      <div className="pb-4 border-b border-white/[0.06]">
        <p className="text-xs font-medium tracking-[0.16em] uppercase text-[#D6B477] mb-1">
          Personal Library
        </p>
        <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#F5F3FA]">
          My Watchlist
        </h1>
        <p className="mt-1.5 text-sm text-[#A1A1B2] tabular-nums">
          {libraryList.length} saved title{libraryList.length === 1 ? '' : 's'} synchronized with your account
        </p>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
        {TABS.map((tab) => {
          const active = tab.id === activeTab;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-colors border ${
                active
                  ? 'bg-[#A78BFA] text-[#08090D] border-[#A78BFA]'
                  : 'bg-[#11131B] text-[#A1A1B2] border-white/[0.06] hover:text-[#F5F3FA]'
              }`}
            >
              {tab.label}
              <span
                className={`ml-1.5 font-mono tabular-nums ${
                  active ? 'text-[#08090D]/80' : 'text-[#A1A1B2]/75'
                }`}
              >
                {countFor(tab.id)}
              </span>
            </button>
          );
        })}
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-12 text-center space-y-3">
          <h2 className="font-serif text-xl text-[#F5F3FA]">No titles in this section yet</h2>
          <p className="text-sm text-[#A1A1B2] max-w-md mx-auto">
            Explore global series, dramas, films, and anime to start building your library.
          </p>
          <Link
            to="/discover"
            className="inline-block mt-2 px-5 py-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold hover:bg-[#b89efc]"
          >
            Browse Global Discovery
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filtered.map((item) => {
            const pct =
              item.totalReleasedEpisodes > 0
                ? Math.min(100, Math.round((item.completedEpisodesCount / item.totalReleasedEpisodes) * 100))
                : 0;
            const detailUrl = `/title/${item.source}/${item.mediaType}/${item.externalId}`;

            return (
              <article
                key={item.titleKey}
                className="flex gap-4 p-4 rounded-xl bg-[#11131B] border border-white/[0.06] hover:border-white/15 transition-colors"
              >
                <Link
                  to={detailUrl}
                  className="w-20 sm:w-24 aspect-[2/3] rounded-lg overflow-hidden shrink-0 border border-white/10"
                >
                  <PosterImage src={item.posterUrl} alt={item.title} className="w-full h-full" />
                </Link>

                <div className="flex-1 min-w-0 flex flex-col justify-between gap-3">
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <Link
                        to={detailUrl}
                        className="text-base font-medium text-[#F5F3FA] hover:text-[#A78BFA] transition-colors line-clamp-1"
                      >
                        {item.title}
                      </Link>
                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() =>
                            upsertTitleStatus(
                              {
                                ...item,
                                synopsis: '',
                                backdropUrl: null,
                                releaseDate: null,
                                countryCode: '',
                                rating: null,
                                voteCount: null,
                                popularity: null,
                                status: null,
                                totalSeasons: null,
                                totalEpisodes: item.totalReleasedEpisodes,
                                sourceAttribution: item.source,
                                fetchedAt: '',
                              },
                              { isFavorite: !item.isFavorite }
                            )
                          }
                          aria-label="Toggle favorite"
                          className={`p-1.5 rounded-lg transition-colors ${
                            item.isFavorite ? 'text-[#D6B477]' : 'text-[#A1A1B2] hover:text-[#F5F3FA]'
                          }`}
                        >
                          <Heart className={`w-4 h-4 ${item.isFavorite ? 'fill-[#D6B477]' : ''}`} />
                        </button>
                        <button
                          type="button"
                          onClick={() => setPendingDelete(item)}
                          aria-label={`Remove ${item.title}`}
                          className="p-1.5 rounded-lg text-[#A1A1B2] hover:text-red-400 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <p className="text-xs text-[#A1A1B2] mt-0.5 tabular-nums truncate">
                      {item.releaseYear || 'TBA'} · {item.country} ·{' '}
                      {item.mediaType === 'movie' ? 'Film' : item.mediaType === 'anime' ? 'Anime' : 'Series'}
                      {item.personalRating > 0 && (
                        <span className="text-[#D6B477] font-mono ml-1.5 inline-flex items-center gap-0.5">
                          · <Star className="w-3 h-3 fill-[#D6B477] inline" /> {item.personalRating}/10
                        </span>
                      )}
                    </p>

                    {item.notes && (
                      <p className="mt-2 text-xs text-[#A1A1B2]/90 line-clamp-2 italic">
                        &ldquo;{item.notes}&rdquo;
                      </p>
                    )}
                  </div>

                  <div className="space-y-2.5">
                    {item.totalReleasedEpisodes > 0 && (
                      <div className="space-y-1">
                        <div className="flex justify-between text-[11px] font-mono tabular-nums text-[#A1A1B2]">
                          <span>
                            {item.completedEpisodesCount} / {item.totalReleasedEpisodes} episodes
                          </span>
                          <span className="text-[#A78BFA]">{pct}%</span>
                        </div>
                        <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                          <div className="h-full bg-[#A78BFA] rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    )}

                    <div className="flex items-center justify-between gap-2">
                      <select
                        aria-label={`Status for ${item.title}`}
                        value={item.status}
                        onChange={(e) =>
                          upsertTitleStatus(
                            {
                              ...item,
                              synopsis: '',
                              backdropUrl: null,
                              releaseDate: null,
                              countryCode: '',
                              rating: null,
                              voteCount: null,
                              popularity: null,
                              status: null,
                              totalSeasons: null,
                              totalEpisodes: item.totalReleasedEpisodes,
                              sourceAttribution: item.source,
                              fetchedAt: '',
                            },
                            { status: e.target.value as WatchStatus }
                          )
                        }
                        className="h-8 px-2.5 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
                      >
                        {Object.entries(WATCH_STATUS_LABELS).map(([val, label]) => (
                          <option key={val} value={val}>
                            {label}
                          </option>
                        ))}
                      </select>

                      <Link
                        to={detailUrl}
                        className="text-xs font-medium text-[#A78BFA] hover:text-[#c4b0ff] whitespace-nowrap"
                      >
                        Open tracker
                      </Link>
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Remove title from library?"
        description={
          pendingDelete
            ? `Remove "${pendingDelete.title}" from your personal watchlist?`
            : ''
        }
        confirmLabel="Remove"
        destructive
        onCancel={() => setPendingDelete(null)}
        onConfirm={async () => {
          if (pendingDelete) {
            await removeTitleFromLibrary(pendingDelete.titleKey);
          }
          setPendingDelete(null);
        }}
      />
    </div>
  );
}
