import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  Bookmark,
  Calendar,
  Check,
  CheckCircle2,
  Clock,
  ExternalLink,
  FolderPlus,
  Heart,
  Layers,
  Lock,
  Play,
  Star,
  Trash2,
  Tv,
  User,
} from 'lucide-react';
import type { EpisodeItem, MediaDetail, MediaType, MetadataSource, WatchStatus } from '../types/media';
import { GENERATED_ASSETS, STREAMING_REGIONS, WATCH_STATUS_LABELS } from '../constants/catalog';
import { getTitleDetailApi, getTitleRoute } from '../services/api';
import { useUserData } from '../context/UserDataContext';
import { PosterImage } from '../components/PosterImage';
import { MediaRow } from '../components/MediaRow';
import { ConfirmDialog } from '../components/ConfirmDialog';

function formatCode(ep: EpisodeItem): string {
  if (ep.isSpecial) return `SP${String(ep.episodeNumber).padStart(2, '0')}`;
  return `S${String(ep.seasonNumber).padStart(2, '0')}E${String(ep.episodeNumber).padStart(2, '0')}`;
}

export function TitleDetailPage() {
  const { source, mediaType, externalId } = useParams<{
    source: MetadataSource;
    mediaType: MediaType;
    externalId: string;
  }>();

  const {
    user,
    preferredRegion,
    setGuestRegion,
    library,
    episodeProgress,
    collections,
    upsertTitleStatus,
    removeTitleFromLibrary,
    toggleEpisodeWatched,
    markSeasonWatched,
    toggleTitleInCollection,
    signInWithGoogle,
  } = useUserData();

  const [region, setRegion] = useState(preferredRegion || 'IN');
  const [detail, setDetail] = useState<MediaDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedSeasonNum, setSelectedSeasonNum] = useState<number>(1);
  const [showTrailer, setShowTrailer] = useState(false);
  const [confirmRemove, setConfirmRemove] = useState(false);
  const [notesDraft, setNotesDraft] = useState('');
  const [startedDraft, setStartedDraft] = useState('');
  const [completedDraft, setCompletedDraft] = useState('');
  const [showCollectionMenu, setShowCollectionMenu] = useState(false);

  useEffect(() => {
    setRegion(preferredRegion || 'IN');
  }, [preferredRegion]);

  useEffect(() => {
    if (!source || !mediaType || !externalId) return;
    const controller = new AbortController();
    setLoading(true);
    setError(null);
    setShowTrailer(false);

    getTitleDetailApi(source, mediaType, externalId, region, controller.signal)
      .then((data) => {
        setDetail(data);
        if (data.seasons.length > 0) {
          const firstRegular = data.seasons.find((s) => !s.isSpecials) || data.seasons[0];
          setSelectedSeasonNum(firstRegular.seasonNumber);
        }
      })
      .catch((err: any) => {
        if (err?.name !== 'AbortError') {
          setError(err?.message || 'Unable to load title details from metadata provider.');
        }
      })
      .finally(() => setLoading(false));

    return () => controller.abort();
  }, [source, mediaType, externalId, region]);

  const savedRecord = detail ? library[detail.titleKey] : undefined;

  useEffect(() => {
    setNotesDraft(savedRecord?.notes || '');
    setStartedDraft(savedRecord?.startedAt || '');
    setCompletedDraft(savedRecord?.completedAt || '');
  }, [savedRecord?.titleKey, savedRecord?.notes, savedRecord?.startedAt, savedRecord?.completedAt]);

  // Episode progress calculations (strictly excluding unreleased episodes & separating specials)
  const progressStats = useMemo(() => {
    if (!detail || detail.seasons.length === 0) {
      return {
        regularReleased: [] as EpisodeItem[],
        regularCompleted: 0,
        regularRemaining: 0,
        regularPct: 0,
        upcomingCount: 0,
        specialsTotal: 0,
        specialsCompleted: 0,
        nextEpisode: null as EpisodeItem | null,
        lastWatchedEpisode: null as EpisodeItem | null,
      };
    }

    const regularAll = detail.seasons.filter((s) => !s.isSpecials).flatMap((s) => s.episodes);
    const regularReleased = regularAll.filter((e) => e.isReleased);
    const upcomingCount = regularAll.filter((e) => !e.isReleased).length;
    const regularCompletedList = regularReleased.filter((e) => Boolean(episodeProgress[e.episodeKey]));
    const regularCompleted = regularCompletedList.length;
    const regularRemaining = Math.max(0, regularReleased.length - regularCompleted);
    const regularPct =
      regularReleased.length > 0 ? Math.round((regularCompleted / regularReleased.length) * 100) : 0;

    const specialsReleased = detail.seasons
      .filter((s) => s.isSpecials)
      .flatMap((s) => s.episodes)
      .filter((e) => e.isReleased);
    const specialsCompleted = specialsReleased.filter((e) => Boolean(episodeProgress[e.episodeKey])).length;

    const nextEpisode = regularReleased.find((e) => !episodeProgress[e.episodeKey]) || null;
    const lastWatchedEpisode =
      regularCompletedList.length > 0 ? regularCompletedList[regularCompletedList.length - 1] : null;

    return {
      regularReleased,
      regularCompleted,
      regularRemaining,
      regularPct,
      upcomingCount,
      specialsTotal: specialsReleased.length,
      specialsCompleted,
      nextEpisode,
      lastWatchedEpisode,
    };
  }, [detail, episodeProgress]);

  const activeSeason = useMemo(() => {
    if (!detail) return null;
    return detail.seasons.find((s) => s.seasonNumber === selectedSeasonNum) || detail.seasons[0] || null;
  }, [detail, selectedSeasonNum]);

  const activeSeasonProgress = useMemo(() => {
    if (!activeSeason) return { completed: 0, released: 0, pct: 0 };
    const released = activeSeason.episodes.filter((e) => e.isReleased);
    const completed = released.filter((e) => Boolean(episodeProgress[e.episodeKey])).length;
    const pct = released.length > 0 ? Math.round((completed / released.length) * 100) : 0;
    return { completed, released: released.length, pct };
  }, [activeSeason, episodeProgress]);

  if (loading) {
    return (
      <div className="space-y-8 animate-pulse">
        <div className="h-80 rounded-2xl bg-[#11131B]" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <div className="h-8 w-2/3 rounded bg-[#191C27]" />
            <div className="h-24 w-full rounded bg-[#11131B]" />
          </div>
          <div className="h-64 rounded-xl bg-[#11131B]" />
        </div>
      </div>
    );
  }

  if (error || !detail) {
    return (
      <div className="rounded-2xl bg-[#11131B] border border-white/[0.08] p-10 text-center space-y-4">
        <h1 className="font-serif text-2xl text-[#F5F3FA]">Title metadata unavailable</h1>
        <p className="text-sm text-[#A1A1B2] max-w-md mx-auto">
          {error || 'We could not retrieve verified metadata for this title right now.'}
        </p>
        <Link
          to="/discover"
          className="inline-block px-5 py-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-sm font-semibold hover:bg-[#b89efc]"
        >
          Return to Discovery
        </Link>
      </div>
    );
  }

  const isEpisodic = detail.mediaType !== 'movie';

  return (
    <div className="space-y-10">
      {/* Hero Banner */}
      <section className="relative rounded-2xl overflow-hidden bg-[#11131B] border border-white/[0.08]">
        <div className="absolute inset-0">
          <PosterImage
            src={detail.backdropUrl || detail.posterUrl || GENERATED_ASSETS.heroBackdrop}
            alt={detail.title}
            variant="backdrop"
            className="w-full h-full opacity-50"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#08090D] via-[#08090D]/80 to-[#08090D]/40" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#08090D] via-[#08090D]/75 to-transparent" />
        </div>

        <div className="relative z-10 p-6 sm:p-10 flex flex-col md:flex-row gap-7 lg:gap-10 items-start">
          {/* Poster */}
          <div className="w-40 sm:w-52 aspect-[2/3] rounded-xl overflow-hidden border border-white/15 shadow-2xl shrink-0">
            <PosterImage src={detail.posterUrl} alt={detail.title} className="w-full h-full" />
          </div>

          {/* Primary Metadata & Actions */}
          <div className="flex-1 min-w-0 space-y-4">
            <div>
              <p className="text-xs font-medium tracking-[0.16em] uppercase text-[#D6B477] mb-1.5">
                {detail.mediaType === 'movie'
                  ? 'Feature Film'
                  : detail.mediaType === 'anime'
                    ? 'Anime Series'
                    : 'Television Series'}
                {detail.status ? ` · ${detail.status}` : ''}
              </p>
              <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-semibold text-[#F5F3FA] leading-tight">
                {detail.title}
              </h1>
              {detail.originalTitle && detail.originalTitle !== detail.title && (
                <p className="mt-1 text-sm text-[#A1A1B2]">{detail.originalTitle}</p>
              )}
            </div>

            {/* Clean Unboxed Metadata Line */}
            <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1.5 text-xs sm:text-sm text-[#A1A1B2] tabular-nums">
              <span>{detail.releaseDate || detail.releaseYear || 'Release date unavailable'}</span>
              <span aria-hidden="true">·</span>
              <span>{detail.country}</span>
              <span aria-hidden="true">·</span>
              <span>{detail.language}</span>
              {detail.runtimeMinutes ? (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" aria-hidden="true" />
                    {detail.runtimeMinutes} min
                  </span>
                </>
              ) : null}
              {detail.rating !== null && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1 font-mono text-[#D6B477]">
                    <Star className="w-3.5 h-3.5 fill-[#D6B477]" aria-hidden="true" />
                    {detail.rating.toFixed(1)}
                    {detail.voteCount ? (
                      <span className="text-[#A1A1B2] font-sans text-xs ml-0.5">
                        ({detail.voteCount.toLocaleString()} votes)
                      </span>
                    ) : null}
                  </span>
                </>
              )}
            </div>

            {detail.genres.length > 0 && (
              <p className="text-xs sm:text-sm text-[#F5F3FA]/85">
                {detail.genres.join('  /  ')}
              </p>
            )}

            <p className="text-sm sm:text-base text-[#F5F3FA]/80 leading-relaxed max-w-3xl">
              {detail.synopsis || 'Synopsis unavailable from upstream metadata provider.'}
            </p>

            {/* Primary Actions Bar */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              {savedRecord ? (
                <div className="flex items-center gap-2">
                  <select
                    aria-label="Library status"
                    value={savedRecord.status}
                    onChange={(e) =>
                      upsertTitleStatus(detail, { status: e.target.value as WatchStatus })
                    }
                    className="h-10 px-3.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-sm font-semibold focus:outline-none cursor-pointer"
                  >
                    {Object.entries(WATCH_STATUS_LABELS).map(([val, label]) => (
                      <option key={val} value={val} className="bg-[#11131B] text-[#F5F3FA]">
                        {label}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    onClick={() => setConfirmRemove(true)}
                    aria-label="Remove from library"
                    title="Remove from library"
                    className="h-10 w-10 rounded-lg bg-[#191C27] border border-white/10 flex items-center justify-center text-[#A1A1B2] hover:text-red-400 hover:border-red-500/40 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => upsertTitleStatus(detail, { status: 'want_to_watch' })}
                  className="inline-flex items-center gap-2 h-10 px-5 rounded-lg bg-[#A78BFA] text-[#08090D] text-sm font-semibold hover:bg-[#b89efc] transition-colors whitespace-nowrap"
                >
                  <Bookmark className="w-4 h-4" />
                  <span>Add to Watchlist</span>
                </button>
              )}

              <button
                type="button"
                onClick={() =>
                  upsertTitleStatus(detail, {
                    status: savedRecord?.status || 'want_to_watch',
                    isFavorite: !(savedRecord?.isFavorite ?? false),
                  })
                }
                className={`inline-flex items-center gap-2 h-10 px-4 rounded-lg border text-sm font-medium transition-colors whitespace-nowrap ${
                  savedRecord?.isFavorite
                    ? 'bg-[#D6B477]/15 border-[#D6B477]/50 text-[#D6B477]'
                    : 'bg-[#191C27]/80 border-white/10 text-[#F5F3FA] hover:border-white/25'
                }`}
              >
                <Heart className={`w-4 h-4 ${savedRecord?.isFavorite ? 'fill-[#D6B477]' : ''}`} />
                <span>{savedRecord?.isFavorite ? 'Favorited' : 'Favorite'}</span>
              </button>

              {detail.trailer && (
                <button
                  type="button"
                  onClick={() => setShowTrailer((v) => !v)}
                  className="inline-flex items-center gap-2 h-10 px-4 rounded-lg bg-[#191C27]/80 border border-white/10 text-sm font-medium text-[#F5F3FA] hover:border-white/25 transition-colors whitespace-nowrap"
                >
                  <Play className="w-4 h-4 text-[#A78BFA]" />
                  <span>{showTrailer ? 'Hide Trailer' : 'Watch Trailer'}</span>
                </button>
              )}

              {user && (
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setShowCollectionMenu((v) => !v)}
                    className="inline-flex items-center gap-2 h-10 px-4 rounded-lg bg-[#191C27]/80 border border-white/10 text-sm font-medium text-[#F5F3FA] hover:border-white/25 transition-colors whitespace-nowrap"
                  >
                    <FolderPlus className="w-4 h-4 text-[#A1A1B2]" />
                    <span>Collections</span>
                  </button>

                  {showCollectionMenu && (
                    <div className="absolute left-0 top-12 z-30 w-64 rounded-xl bg-[#11131B] border border-white/15 shadow-2xl p-2 space-y-1">
                      {collections.length === 0 ? (
                        <div className="p-3 text-xs text-[#A1A1B2]">
                          No custom collections yet.{' '}
                          <Link to="/collections" className="text-[#A78BFA] underline">
                            Create one
                          </Link>
                        </div>
                      ) : (
                        collections.map((col) => {
                          const included = col.titleKeys.includes(detail.titleKey);
                          return (
                            <button
                              key={col.id}
                              type="button"
                              onClick={async () => {
                                if (!savedRecord) {
                                  await upsertTitleStatus(detail, { status: 'want_to_watch' });
                                }
                                await toggleTitleInCollection(col.id, detail.titleKey);
                              }}
                              className="w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg text-xs text-left hover:bg-white/5"
                            >
                              <span className="truncate text-[#F5F3FA]">{col.name}</span>
                              {included && <Check className="w-3.5 h-3.5 text-[#A78BFA] shrink-0" />}
                            </button>
                          );
                        })
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Embedded Official Trailer */}
      {showTrailer && detail.trailer?.embedUrl && (
        <section className="rounded-2xl overflow-hidden bg-[#11131B] border border-white/10">
          <div className="aspect-video w-full">
            <iframe
              src={detail.trailer.embedUrl}
              title={detail.trailer.name}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full border-0"
            />
          </div>
        </section>
      )}

      {/* Parent Franchise & Viewing Order Banner */}
      {detail.parentFranchises && detail.parentFranchises.length > 0 && (
        <section className="rounded-2xl bg-[#11131B] border border-[#D6B477]/25 p-5 sm:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1 min-w-0">
              <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-[#D6B477] inline-flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" aria-hidden="true" />
                <span>Part of Verified Franchise Viewing Guide</span>
              </p>
              <p className="text-sm text-[#A1A1B2]">
                Explore the complete release, chronological, and recommended watch order for this universe.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              {detail.parentFranchises.map((pf) => (
                <Link
                  key={pf.id}
                  to={`/franchises/${encodeURIComponent(pf.id)}`}
                  className="inline-flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-[#191C27] border border-white/10 hover:border-[#A78BFA]/70 transition-colors"
                >
                  <div className="text-left">
                    <p className="text-xs sm:text-sm font-semibold text-[#F5F3FA]">{pf.name}</p>
                    <p className="text-[11px] text-[#A1A1B2] tabular-nums">
                      {pf.positionInRecommended
                        ? `Entry #${pf.positionInRecommended} in Recommended Order · `
                        : ''}
                      {pf.entryCount} entries
                    </p>
                  </div>
                  <span className="text-xs font-medium text-[#A78BFA] whitespace-nowrap">View Guide →</span>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Main Content Grid: Left (Episodes + Cast + Franchise) / Right (Where to Watch + Personal Tracking + Production Info) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        <div className="lg:col-span-8 space-y-10 min-w-0">
          {/* EPISODE TRACKING SYSTEM (Primary Feature) */}
          {isEpisodic && (
            <section className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-5 sm:p-7 space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-medium tracking-[0.14em] uppercase text-[#D6B477] mb-1">
                    Episode Tracker
                  </p>
                  <h2 className="font-serif text-2xl font-semibold text-[#F5F3FA]">
                    Seasons & Episodes
                  </h2>
                  <p className="text-xs text-[#A1A1B2] mt-1 tabular-nums">
                    {detail.totalSeasons ? `${detail.totalSeasons} season${detail.totalSeasons === 1 ? '' : 's'}` : 'Season info confirmed below'}
                    {' · '}
                    {progressStats.regularReleased.length} released episode{progressStats.regularReleased.length === 1 ? '' : 's'}
                    {progressStats.upcomingCount > 0 ? ` · ${progressStats.upcomingCount} upcoming (excluded from progress)` : ''}
                    {progressStats.specialsTotal > 0 ? ` · ${progressStats.specialsTotal} specials tracked separately` : ''}
                  </p>
                </div>

                {progressStats.nextEpisode && (
                  <button
                    type="button"
                    onClick={() => toggleEpisodeWatched(detail, progressStats.nextEpisode!)}
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold hover:bg-[#b89efc] transition-colors whitespace-nowrap self-start"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Mark Next ({formatCode(progressStats.nextEpisode)}) Watched</span>
                  </button>
                )}
              </div>

              {/* Overall Series Progress Summary */}
              {detail.seasons.length > 0 && (
                <div className="rounded-xl bg-[#191C27]/70 border border-white/[0.06] p-4 sm:p-5 space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs sm:text-sm">
                    <span className="font-medium text-[#F5F3FA]">Series Progress (Released Episodes)</span>
                    <span className="font-mono tabular-nums text-[#A78BFA] font-semibold">
                      {progressStats.regularCompleted} / {progressStats.regularReleased.length} ({progressStats.regularPct}%)
                    </span>
                  </div>

                  <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                    <div
                      className="h-full bg-[#A78BFA] rounded-full transition-all duration-300"
                      style={{ width: `${progressStats.regularPct}%` }}
                    />
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1 text-xs">
                    <div>
                      <p className="text-[#A1A1B2]">Completed</p>
                      <p className="mt-0.5 font-mono tabular-nums text-[#F5F3FA] text-sm font-semibold">
                        {progressStats.regularCompleted}
                      </p>
                    </div>
                    <div>
                      <p className="text-[#A1A1B2]">Remaining</p>
                      <p className="mt-0.5 font-mono tabular-nums text-[#F5F3FA] text-sm font-semibold">
                        {progressStats.regularRemaining}
                      </p>
                    </div>
                    <div>
                      <p className="text-[#A1A1B2]">Last Watched</p>
                      <p className="mt-0.5 font-mono tabular-nums text-[#F5F3FA] text-sm truncate">
                        {progressStats.lastWatchedEpisode ? formatCode(progressStats.lastWatchedEpisode) : 'None yet'}
                      </p>
                    </div>
                    <div>
                      <p className="text-[#A1A1B2]">Next Up</p>
                      <p className="mt-0.5 font-mono tabular-nums text-[#D6B477] text-sm truncate">
                        {progressStats.nextEpisode
                          ? formatCode(progressStats.nextEpisode)
                          : progressStats.regularReleased.length > 0
                            ? 'All caught up'
                            : 'TBA'}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {!user && (
                <div className="rounded-xl bg-[#191C27]/50 border border-white/[0.06] px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-[#A1A1B2]">
                  <span>Sign in to save episode checkboxes and synchronize progress across devices.</span>
                  <button
                    type="button"
                    onClick={signInWithGoogle}
                    className="px-3.5 py-1.5 rounded-lg bg-[#A78BFA] text-[#08090D] font-semibold hover:bg-[#b89efc] whitespace-nowrap self-start sm:self-auto"
                  >
                    Sign In with Google
                  </button>
                </div>
              )}

              {detail.seasons.length === 0 ? (
                <div className="rounded-xl bg-[#191C27]/40 border border-white/[0.06] p-8 text-center text-sm text-[#A1A1B2]">
                  Individual episode records are not yet published by {detail.sourceAttribution} for this title.
                </div>
              ) : (
                <>
                  {/* Season Selector Tabs */}
                  <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
                    {detail.seasons.map((season) => {
                      const active = season.seasonNumber === activeSeason?.seasonNumber;
                      const sReleased = season.episodes.filter((e) => e.isReleased);
                      const sDone = sReleased.filter((e) => Boolean(episodeProgress[e.episodeKey])).length;
                      return (
                        <button
                          key={season.seasonNumber}
                          type="button"
                          onClick={() => setSelectedSeasonNum(season.seasonNumber)}
                          className={`px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-colors border ${
                            active
                              ? 'bg-[#A78BFA] text-[#08090D] border-[#A78BFA]'
                              : 'bg-[#191C27] text-[#A1A1B2] border-white/[0.06] hover:text-[#F5F3FA]'
                          }`}
                        >
                          {season.isSpecials ? 'Specials' : `Season ${season.seasonNumber}`}
                          <span className={`ml-1.5 font-mono tabular-nums ${active ? 'text-[#08090D]/80' : 'text-[#A1A1B2]/75'}`}>
                            {sDone}/{sReleased.length}
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Active Season Controls & Progress */}
                  {activeSeason && (
                    <div className="space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                        <div>
                          <h3 className="text-base font-semibold text-[#F5F3FA]">{activeSeason.name}</h3>
                          <p className="text-xs text-[#A1A1B2] tabular-nums mt-0.5">
                            {activeSeasonProgress.completed} of {activeSeasonProgress.released} released episodes watched ({activeSeasonProgress.pct}%)
                            {activeSeason.isSpecials ? ' · Tracked separately from main series total' : ''}
                          </p>
                        </div>

                        {activeSeasonProgress.released > 0 && (
                          <div className="flex items-center gap-2 shrink-0">
                            {activeSeasonProgress.completed < activeSeasonProgress.released ? (
                              <button
                                type="button"
                                onClick={() => markSeasonWatched(detail, activeSeason, true)}
                                className="px-3 py-1.5 rounded-lg bg-[#191C27] border border-white/10 text-xs font-medium text-[#F5F3FA] hover:border-[#A78BFA]/60 hover:text-[#A78BFA] transition-colors whitespace-nowrap"
                              >
                                Mark Season Watched
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => markSeasonWatched(detail, activeSeason, false)}
                                className="px-3 py-1.5 rounded-lg bg-[#191C27] border border-white/10 text-xs font-medium text-[#A1A1B2] hover:text-[#F5F3FA] transition-colors whitespace-nowrap"
                              >
                                Unmark Season
                              </button>
                            )}
                          </div>
                        )}
                      </div>

                      <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                        <div
                          className="h-full bg-[#D6B477] rounded-full transition-all duration-300"
                          style={{ width: `${activeSeasonProgress.pct}%` }}
                        />
                      </div>

                      {/* Episode Rows */}
                      <div className="divide-y divide-white/[0.06] border-t border-white/[0.06]">
                        {activeSeason.episodes.map((ep) => {
                          const watched = Boolean(episodeProgress[ep.episodeKey]);
                          return (
                            <div
                              key={ep.episodeKey}
                              className={`py-4 flex items-start gap-4 transition-colors ${
                                watched ? 'opacity-80' : ''
                              }`}
                            >
                              {/* Completion Checkbox */}
                              <button
                                type="button"
                                disabled={!ep.isReleased}
                                onClick={() => toggleEpisodeWatched(detail, ep)}
                                aria-label={
                                  !ep.isReleased
                                    ? `${formatCode(ep)} is unreleased`
                                    : watched
                                      ? `Undo completion for ${formatCode(ep)}`
                                      : `Mark ${formatCode(ep)} watched`
                                }
                                className={`mt-0.5 w-6 h-6 rounded-md border flex items-center justify-center shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A78BFA] ${
                                  !ep.isReleased
                                    ? 'bg-white/[0.02] border-white/10 text-[#A1A1B2]/40 cursor-not-allowed'
                                    : watched
                                      ? 'bg-[#A78BFA] border-[#A78BFA] text-[#08090D]'
                                      : 'bg-[#191C27] border-white/20 text-transparent hover:border-[#A78BFA]'
                                }`}
                              >
                                {!ep.isReleased ? (
                                  <Lock className="w-3 h-3" />
                                ) : (
                                  <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                                )}
                              </button>

                              {/* Episode Thumbnail (when available) */}
                              {ep.thumbnailUrl && (
                                <div className="hidden sm:block w-28 aspect-video rounded-lg overflow-hidden bg-[#191C27] border border-white/[0.06] shrink-0">
                                  <img
                                    src={ep.thumbnailUrl}
                                    alt={ep.name}
                                    referrerPolicy="no-referrer"
                                    loading="lazy"
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                              )}

                              {/* Episode Metadata */}
                              <div className="flex-1 min-w-0">
                                <div className="flex flex-wrap items-baseline justify-between gap-2">
                                  <div className="flex items-baseline gap-2.5 min-w-0">
                                    <span className="text-xs font-mono tabular-nums text-[#D6B477] shrink-0">
                                      {formatCode(ep)}
                                    </span>
                                    <h4
                                      className={`text-sm font-medium truncate ${
                                        watched ? 'text-[#A1A1B2] line-through' : 'text-[#F5F3FA]'
                                      }`}
                                    >
                                      {ep.name}
                                    </h4>
                                  </div>

                                  <div className="flex items-center gap-2 text-xs text-[#A1A1B2] font-mono tabular-nums shrink-0">
                                    {ep.airDate ? (
                                      <span>{ep.isReleased ? ep.airDate : `Airs ${ep.airDate}`}</span>
                                    ) : (
                                      <span>Date TBA</span>
                                    )}
                                    {ep.runtimeMinutes ? (
                                      <>
                                        <span aria-hidden="true">·</span>
                                        <span>{ep.runtimeMinutes}m</span>
                                      </>
                                    ) : null}
                                  </div>
                                </div>

                                {(ep.isFiller || ep.isRecap || !ep.isReleased) && (
                                  <p className="mt-1 text-xs text-[#D6B477]/90">
                                    {!ep.isReleased && 'Unreleased episode — unlocks automatically on air date'}
                                    {ep.isReleased && ep.isFiller && 'Filler episode'}
                                    {ep.isReleased && ep.isRecap && 'Recap episode'}
                                  </p>
                                )}

                                {ep.overview && (
                                  <p className="mt-1.5 text-xs text-[#A1A1B2] leading-relaxed line-clamp-2">
                                    {ep.overview}
                                  </p>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </>
              )}
            </section>
          )}

          {/* Cast & Crew */}
          {(detail.cast.length > 0 || detail.crew.length > 0) && (
            <section className="space-y-5">
              <h2 className="font-serif text-2xl font-semibold text-[#F5F3FA]">Cast & Crew</h2>

              {detail.cast.length > 0 && (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5">
                  {detail.cast.slice(0, 12).map((member) => (
                    <div
                      key={member.id}
                      className="flex items-center gap-3 p-3 rounded-xl bg-[#11131B] border border-white/[0.06]"
                    >
                      <div className="w-11 h-11 rounded-full bg-[#191C27] overflow-hidden flex items-center justify-center shrink-0">
                        {member.profileUrl ? (
                          <img
                            src={member.profileUrl}
                            alt={member.name}
                            referrerPolicy="no-referrer"
                            loading="lazy"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <User className="w-5 h-5 text-[#A1A1B2]" />
                        )}
                      </div>
                      <div className="min-w-0">
                        <p className="text-xs sm:text-sm font-medium text-[#F5F3FA] truncate">
                          {member.name}
                        </p>
                        <p className="text-xs text-[#A1A1B2] truncate">{member.character}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {detail.crew.length > 0 && (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-6 gap-y-2.5 pt-2 border-t border-white/[0.06] text-xs">
                  {detail.crew.slice(0, 9).map((c) => (
                    <div key={c.id} className="flex items-baseline justify-between gap-2 py-1">
                      <span className="text-[#F5F3FA] font-medium truncate">{c.name}</span>
                      <span className="text-[#A1A1B2] truncate text-right">{c.role}</span>
                    </div>
                  ))}
                </div>
              )}
            </section>
          )}

          {/* Franchise & Related Connections */}
          {detail.relatedFranchise.length > 0 && (
            <section className="space-y-4">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <h2 className="font-serif text-2xl font-semibold text-[#F5F3FA]">
                    Franchise & Connected Titles
                  </h2>
                  <p className="text-xs text-[#A1A1B2] mt-1">
                    Verified upstream relationships ({detail.sourceAttribution})
                  </p>
                </div>
                <Link
                  to="/franchises"
                  className="text-xs font-medium text-[#A78BFA] hover:text-[#c4b0ff] whitespace-nowrap"
                >
                  Open Franchise Explorer
                </Link>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {detail.relatedFranchise.map((rel) => (
                  <Link
                    key={`${rel.relationType}_${rel.titleKey}`}
                    to={getTitleRoute(rel)}
                    className="flex items-center gap-3.5 p-3.5 rounded-xl bg-[#11131B] border border-white/[0.06] hover:border-[#A78BFA]/40 transition-colors"
                  >
                    <div className="w-10 h-10 rounded-lg bg-[#191C27] flex items-center justify-center shrink-0">
                      <Layers className="w-4 h-4 text-[#D6B477]" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-[11px] uppercase tracking-wider text-[#D6B477]">
                        {rel.relationType}
                      </p>
                      <p className="text-sm font-medium text-[#F5F3FA] truncate mt-0.5">
                        {rel.title}
                      </p>
                      {rel.releaseYear && (
                        <p className="text-xs text-[#A1A1B2] font-mono tabular-nums">
                          {rel.releaseYear}
                        </p>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            </section>
          )}
        </div>

        {/* Right Sidebar: Where to Watch + Personal Rating/Notes + Production Sheet */}
        <aside className="lg:col-span-4 space-y-6">
          {/* WHERE TO WATCH */}
          <section className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-5 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <Tv className="w-4 h-4 text-[#D6B477]" aria-hidden="true" />
                <h2 className="font-serif text-lg font-semibold text-[#F5F3FA]">Where to Watch</h2>
              </div>
              <select
                aria-label="Streaming availability region"
                value={region}
                onChange={(e) => {
                  const next = e.target.value;
                  setRegion(next);
                  setGuestRegion(next);
                }}
                className="h-8 px-2.5 rounded-lg bg-[#191C27] border border-white/10 text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
              >
                {STREAMING_REGIONS.map((r) => (
                  <option key={r.code} value={r.code}>
                    {r.name} ({r.code})
                  </option>
                ))}
              </select>
            </div>

            {!detail.availability.available || detail.availability.providers.length === 0 ? (
              <div className="rounded-xl bg-[#191C27]/50 border border-white/[0.06] p-4 text-xs text-[#A1A1B2] leading-relaxed">
                Availability information unavailable.
              </div>
            ) : (
              <div className="space-y-2.5">
                {detail.availability.providers.map((prov) => (
                  <div
                    key={`${prov.providerId}_${prov.type}`}
                    className="flex items-center justify-between gap-3 p-3 rounded-xl bg-[#191C27] border border-white/[0.06]"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      {prov.logoUrl ? (
                        <img
                          src={prov.logoUrl}
                          alt={prov.providerName}
                          referrerPolicy="no-referrer"
                          className="w-8 h-8 rounded-lg object-cover shrink-0"
                        />
                      ) : (
                        <div className="w-8 h-8 rounded-lg bg-[#11131B] border border-white/10 flex items-center justify-center text-xs font-semibold text-[#D6B477] shrink-0">
                          {prov.providerName[0]}
                        </div>
                      )}
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-[#F5F3FA] truncate">
                          {prov.providerName}
                        </p>
                        <p className="text-[11px] text-[#A1A1B2] capitalize">{prov.type}</p>
                      </div>
                    </div>
                    {prov.link && (
                      <a
                        href={prov.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-xs font-medium text-[#A78BFA] hover:text-[#c4b0ff] whitespace-nowrap shrink-0"
                      >
                        <span>Watch</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    )}
                  </div>
                ))}
              </div>
            )}

            <div className="pt-2 border-t border-white/[0.06] space-y-1 text-[11px] text-[#A1A1B2]">
              {detail.availability.note && <p className="leading-relaxed">{detail.availability.note}</p>}
              <p className="font-mono tabular-nums text-[#A1A1B2]/75">
                Source: {detail.availability.source} · Updated{' '}
                {new Date(detail.availability.updatedAt).toLocaleDateString()}
              </p>
            </div>
          </section>

          {/* PERSONAL TRACKING JOURNAL (Rating, Dates, Notes) */}
          <section className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-5 space-y-4">
            <h2 className="font-serif text-lg font-semibold text-[#F5F3FA]">Personal Record</h2>

            {!user ? (
              <p className="text-xs text-[#A1A1B2] leading-relaxed">
                Sign in with Google to rate this title, record started/completed dates, and keep private viewing notes.
              </p>
            ) : (
              <div className="space-y-4">
                {/* Personal Rating 1-10 */}
                <div>
                  <div className="flex items-center justify-between text-xs mb-2">
                    <span className="text-[#A1A1B2]">Personal Rating</span>
                    <span className="font-mono tabular-nums text-[#D6B477]">
                      {savedRecord?.personalRating ? `${savedRecord.personalRating} / 10` : 'Unrated'}
                    </span>
                  </div>
                  <div className="grid grid-cols-10 gap-1">
                    {Array.from({ length: 10 }, (_, idx) => idx + 1).map((score) => {
                      const active = (savedRecord?.personalRating || 0) === score;
                      return (
                        <button
                          key={score}
                          type="button"
                          onClick={() =>
                            upsertTitleStatus(detail, {
                              status: savedRecord?.status || 'watching',
                              personalRating: active ? 0 : score,
                            })
                          }
                          className={`h-8 rounded text-xs font-mono tabular-nums transition-colors ${
                            active
                              ? 'bg-[#D6B477] text-[#08090D] font-semibold'
                              : 'bg-[#191C27] text-[#A1A1B2] hover:text-[#F5F3FA]'
                          }`}
                        >
                          {score}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Dates */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="started-date" className="block text-xs text-[#A1A1B2] mb-1">
                      Started Date
                    </label>
                    <input
                      id="started-date"
                      type="date"
                      value={startedDraft}
                      onChange={(e) => setStartedDraft(e.target.value)}
                      className="w-full h-9 px-2.5 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
                    />
                  </div>
                  <div>
                    <label htmlFor="completed-date" className="block text-xs text-[#A1A1B2] mb-1">
                      Completed Date
                    </label>
                    <input
                      id="completed-date"
                      type="date"
                      value={completedDraft}
                      onChange={(e) => setCompletedDraft(e.target.value)}
                      className="w-full h-9 px-2.5 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
                    />
                  </div>
                </div>

                {/* Personal Notes */}
                <div>
                  <label htmlFor="personal-notes" className="block text-xs text-[#A1A1B2] mb-1">
                    Private Viewing Notes
                  </label>
                  <textarea
                    id="personal-notes"
                    rows={3}
                    maxLength={2000}
                    value={notesDraft}
                    onChange={(e) => setNotesDraft(e.target.value)}
                    placeholder="Memorable scenes, episode thoughts, or watch notes..."
                    className="w-full p-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] placeholder:text-[#A1A1B2]/50 focus:outline-none focus:border-[#A78BFA] resize-y"
                  />
                </div>

                <button
                  type="button"
                  onClick={() =>
                    upsertTitleStatus(detail, {
                      status: savedRecord?.status || 'watching',
                      notes: notesDraft,
                      startedAt: startedDraft,
                      completedAt: completedDraft,
                    })
                  }
                  className="w-full py-2 rounded-lg bg-[#191C27] border border-white/15 text-xs font-semibold text-[#F5F3FA] hover:border-[#A78BFA] hover:text-[#A78BFA] transition-colors"
                >
                  Save Notes & Dates
                </button>
              </div>
            )}
          </section>

          {/* PRODUCTION DETAILS SHEET */}
          <section className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-5 space-y-3">
            <h2 className="font-serif text-lg font-semibold text-[#F5F3FA]">Production Details</h2>
            <dl className="divide-y divide-white/[0.06] text-xs">
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-[#A1A1B2]">Release Status</dt>
                <dd className="text-[#F5F3FA] text-right">{detail.status || 'Unavailable'}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-[#A1A1B2]">Country</dt>
                <dd className="text-[#F5F3FA] text-right">{detail.country}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-[#A1A1B2]">Original Language</dt>
                <dd className="text-[#F5F3FA] text-right">{detail.language}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-[#A1A1B2]">Network / Studio</dt>
                <dd className="text-[#F5F3FA] text-right">
                  {detail.networkOrStudio || 'Unavailable'}
                </dd>
              </div>
              {detail.productionCompanies.length > 0 && (
                <div className="py-2.5 flex justify-between gap-4">
                  <dt className="text-[#A1A1B2]">Production</dt>
                  <dd className="text-[#F5F3FA] text-right max-w-[60%]">
                    {detail.productionCompanies.slice(0, 4).join(', ')}
                  </dd>
                </div>
              )}
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-[#A1A1B2]">Metadata Source</dt>
                <dd className="text-[#D6B477] text-right">{detail.sourceAttribution}</dd>
              </div>
              <div className="py-2.5 flex justify-between gap-4">
                <dt className="text-[#A1A1B2]">Last Verified</dt>
                <dd className="text-[#A1A1B2] font-mono tabular-nums text-right inline-flex items-center gap-1">
                  <Calendar className="w-3 h-3" aria-hidden="true" />
                  {new Date(detail.fetchedAt).toLocaleDateString()}
                </dd>
              </div>
            </dl>
          </section>
        </aside>
      </div>

      {/* Similar Titles */}
      {detail.similarTitles.length > 0 && (
        <div className="pt-4 border-t border-white/[0.06]">
          <MediaRow
            title="Similar & Related Titles"
            subtitle="Matched from upstream catalog recommendations"
            items={detail.similarTitles}
          />
        </div>
      )}

      <ConfirmDialog
        open={confirmRemove}
        title="Remove from your library?"
        description={`Remove "${detail.title}" from your personal watchlist? Individual episode logs remain preserved unless unmarked.`}
        confirmLabel="Remove Title"
        destructive
        onCancel={() => setConfirmRemove(false)}
        onConfirm={async () => {
          setConfirmRemove(false);
          await removeTitleFromLibrary(detail.titleKey);
        }}
      />
    </div>
  );
}
