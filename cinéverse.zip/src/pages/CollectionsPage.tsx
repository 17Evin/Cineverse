import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Edit3, FolderHeart, LogIn, Plus, Trash2, X } from 'lucide-react';
import type { UserCollectionRecord } from '../types/media';
import { useUserData } from '../context/UserDataContext';
import { PosterImage } from '../components/PosterImage';
import { ConfirmDialog } from '../components/ConfirmDialog';

const SUGGESTED_TEMPLATES = [
  { name: 'My Favorite Korean Dramas', description: 'Essential South Korean series across romance, mystery, and drama.' },
  { name: 'Anime to Watch', description: 'Priority anime seasons and theatrical films queued for upcoming weekends.' },
  { name: 'Best Psychological Thrillers', description: 'Mind-bending mysteries, slow-burn suspense, and crime sagas.' },
];

export function CollectionsPage() {
  const {
    user,
    collections,
    library,
    libraryList,
    signInWithGoogle,
    createCollection,
    updateCollection,
    deleteCollection,
    toggleTitleInCollection,
  } = useUserData();

  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [editingCol, setEditingCol] = useState<UserCollectionRecord | null>(null);
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [pendingDelete, setPendingDelete] = useState<UserCollectionRecord | null>(null);

  if (!user) {
    return (
      <div className="max-w-lg mx-auto my-12 rounded-2xl bg-[#11131B] border border-white/[0.08] p-8 sm:p-10 text-center space-y-4">
        <FolderHeart className="w-8 h-8 text-[#D6B477] mx-auto" />
        <h1 className="font-serif text-2xl sm:text-3xl font-semibold text-[#F5F3FA]">
          Custom Collections
        </h1>
        <p className="text-sm text-[#A1A1B2] leading-relaxed">
          Sign in to curate personal shelves like &ldquo;My Favorite Korean Dramas&rdquo;, &ldquo;Anime to Watch&rdquo;, or &ldquo;Best Psychological Thrillers&rdquo;.
        </p>
        <button
          type="button"
          onClick={signInWithGoogle}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-sm font-semibold hover:bg-[#b89efc]"
        >
          <LogIn className="w-4 h-4" />
          <span>Sign In with Google</span>
        </button>
      </div>
    );
  }

  const activeCollection =
    collections.find((c) => c.id === selectedId) || collections[0] || null;

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    const id = await createCollection(newName, newDesc);
    if (id) {
      setSelectedId(id);
      setNewName('');
      setNewDesc('');
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCol || !editName.trim()) return;
    await updateCollection(editingCol.id, { name: editName, description: editDesc });
    setEditingCol(null);
  };

  return (
    <div className="space-y-8">
      <div className="pb-4 border-b border-white/[0.06]">
        <p className="text-xs font-medium tracking-[0.16em] uppercase text-[#D6B477] mb-1">
          Curated Shelves
        </p>
        <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#F5F3FA]">
          Collections
        </h1>
        <p className="mt-1.5 text-sm text-[#A1A1B2]">
          Create, edit, and organize personal lists across any country, genre, or franchise.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Create + Collection List */}
        <div className="lg:col-span-4 space-y-6">
          <form
            onSubmit={handleCreate}
            className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-5 space-y-3.5"
          >
            <h2 className="font-serif text-lg font-semibold text-[#F5F3FA]">New Collection</h2>
            <div>
              <label htmlFor="col-name" className="block text-xs text-[#A1A1B2] mb-1">
                Name
              </label>
              <input
                id="col-name"
                type="text"
                maxLength={100}
                required
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. My Favorite Korean Dramas"
                className="w-full h-9 px-3 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] placeholder:text-[#A1A1B2]/50 focus:outline-none focus:border-[#A78BFA]"
              />
            </div>
            <div>
              <label htmlFor="col-desc" className="block text-xs text-[#A1A1B2] mb-1">
                Description (optional)
              </label>
              <textarea
                id="col-desc"
                rows={2}
                maxLength={500}
                value={newDesc}
                onChange={(e) => setNewDesc(e.target.value)}
                placeholder="Theme or curation notes..."
                className="w-full p-2.5 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] placeholder:text-[#A1A1B2]/50 focus:outline-none focus:border-[#A78BFA]"
              />
            </div>
            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-1.5 py-2 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold hover:bg-[#b89efc] transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Create Collection</span>
            </button>
          </form>

          {collections.length === 0 ? (
            <div className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-5 space-y-3">
              <p className="text-xs font-medium text-[#D6B477]">Quick Starter Ideas</p>
              <div className="space-y-2">
                {SUGGESTED_TEMPLATES.map((tpl) => (
                  <button
                    key={tpl.name}
                    type="button"
                    onClick={async () => {
                      const id = await createCollection(tpl.name, tpl.description);
                      if (id) setSelectedId(id);
                    }}
                    className="w-full text-left p-3 rounded-lg bg-[#191C27] border border-white/[0.06] hover:border-[#A78BFA]/50 transition-colors"
                  >
                    <p className="text-xs font-semibold text-[#F5F3FA]">{tpl.name}</p>
                    <p className="text-[11px] text-[#A1A1B2] mt-0.5 line-clamp-1">{tpl.description}</p>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              {collections.map((col) => {
                const active = col.id === activeCollection?.id;
                return (
                  <button
                    key={col.id}
                    type="button"
                    onClick={() => setSelectedId(col.id)}
                    className={`w-full text-left p-4 rounded-xl border transition-colors ${
                      active
                        ? 'bg-[#191C27] border-[#A78BFA]/70'
                        : 'bg-[#11131B] border-white/[0.06] hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-semibold text-[#F5F3FA] truncate">{col.name}</span>
                      <span className="text-xs font-mono tabular-nums text-[#A1A1B2] shrink-0">
                        {col.titleKeys.length}
                      </span>
                    </div>
                    {col.description && (
                      <p className="mt-1 text-xs text-[#A1A1B2] line-clamp-1">{col.description}</p>
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Right: Active Collection Details */}
        <div className="lg:col-span-8">
          {!activeCollection ? (
            <div className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-12 text-center text-sm text-[#A1A1B2]">
              Create a collection on the left to start organizing your favorite stories.
            </div>
          ) : (
            <div className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-6 space-y-6">
              {editingCol?.id === activeCollection.id ? (
                <form onSubmit={handleSaveEdit} className="space-y-3">
                  <input
                    type="text"
                    maxLength={100}
                    required
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full h-10 px-3 rounded-lg bg-[#191C27] border border-white/15 text-sm text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
                  />
                  <textarea
                    rows={2}
                    maxLength={500}
                    value={editDesc}
                    onChange={(e) => setEditDesc(e.target.value)}
                    className="w-full p-3 rounded-lg bg-[#191C27] border border-white/15 text-xs text-[#F5F3FA] focus:outline-none focus:border-[#A78BFA]"
                  />
                  <div className="flex items-center gap-2">
                    <button
                      type="submit"
                      className="px-4 py-2 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold"
                    >
                      Save Changes
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingCol(null)}
                      className="px-4 py-2 rounded-lg text-xs text-[#A1A1B2] hover:text-[#F5F3FA]"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              ) : (
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-4 border-b border-white/[0.06]">
                  <div>
                    <h2 className="font-serif text-2xl font-semibold text-[#F5F3FA]">
                      {activeCollection.name}
                    </h2>
                    {activeCollection.description && (
                      <p className="mt-1 text-sm text-[#A1A1B2]">{activeCollection.description}</p>
                    )}
                    <p className="mt-2 text-xs font-mono tabular-nums text-[#D6B477]">
                      {activeCollection.titleKeys.length} title{activeCollection.titleKeys.length === 1 ? '' : 's'}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingCol(activeCollection);
                        setEditName(activeCollection.name);
                        setEditDesc(activeCollection.description);
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#191C27] border border-white/10 text-xs text-[#F5F3FA] hover:border-white/25"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Edit</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPendingDelete(activeCollection)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#191C27] border border-white/10 text-xs text-[#A1A1B2] hover:text-red-400 hover:border-red-500/40"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Titles inside collection */}
              {activeCollection.titleKeys.length === 0 ? (
                <div className="py-8 text-center text-sm text-[#A1A1B2]">
                  This collection has no titles yet. Add items from your library below or from any Title Detail page.
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {activeCollection.titleKeys.map((key) => {
                    const entry = library[key];
                    if (!entry) return null;
                    return (
                      <div key={key} className="group relative">
                        <Link
                          to={`/title/${entry.source}/${entry.mediaType}/${entry.externalId}`}
                          className="block aspect-[2/3] rounded-xl overflow-hidden border border-white/10"
                        >
                          <PosterImage src={entry.posterUrl} alt={entry.title} className="w-full h-full" />
                        </Link>
                        <button
                          type="button"
                          onClick={() => toggleTitleInCollection(activeCollection.id, key)}
                          aria-label={`Remove ${entry.title} from collection`}
                          className="absolute top-2 right-2 w-7 h-7 rounded-lg bg-[#08090D]/80 text-[#F5F3FA] hover:text-red-400 flex items-center justify-center border border-white/10"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                        <p className="mt-2 text-xs font-medium text-[#F5F3FA] truncate">{entry.title}</p>
                        <p className="text-[11px] text-[#A1A1B2] truncate">{entry.country}</p>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* Quick Add from Library */}
              {libraryList.length > 0 && (
                <div className="pt-4 border-t border-white/[0.06] space-y-3">
                  <p className="text-xs font-medium text-[#A1A1B2]">Add from your library</p>
                  <div className="flex flex-wrap gap-2">
                    {libraryList
                      .filter((item) => !activeCollection.titleKeys.includes(item.titleKey))
                      .slice(0, 12)
                      .map((item) => (
                        <button
                          key={item.titleKey}
                          type="button"
                          onClick={() => toggleTitleInCollection(activeCollection.id, item.titleKey)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#191C27] border border-white/[0.08] text-xs text-[#F5F3FA] hover:border-[#A78BFA]/60 transition-colors"
                        >
                          <Plus className="w-3 h-3 text-[#A78BFA]" />
                          <span className="max-w-[180px] truncate">{item.title}</span>
                        </button>
                      ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete collection?"
        description={
          pendingDelete
            ? `Permanently delete "${pendingDelete.name}"? The titles themselves will remain in your personal library.`
            : ''
        }
        confirmLabel="Delete Collection"
        destructive
        onCancel={() => setPendingDelete(null)}
        onConfirm={async () => {
          if (pendingDelete) {
            await deleteCollection(pendingDelete.id);
          }
          setPendingDelete(null);
        }}
      />
    </div>
  );
}
