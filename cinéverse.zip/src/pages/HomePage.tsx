import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bookmark, Check, Compass, Play, Shuffle, Star } from 'lucide-react';
import type { HomeFeedResponse, MediaSummary } from '../types/media';
import { GLOBAL_COUNTRIES, GLOBAL_GENRES, GENERATED_ASSETS } from '../constants/catalog';
import { getHomeFeedApi, getRandomTitleApi, getTitleRoute } from '../services/api';
import { useUserData } from '../context/UserDataContext';
import { MediaRow } from '../components/MediaRow';
import { PosterImage } from '../components/PosterImage';

export function HomePage() {
  const navigate = useNavigate();
  const {
    user,
    profile,
    library,
    libraryList,
    upsertTitleStatus,
    removeTitleFromLibrary,
    notify,
  } = useUserData();

  const [feed, setFeed] = useState<HomeFeedResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [randomLoading, setRandomLoading] = useState(false);
  const [excludeSeenRecs, setExcludeSeenRecs] = useState(true);

  useEffect(() => {
    if (profile) {
      setExcludeSeenRecs(profile.excludeCompletedRecs);
    }
  }, [profile]);

  const loadFeed = async (signal?: AbortSignal) => {
    setLoading(true);
    setError(null);
    try {
      const data = await getHomeFeedApi(signal);
      setFeed(data);
    } catch (err: any) {
      if (err?.name !== 'AbortError') {
        setError(err?.message || 'Unable to load entertainment catalog right now.');
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const controller = new AbortController();
    loadFeed(controller.signal);
    return () => controller.abort();
  }, []);

  // Continue watching titles from user's personal library
  const continueWatching = useMemo(() => {
    return libraryList
      .filter((t) => t.status === 'watching')
      .sort((a, b) => (b.completedEpisodesCount || 0) - (a.completedEpisodesCount || 0));
  }, [libraryList]);

  // Personalized recommendations derived strictly from real fetched titles + user preferences/library
  const { personalizedForYou, becauseYouWatchedTitle, becauseYouWatchedItems } = useMemo(() => {
    if (!feed) {
      return {
        personalizedForYou: [] as MediaSummary[],
        becauseYouWatchedTitle: null as string | null,
        becauseYouWatchedItems: [] as MediaSummary[],
      };
    }

    const allPoolMap = new Map<string, MediaSummary>();
    const allLists = [
      feed.trendingWorldwide,
      feed.popularMovies,
      feed.popularSeries,
      feed.popularAnime,
      feed.topRatedDramas,
      feed.hiddenGems,
      feed.recentlyReleased,
    ];
    for (const list of allLists) {
      for (const item of list) {
        if (!allPoolMap.has(item.titleKey)) {
          allPoolMap.set(item.titleKey, item);
        }
      }
    }
    const allPool = Array.from(allPoolMap.values());

    // Build taste weights from user's profile + highly rated/completed/favorite library entries
    const genreWeights = new Map<string, number>();
    const countryWeights = new Map<string, number>();

    for (const g of profile?.favoriteGenres || []) {
      genreWeights.set(g.toLowerCase(), (genreWeights.get(g.toLowerCase()) || 0) + 3);
    }
    for (const c of profile?.preferredCountries || []) {
      countryWeights.set(c.toUpperCase(), (countryWeights.get(c.toUpperCase()) || 0) + 2.5);
    }

    const completedOrFav = libraryList.filter(
      (item) => item.status === 'completed' || item.isFavorite || item.personalRating >= 7
    );
    for (const entry of completedOrFav) {
      const weight = entry.isFavorite ? 3 : entry.personalRating >= 8 ? 2.5 : 1.5;
      for (const g of entry.genres || []) {
        genreWeights.set(g.toLowerCase(), (genreWeights.get(g.toLowerCase()) || 0) + weight);
      }
    }

    const excludeSet = new Set<string>();
    if (excludeSeenRecs) {
      for (const entry of libraryList) {
        if (entry.status === 'completed' || entry.status === 'dropped') {
          excludeSet.add(entry.titleKey);
        }
      }
    }

    const scored = allPool
      .filter((item) => !excludeSet.has(item.titleKey))
      .map((item) => {
        let score = (item.rating || 6.5) * 0.6;
        for (const g of item.genres) {
          score += genreWeights.get(g.toLowerCase()) || 0;
        }
        score += countryWeights.get(item.countryCode.toUpperCase()) || 0;
        return { item, score };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 12)
      .map((s) => s.item);

    // Anchor "Because you watched" on user's top favorite or most recently completed/watching title
    const anchor =
      libraryList.find((t) => t.isFavorite) ||
      libraryList.find((t) => t.status === 'completed') ||
      libraryList.find((t) => t.status === 'watching') ||
      null;

    let relatedToAnchor: MediaSummary[] = [];
    if (anchor) {
      const anchorGenres = new Set((anchor.genres || []).map((g) => g.toLowerCase()));
      relatedToAnchor = allPool
        .filter((item) => item.titleKey !== anchor.titleKey && !excludeSet.has(item.titleKey))
        .map((item) => {
          const sharedGenres = item.genres.filter((g) => anchorGenres.has(g.toLowerCase())).length;
          const sameCountry = item.country.toLowerCase() === anchor.country.toLowerCase() ? 1.5 : 0;
          const sameType = item.mediaType === anchor.mediaType ? 1 : 0;
          return { item, match: sharedGenres * 2 + sameCountry + sameType };
        })
        .filter((x) => x.match > 0)
        .sort((a, b) => b.match - a.match || (b.item.rating || 0) - (a.item.rating || 0))
        .slice(0, 10)
        .map((x) => x.item);
    }

    return {
      personalizedForYou: scored,
      becauseYouWatchedTitle: anchor?.title || null,
      becauseYouWatchedItems: relatedToAnchor,
    };
  }, [feed, profile, libraryList, excludeSeenRecs]);

  const handleRandomDiscovery = async () => {
    setRandomLoading(true);
    try {
      const excludeKeys = excludeSeenRecs
        ? libraryList
            .filter((t) => t.status === 'completed' || t.status === 'dropped')
            .map((t) => t.titleKey)
        : [];
      const pick = await getRandomTitleApi(excludeKeys);
      navigate(getTitleRoute(pick));
    } catch {
      notify('Could not pick a random title right now. Please try again.', 'error');
    } finally {
      setRandomLoading(false);
    }
  };

  const featured = feed?.featured || null;
  const featuredSaved = featured ? Boolean(library[featured.titleKey]) : false;

  return (
    <div className="space-y-12 sm:space-y-14">
      {/* Cinematic Featured Hero */}
      <section className="relative rounded-2xl overflow-hidden bg-[#11131B] border border-white/[0.08] min-h-[420px] sm:min-h-[480px] flex items-end">
        <div className="absolute inset-0">
          <PosterImage
            src={featured?.backdropUrl || GENERATED_ASSETS.heroBackdrop}
            alt={featured?.title || 'CINÉVERSE Featured Cinema'}
            variant="backdrop"
            className="w-full h-full"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#08090D] via-[#08090D]/80 to-[#08090D]/25" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#08090D] via-[#08090D]/40 to-transparent" />
        </div>

        <div className="relative z-10 w-full p-6 sm:p-10 lg:p-12 flex flex-col lg:flex-row lg:items-end justify-between gap-8">
          <div className="max-w-2xl space-y-4">
            <p className="text-xs font-medium tracking-[0.18em] uppercase text-[#D6B477]">
              {featured ? 'Featured in CINÉVERSE' : 'Every story. Every world. One universe.'}
            </p>

            {loading ? (
              <div className="space-y-3">
                <div className="h-10 w-3/4 rounded bg-white/10 animate-pulse" />
                <div className="h-4 w-full rounded bg-white/10 animate-pulse" />
                <div className="h-4 w-2/3 rounded bg-white/10 animate-pulse" />
              </div>
            ) : featured ? (
              <>
                <h1 className="font-serif text-3xl sm:text-5xl font-semibold text-[#F5F3FA] leading-[1.12] tracking-tight">
                  {featured.title}
                </h1>

                <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs sm:text-sm text-[#A1A1B2] tabular-nums">
                  {featured.releaseYear && <span>{featured.releaseYear}</span>}
                  <span aria-hidden="true">·</span>
                  <span>{featured.country}</span>
                  <span aria-hidden="true">·</span>
                  <span>{featured.genres.slice(0, 3).join(' / ')}</span>
                  {featured.rating !== null && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="inline-flex items-center gap-1 text-[#D6B477] font-mono">
                        <Star className="w-3.5 h-3.5 fill-[#D6B477]" aria-hidden="true" />
                        {featured.rating.toFixed(1)}
                      </span>
                    </>
                  )}
                </div>

                <p className="text-sm sm:text-base text-[#F5F3FA]/80 leading-relaxed line-clamp-3 max-w-xl">
                  {featured.synopsis || 'Explore full episode guides, cast credits, franchise viewing orders, and legal streaming platforms.'}
                </p>

                <div className="pt-2 flex flex-wrap items-center gap-3">
                  <Link
                    to={getTitleRoute(featured)}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-sm font-semibold hover:bg-[#b89efc] transition-colors whitespace-nowrap"
                  >
                    <Play className="w-4 h-4 fill-current" />
                    <span>Explore Title</span>
                  </Link>

                  <button
                    type="button"
                    onClick={() =>
                      featuredSaved
                        ? removeTitleFromLibrary(featured.titleKey)
                        : upsertTitleStatus(featured, { status: 'want_to_watch' })
                    }
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-[#191C27]/90 border border-white/10 text-sm font-medium text-[#F5F3FA] hover:border-white/25 transition-colors whitespace-nowrap"
                  >
                    {featuredSaved ? <Check className="w-4 h-4 text-[#A78BFA]" /> : <Bookmark className="w-4 h-4" />}
                    <span>{featuredSaved ? 'In Library' : 'Add to Watchlist'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={randomLoading}
                    onClick={handleRandomDiscovery}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-transparent border border-white/15 text-sm font-medium text-[#F5F3FA] hover:bg-white/5 transition-colors whitespace-nowrap disabled:opacity-50"
                  >
                    <Shuffle className="w-4 h-4 text-[#D6B477]" />
                    <span>{randomLoading ? 'Picking...' : 'Random Discovery'}</span>
                  </button>
                </div>
              </>
            ) : (
              <>
                <h1 className="font-serif text-3xl sm:text-5xl font-semibold text-[#F5F3FA] leading-[1.12]">
                  Discover Global Cinema, Dramas & Anime
                </h1>
                <p className="text-sm sm:text-base text-[#A1A1B2] max-w-xl">
                  Track every released episode, follow verified franchise timelines, and discover stories across every language.
                </p>
                <div className="pt-2 flex flex-wrap items-center gap-3">
                  <Link
                    to="/discover"
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-sm font-semibold hover:bg-[#b89efc] transition-colors"
                  >
                    <Compass className="w-4 h-4" />
                    <span>Open Global Discovery</span>
                  </Link>
                </div>
              </>
            )}
          </div>

          {/* Subtle poster preview on desktop */}
          {featured?.posterUrl && (
            <Link
              to={getTitleRoute(featured)}
              className="hidden lg:block w-36 aspect-[2/3] rounded-xl overflow-hidden border border-white/15 shadow-2xl shrink-0 hover:scale-[1.03] transition-transform duration-200"
            >
              <PosterImage src={featured.posterUrl} alt={featured.title} className="w-full h-full" />
            </Link>
          )}
        </div>
      </section>

      {error && (
        <div className="rounded-xl bg-[#191C27] border border-red-500/30 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <p className="text-sm text-[#F5F3FA]">{error}</p>
          <button
            type="button"
            onClick={() => loadFeed()}
            className="px-4 py-2 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold hover:bg-[#b89efc] whitespace-nowrap self-start sm:self-auto"
          >
            Retry Connection
          </button>
        </div>
      )}

      {/* Continue Watching (Authenticated & Active Series) */}
      {continueWatching.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-end justify-between gap-4">
            <div>
              <h2 className="font-serif text-xl sm:text-2xl font-semibold text-[#F5F3FA]">
                Continue Watching
              </h2>
              <p className="text-xs sm:text-sm text-[#A1A1B2] mt-1">
                Pick up right where you paused across your tracked series and anime
              </p>
            </div>
            <Link
              to="/continue-watching"
              className="text-xs sm:text-sm font-medium text-[#A1A1B2] hover:text-[#A78BFA] transition-colors whitespace-nowrap"
            >
              View all ({continueWatching.length})
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
            {continueWatching.slice(0, 6).map((item) => {
              const pct =
                item.totalReleasedEpisodes > 0
                  ? Math.min(100, Math.round((item.completedEpisodesCount / item.totalReleasedEpisodes) * 100))
                  : 0;
              return (
                <Link
                  key={item.titleKey}
                  to={`/title/${item.source}/${item.mediaType}/${item.externalId}`}
                  className="group flex gap-4 p-3.5 rounded-xl bg-[#11131B] border border-white/[0.06] hover:border-white/15 transition-colors"
                >
                  <PosterImage
                    src={item.posterUrl}
                    alt={item.title}
                    className="w-16 aspect-[2/3] rounded-lg shrink-0"
                  />
                  <div className="flex-1 min-w-0 flex flex-col justify-between py-0.5">
                    <div>
                      <h3 className="text-sm font-semibold text-[#F5F3FA] group-hover:text-[#A78BFA] transition-colors truncate">
                        {item.title}
                      </h3>
                      <p className="text-xs text-[#A1A1B2] mt-1 truncate">
                        {item.lastWatchedEpisodeCode
                          ? `Last watched ${item.lastWatchedEpisodeCode}${item.lastWatchedEpisodeName ? ` · ${item.lastWatchedEpisodeName}` : ''}`
                          : `${item.country} · ${item.releaseYear || 'Ongoing'}`}
                      </p>
                    </div>
                    <div className="space-y-1.5 mt-3">
                      <div className="flex items-center justify-between text-xs font-mono tabular-nums text-[#A1A1B2]">
                        <span>
                          {item.completedEpisodesCount} / {item.totalReleasedEpisodes || '?'} episodes
                        </span>
                        <span className="text-[#A78BFA]">{pct}%</span>
                      </div>
                      <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
                        <div
                          className="h-full bg-[#A78BFA] rounded-full transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </section>
      )}

      {/* Trending Worldwide */}
      <MediaRow
        title="Trending Worldwide"
        subtitle="Global rankings across series, dramas, and anime"
        items={feed?.trendingWorldwide || []}
        loading={loading}
        viewAllTo="/discover?sortBy=popularity"
      />

      {/* Personalized Recommendations (Clearly Distinguished from Popularity Rankings) */}
      {(personalizedForYou.length > 0 || loading) && (
        <section className="space-y-4 pt-2 border-t border-white/[0.06]">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
            <div>
              <p className="text-xs font-medium tracking-[0.14em] uppercase text-[#D6B477] mb-1">
                Personalized Discovery
              </p>
              <h2 className="font-serif text-xl sm:text-2xl font-semibold text-[#F5F3FA]">
                Recommended for Tonight
              </h2>
              <p className="text-xs sm:text-sm text-[#A1A1B2] mt-1">
                {user
                  ? 'Weighted by your favorite genres, preferred countries, and library ratings — separate from global popularity charts.'
                  : 'Curated international picks weighted by critical rating and regional variety. Sign in to personalize with your watch history.'}
              </p>
            </div>
            {user && (
              <label className="inline-flex items-center gap-2 text-xs text-[#A1A1B2] cursor-pointer select-none whitespace-nowrap">
                <input
                  type="checkbox"
                  checked={excludeSeenRecs}
                  onChange={(e) => setExcludeSeenRecs(e.target.checked)}
                  className="accent-[#A78BFA] rounded"
                />
                <span>Hide completed & dropped</span>
              </label>
            )}
          </div>
          <MediaRow
            title=""
            items={personalizedForYou}
            loading={loading}
          />
        </section>
      )}

      {/* Because You Watched */}
      {becauseYouWatchedTitle && becauseYouWatchedItems.length > 0 && (
        <MediaRow
          title={`Because You Watched ${becauseYouWatchedTitle}`}
          subtitle="Matched by shared genre DNA and production region"
          items={becauseYouWatchedItems}
        />
      )}

      {/* Popular Television Series */}
      <MediaRow
        title="Popular Television Series"
        subtitle="Acclaimed ongoing and completed series with full episode tracking"
        items={feed?.popularSeries || []}
        loading={loading}
        viewAllTo="/series"
      />

      {/* Popular Anime */}
      <MediaRow
        title="Popular Anime"
        subtitle="Enriched with Jikan / MyAnimeList episodes, cast, and studio records"
        items={feed?.popularAnime || []}
        loading={loading}
        viewAllTo="/anime"
      />

      {/* Top-Rated Dramas */}
      <MediaRow
        title="Top-Rated Dramas"
        subtitle="Highest-scored television dramas from South Korea, India, Europe, and beyond"
        items={feed?.topRatedDramas || []}
        loading={loading}
        viewAllTo="/discover?genre=Drama&sortBy=rating"
      />

      {/* Popular Movies */}
      <MediaRow
        title="Popular Movies"
        subtitle={
          feed?.tmdbConfigured
            ? 'Feature films from global cinema'
            : 'Theatrical anime features from Jikan (configure TMDB_API_KEY for live-action global films)'
        }
        items={feed?.popularMovies || []}
        loading={loading}
        viewAllTo="/movies"
      />

      {/* Hidden Gems */}
      <MediaRow
        title="Hidden Gems & Underrated Worldwide"
        subtitle="High critical scores outside the loudest mainstream rankings"
        items={feed?.hiddenGems || []}
        loading={loading}
        viewAllTo="/discover?minRating=8&sortBy=rating"
      />

      {/* Recently Released & Upcoming */}
      <MediaRow
        title="Recently Released & Airing Now"
        subtitle="Currently broadcasting seasons and fresh international premieres"
        items={feed?.recentlyReleased || []}
        loading={loading}
        viewAllTo="/discover?status=airing&sortBy=release_date"
      />

      <MediaRow
        title="Upcoming Releases"
        subtitle="Confirmed future titles — future episodes remain locked until release date"
        items={feed?.upcomingReleases || []}
        loading={loading}
        viewAllTo="/discover?status=upcoming"
      />

      {/* Explore by Country */}
      <section className="space-y-5 pt-4 border-t border-white/[0.06]">
        <div className="flex items-end justify-between gap-4">
          <div>
            <h2 className="font-serif text-xl sm:text-2xl font-semibold text-[#F5F3FA]">
              Explore by Country
            </h2>
            <p className="text-xs sm:text-sm text-[#A1A1B2] mt-1">
              Discover stories from world television and cinema industries
            </p>
          </div>
          <Link
            to="/countries"
            className="text-xs sm:text-sm font-medium text-[#A1A1B2] hover:text-[#A78BFA] transition-colors whitespace-nowrap"
          >
            Full World Atlas
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {GLOBAL_COUNTRIES.slice(0, 12).map((c) => (
            <Link
              key={c.code}
              to={`/discover?country=${c.code}`}
              className="group p-4 rounded-xl bg-[#11131B] border border-white/[0.06] hover:border-[#A78BFA]/40 transition-colors"
            >
              <p className="text-xs font-mono text-[#D6B477]">{c.code}</p>
              <p className="mt-1 text-sm font-medium text-[#F5F3FA] group-hover:text-[#A78BFA] transition-colors truncate">
                {c.name}
              </p>
              <p className="mt-0.5 text-xs text-[#A1A1B2] truncate">{c.language}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* Explore by Genre */}
      <section className="space-y-4">
        <h2 className="font-serif text-xl sm:text-2xl font-semibold text-[#F5F3FA]">
          Explore by Genre
        </h2>
        <div className="flex flex-wrap gap-2">
          {GLOBAL_GENRES.map((genre) => (
            <Link
              key={genre}
              to={`/discover?genre=${encodeURIComponent(genre)}`}
              className="px-3.5 py-2 rounded-lg bg-[#11131B] border border-white/[0.08] text-xs sm:text-sm text-[#F5F3FA]/90 hover:border-[#A78BFA]/50 hover:text-[#A78BFA] transition-colors whitespace-nowrap"
            >
              {genre}
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
