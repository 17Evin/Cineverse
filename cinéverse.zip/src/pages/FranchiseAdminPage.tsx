import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowDown,
  ArrowLeft,
  ArrowUp,
  Check,
  Copy,
  Layers,
  Lock,
  Plus,
  Save,
  Search,
  Trash2,
} from 'lucide-react';
import type {
  FranchiseDetail,
  FranchiseEntry,
  FranchiseOrderKey,
  FranchiseRelationship,
  MediaSummary,
} from '../types/media';
import { getFranchisesApi, getFranchiseRoute, searchAllApi } from '../services/api';
import {
  checkIsAdminUser,
  deleteFirestoreFranchise,
  fetchFirestoreFranchises,
  sanitizeSlug,
  saveFirestoreFranchise,
} from '../lib/franchiseStore';
import { useUserData } from '../context/UserDataContext';
import { PosterImage } from '../components/PosterImage';

const RELATIONSHIPS: FranchiseRelationship[] = [
  'Core Entry',
  'Sequel',
  'Prequel',
  'Spin-off',
  'Crossover',
  'Shared Universe',
  'Special',
  'Alternate Timeline',
];

const ORDER_TABS: Array<{ key: FranchiseOrderKey; label: string }> = [
  { key: 'recommended', label: 'Recommended' },
  { key: 'release', label: 'Release' },
  { key: 'chronological', label: 'Chronological' },
  { key: 'complete', label: 'Complete' },
];

function createEmptyFranchise(): FranchiseDetail {
  return {
    id: '',
    name: '',
    description: '',
    originCountry: 'United States',
    mediaScope: 'Verified Films & Series',
    posterUrl: '',
    backdropUrl: '',
    orderAttribution: 'Admin Verified Order',
    sourceNote: 'Manually curated and verified by CINÉVERSE franchise curator.',
    disputedOrderNote: '',
    searchAliases: [],
    relatedFranchiseIds: [],
    confirmedMovieCount: 0,
    confirmedSeriesCount: 0,
    spinoffCount: 0,
    prequelSequelCount: 0,
    isCustom: true,
    isPublished: true,
    orders: {
      recommended: [],
      release: [],
      chronological: [],
      complete: [],
    },
  };
}

export function FranchiseAdminPage() {
  const { user, authReady, signInWithGoogle, notify } = useUserData();
  const [isAdmin, setIsAdmin] = useState(false);
  const [checkingAdmin, setCheckingAdmin] = useState(true);

  const [builtInFranchises, setBuiltInFranchises] = useState<FranchiseDetail[]>([]);
  const [customFranchises, setCustomFranchises] = useState<FranchiseDetail[]>([]);
  const [draft, setDraft] = useState<FranchiseDetail>(createEmptyFranchise());
  const [aliasesText, setAliasesText] = useState('');
  const [relatedText, setRelatedText] = useState('');
  const [activeOrder, setActiveOrder] = useState<FranchiseOrderKey>('recommended');

  const [titleQuery, setTitleQuery] = useState('');
  const [searchResults, setSearchResults] = useState<MediaSummary[]>([]);
  const [searchingTitles, setSearchingTitles] = useState(false);

  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    let active = true;
    setCheckingAdmin(true);
    checkIsAdminUser(user)
      .then((res) => {
        if (active) setIsAdmin(res);
      })
      .finally(() => {
        if (active) setCheckingAdmin(false);
      });
    return () => {
      active = false;
    };
  }, [user]);

  useEffect(() => {
    if (!isAdmin) return;
    Promise.all([
      getFranchisesApi(undefined, 'IN').catch(() => []),
      fetchFirestoreFranchises({ includeDrafts: true }).catch(() => []),
    ]).then(([builtIn, custom]) => {
      setBuiltInFranchises(builtIn);
      setCustomFranchises(custom);
    });
  }, [isAdmin]);

  const loadIntoEditor = (fr: FranchiseDetail) => {
    const cloned: FranchiseDetail = {
      ...fr,
      disputedOrderNote: fr.disputedOrderNote || '',
      posterUrl: fr.posterUrl || '',
      backdropUrl: fr.backdropUrl || '',
      orders: {
        recommended: [...(fr.orders.recommended || [])],
        release: [...(fr.orders.release || [])],
        chronological: [...(fr.orders.chronological || [])],
        complete: [...(fr.orders.complete || [])],
      },
    };
    setDraft(cloned);
    setAliasesText((fr.searchAliases || []).join(', '));
    setRelatedText((fr.relatedFranchiseIds || []).join(', '));
    setConfirmDelete(false);
  };

  const handleSearchTitles = async (e: React.FormEvent) => {
    e.preventDefault();
    const q = titleQuery.trim();
    if (q.length < 2) return;
    setSearchingTitles(true);
    try {
      const res = await searchAllApi(q);
      setSearchResults(res.results.slice(0, 10));
    } catch {
      notify('Unable to query metadata providers right now.', 'error');
    } finally {
      setSearchingTitles(false);
    }
  };

  const addVerifiedTitleToOrder = (item: MediaSummary) => {
    const currentList = draft.orders[activeOrder];
    if (currentList.some((e) => e.titleKey === item.titleKey)) {
      notify(`"${item.title}" is already in ${activeOrder} order.`, 'default');
      return;
    }

    const newEntry: FranchiseEntry = {
      position: currentList.length + 1,
      titleKey: item.titleKey,
      source: item.source,
      mediaType: item.mediaType,
      externalId: item.externalId,
      title: item.title,
      releaseYear: item.releaseYear,
      entryType: item.mediaType === 'movie' ? 'Movie' : item.mediaType === 'anime' ? 'Anime Series' : 'Series',
      relationships: ['Core Entry'],
      description: item.synopsis ? item.synopsis.slice(0, 240) : '',
      relationNote: '',
      posterUrl: item.posterUrl,
      totalSeasons: item.totalSeasons ?? null,
      totalEpisodes: item.totalEpisodes ?? null,
    };

    const nextOrders = { ...draft.orders };
    nextOrders[activeOrder] = [...currentList, newEntry];
    // Ensure entry also exists in complete list
    if (activeOrder !== 'complete' && !nextOrders.complete.some((e) => e.titleKey === item.titleKey)) {
      nextOrders.complete = [
        ...nextOrders.complete,
        { ...newEntry, position: nextOrders.complete.length + 1 },
      ];
    }

    setDraft((prev) => ({
      ...prev,
      posterUrl: prev.posterUrl || item.posterUrl || '',
      backdropUrl: prev.backdropUrl || item.backdropUrl || '',
      orders: nextOrders,
    }));
    notify(`Added "${item.title}" to ${activeOrder} order.`, 'success');
  };

  const moveEntry = (idx: number, dir: -1 | 1) => {
    const list = [...draft.orders[activeOrder]];
    const target = idx + dir;
    if (target < 0 || target >= list.length) return;
    const [moved] = list.splice(idx, 1);
    list.splice(target, 0, moved);
    const reindexed = list.map((e, i) => ({ ...e, position: i + 1 }));
    setDraft((prev) => ({
      ...prev,
      orders: { ...prev.orders, [activeOrder]: reindexed },
    }));
  };

  const removeEntry = (titleKey: string) => {
    const next = draft.orders[activeOrder]
      .filter((e) => e.titleKey !== titleKey)
      .map((e, i) => ({ ...e, position: i + 1 }));
    setDraft((prev) => ({
      ...prev,
      orders: { ...prev.orders, [activeOrder]: next },
    }));
  };

  const updateEntryField = (titleKey: string, patch: Partial<FranchiseEntry>) => {
    setDraft((prev) => {
      const nextOrders = { ...prev.orders };
      // Sync shared metadata (relationships, description, entryType) across all orders; keep relationNote order-specific
      for (const k of ['recommended', 'release', 'chronological', 'complete'] as FranchiseOrderKey[]) {
        nextOrders[k] = nextOrders[k].map((e) => {
          if (e.titleKey !== titleKey) return e;
          if (k === activeOrder) return { ...e, ...patch };
          const { relationNote: _ignore, ...sharedPatch } = patch;
          return { ...e, ...sharedPatch };
        });
      }
      return { ...prev, orders: nextOrders };
    });
  };

  const toggleRelationship = (entry: FranchiseEntry, rel: FranchiseRelationship) => {
    const current = entry.relationships || [];
    const exists = current.includes(rel);
    const next = exists ? current.filter((r) => r !== rel) : [...current, rel];
    updateEntryField(entry.titleKey, {
      relationships: next.length > 0 ? next : ['Core Entry'],
    });
  };

  const copyActiveOrderToAll = () => {
    const source = draft.orders[activeOrder];
    if (source.length === 0) return;
    setDraft((prev) => ({
      ...prev,
      orders: {
        recommended: source.map((e, i) => ({ ...e, position: i + 1 })),
        release: source.map((e, i) => ({ ...e, position: i + 1 })),
        chronological: source.map((e, i) => ({ ...e, position: i + 1 })),
        complete: source.map((e, i) => ({ ...e, position: i + 1 })),
      },
    }));
    notify(`Copied ${activeOrder} sequence to all four viewing order tabs.`, 'success');
  };

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      const toSave: FranchiseDetail = {
        ...draft,
        id: sanitizeSlug(draft.id || draft.name),
        searchAliases: aliasesText
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
        relatedFranchiseIds: relatedText
          .split(',')
          .map((s) => sanitizeSlug(s))
          .filter(Boolean),
      };
      const saved = await saveFirestoreFranchise(user, toSave);
      setCustomFranchises((prev) => {
        const filtered = prev.filter((f) => f.id !== saved.id);
        return [saved, ...filtered];
      });
      setDraft(saved);
      notify(`Saved and verified "${saved.name}" in Firestore.`, 'success');
    } catch (err: any) {
      notify(err?.message || 'Unable to save franchise guide.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!draft.id) return;
    setSaving(true);
    try {
      await deleteFirestoreFranchise(draft.id);
      setCustomFranchises((prev) => prev.filter((f) => f.id !== draft.id));
      setDraft(createEmptyFranchise());
      setAliasesText('');
      setRelatedText('');
      setConfirmDelete(false);
      notify('Deleted custom franchise guide from Firestore.', 'success');
    } catch (err: any) {
      notify(err?.message || 'Unable to delete franchise guide.', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (!authReady || checkingAdmin) {
    return (
      <div className="p-12 rounded-2xl bg-[#11131B] border border-white/[0.06] text-center text-sm text-[#A1A1B2]">
        Verifying curator permissions…
      </div>
    );
  }

  if (!user || !isAdmin) {
    return (
      <div className="max-w-xl mx-auto rounded-2xl bg-[#11131B] border border-white/[0.08] p-8 sm:p-10 text-center space-y-4">
        <div className="w-12 h-12 mx-auto rounded-xl bg-[#191C27] flex items-center justify-center">
          <Lock className="w-5 h-5 text-[#D6B477]" />
        </div>
        <h1 className="font-serif text-2xl font-semibold text-[#F5F3FA]">
          Franchise Curator Access Required
        </h1>
        <p className="text-sm text-[#A1A1B2] leading-relaxed">
          Creating, editing, and verifying franchise viewing orders in the database is restricted to verified CINÉVERSE administrators so viewing guides remain accurate and free of invented entries.
        </p>
        <div className="pt-2 flex items-center justify-center gap-3">
          {!user && (
            <button
              type="button"
              onClick={signInWithGoogle}
              className="px-5 py-2.5 rounded-lg bg-[#A78BFA] text-[#08090D] text-sm font-semibold hover:bg-[#b89efc]"
            >
              Sign in with Google
            </button>
          )}
          <Link
            to="/franchises"
            className="px-4 py-2.5 rounded-lg bg-[#191C27] border border-white/10 text-sm font-medium text-[#F5F3FA] hover:border-white/25"
          >
            Back to Franchises
          </Link>
        </div>
      </div>
    );
  }

  const currentOrderEntries = draft.orders[activeOrder] || [];
  const isExistingCustom = customFranchises.some((f) => f.id === draft.id);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-white/[0.06]">
        <div>
          <Link
            to="/franchises"
            className="inline-flex items-center gap-1.5 text-xs text-[#A1A1B2] hover:text-[#F5F3FA] mb-2"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Franchises</span>
          </Link>
          <h1 className="font-serif text-3xl font-semibold text-[#F5F3FA]">
            Franchise Order Studio
          </h1>
          <p className="text-sm text-[#A1A1B2] mt-1">
            Create, edit, and verify franchise viewing orders backed by Firestore using live TMDB, AniList, and TVMaze titles.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {draft.id && isExistingCustom && (
            <Link
              to={getFranchiseRoute(draft.id)}
              className="px-3.5 py-2 rounded-lg bg-[#191C27] border border-white/10 text-xs font-medium text-[#F5F3FA] hover:border-[#A78BFA]/60 whitespace-nowrap"
            >
              View Live Guide →
            </Link>
          )}
          <button
            type="button"
            disabled={saving}
            onClick={handleSave}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs font-semibold hover:bg-[#b89efc] disabled:opacity-50 whitespace-nowrap"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving…' : 'Save & Verify Order'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Sidebar: Saved Firestore Franchises + Clone Built-in */}
        <aside className="lg:col-span-4 space-y-5">
          <button
            type="button"
            onClick={() => {
              setDraft(createEmptyFranchise());
              setAliasesText('');
              setRelatedText('');
              setConfirmDelete(false);
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-[#191C27] border border-[#A78BFA]/40 text-xs font-semibold text-[#A78BFA] hover:bg-[#A78BFA]/10 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>New Franchise Guide</span>
          </button>

          {/* Clone / Override a Built-in Guide */}
          <div className="p-4 rounded-xl bg-[#11131B] border border-white/[0.06] space-y-2.5">
            <label className="block text-xs font-medium text-[#D6B477]">
              Clone Built-in Franchise to Override
            </label>
            <select
              defaultValue=""
              onChange={(e) => {
                const found = builtInFranchises.find((f) => f.id === e.target.value);
                if (found) loadIntoEditor(found);
                e.target.value = '';
              }}
              className="w-full h-9 px-3 rounded-lg bg-[#191C27] border border-white/10 text-xs text-[#F5F3FA]"
            >
              <option value="" disabled>
                Select built-in franchise…
              </option>
              {builtInFranchises.map((f) => (
                <option key={f.id} value={f.id}>
                  {f.name}
                </option>
              ))}
            </select>
          </div>

          {/* Saved in Firestore */}
          <div className="space-y-2">
            <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-[#A1A1B2] px-1">
              Database Franchises ({customFranchises.length})
            </p>
            {customFranchises.length === 0 ? (
              <div className="p-5 rounded-xl bg-[#11131B] border border-white/[0.06] text-xs text-[#A1A1B2]">
                No custom overrides saved in Firestore yet. Create a new guide or clone a built-in franchise above.
              </div>
            ) : (
              customFranchises.map((fr) => (
                <button
                  key={fr.id}
                  type="button"
                  onClick={() => loadIntoEditor(fr)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-colors ${
                    draft.id === fr.id
                      ? 'bg-[#191C27] border-[#A78BFA]/70'
                      : 'bg-[#11131B] border-white/[0.06] hover:border-white/20'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 text-[11px]">
                    <span className="text-[#D6B477]">{fr.isPublished ? 'Published' : 'Draft'}</span>
                    <span className="font-mono text-[#A1A1B2]">{fr.orders.complete.length} entries</span>
                  </div>
                  <p className="mt-1 text-sm font-semibold text-[#F5F3FA] truncate">{fr.name}</p>
                  <p className="text-[11px] text-[#A1A1B2] font-mono truncate">{fr.id}</p>
                </button>
              ))
            )}
          </div>
        </aside>

        {/* Right Editor */}
        <div className="lg:col-span-8 space-y-6">
          {/* Franchise Metadata Form */}
          <section className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-6 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <h2 className="font-serif text-xl font-semibold text-[#F5F3FA] inline-flex items-center gap-2">
                <Layers className="w-5 h-5 text-[#D6B477]" />
                <span>Franchise Metadata</span>
              </h2>
              <label className="inline-flex items-center gap-2 text-xs text-[#F5F3FA] cursor-pointer">
                <input
                  type="checkbox"
                  checked={draft.isPublished !== false}
                  onChange={(e) => setDraft((prev) => ({ ...prev, isPublished: e.target.checked }))}
                  className="accent-[#A78BFA]"
                />
                <span>Published publicly</span>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-[#A1A1B2] mb-1">Franchise Name *</label>
                <input
                  type="text"
                  value={draft.name}
                  onChange={(e) => {
                    const name = e.target.value;
                    setDraft((prev) => ({
                      ...prev,
                      name,
                      id: prev.id || sanitizeSlug(name),
                    }));
                  }}
                  placeholder="e.g., The MonsterVerse"
                  className="w-full h-10 px-3 rounded-lg bg-[#08090D] border border-white/10 text-sm text-[#F5F3FA]"
                />
              </div>

              <div>
                <label className="block text-xs text-[#A1A1B2] mb-1">URL Slug ID *</label>
                <input
                  type="text"
                  value={draft.id}
                  onChange={(e) => setDraft((prev) => ({ ...prev, id: sanitizeSlug(e.target.value) }))}
                  placeholder="e.g., monsterverse"
                  className="w-full h-10 px-3 rounded-lg bg-[#08090D] border border-white/10 text-sm font-mono text-[#F5F3FA]"
                />
              </div>

              <div>
                <label className="block text-xs text-[#A1A1B2] mb-1">Origin Country</label>
                <input
                  type="text"
                  value={draft.originCountry}
                  onChange={(e) => setDraft((prev) => ({ ...prev, originCountry: e.target.value }))}
                  className="w-full h-10 px-3 rounded-lg bg-[#08090D] border border-white/10 text-sm text-[#F5F3FA]"
                />
              </div>

              <div>
                <label className="block text-xs text-[#A1A1B2] mb-1">Order Attribution</label>
                <select
                  value={draft.orderAttribution}
                  onChange={(e) =>
                    setDraft((prev) => ({
                      ...prev,
                      orderAttribution: e.target.value as FranchiseDetail['orderAttribution'],
                    }))
                  }
                  className="w-full h-10 px-3 rounded-lg bg-[#08090D] border border-white/10 text-sm text-[#F5F3FA]"
                >
                  <option value="Admin Verified Order">Admin Verified Order</option>
                  <option value="Verified Official Order">Verified Official Order</option>
                  <option value="Community-Curated Order">Community-Curated Order</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs text-[#A1A1B2] mb-1">Description *</label>
              <textarea
                rows={3}
                value={draft.description}
                onChange={(e) => setDraft((prev) => ({ ...prev, description: e.target.value }))}
                placeholder="Concise editorial summary of this franchise or shared universe."
                className="w-full p-3 rounded-lg bg-[#08090D] border border-white/10 text-sm text-[#F5F3FA]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-[#A1A1B2] mb-1">Verification / Source Note</label>
                <textarea
                  rows={2}
                  value={draft.sourceNote}
                  onChange={(e) => setDraft((prev) => ({ ...prev, sourceNote: e.target.value }))}
                  className="w-full p-3 rounded-lg bg-[#08090D] border border-white/10 text-xs text-[#F5F3FA]"
                />
              </div>
              <div>
                <label className="block text-xs text-[#A1A1B2] mb-1">
                  Disputed or Ambiguous Viewing Order Explanation
                </label>
                <textarea
                  rows={2}
                  value={draft.disputedOrderNote || ''}
                  onChange={(e) => setDraft((prev) => ({ ...prev, disputedOrderNote: e.target.value }))}
                  placeholder="Optional explanation if chronological and release order conflict."
                  className="w-full p-3 rounded-lg bg-[#08090D] border border-white/10 text-xs text-[#F5F3FA]"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-[#A1A1B2] mb-1">
                  Search Aliases (comma-separated characters, acronyms)
                </label>
                <input
                  type="text"
                  value={aliasesText}
                  onChange={(e) => setAliasesText(e.target.value)}
                  placeholder="godzilla, kong, monarch"
                  className="w-full h-10 px-3 rounded-lg bg-[#08090D] border border-white/10 text-xs text-[#F5F3FA]"
                />
              </div>
              <div>
                <label className="block text-xs text-[#A1A1B2] mb-1">
                  Related Franchise Slugs (comma-separated)
                </label>
                <input
                  type="text"
                  value={relatedText}
                  onChange={(e) => setRelatedText(e.target.value)}
                  placeholder="avengers-saga, marvel-cinematic-universe"
                  className="w-full h-10 px-3 rounded-lg bg-[#08090D] border border-white/10 text-xs font-mono text-[#F5F3FA]"
                />
              </div>
            </div>
          </section>

          {/* Verified Title Picker */}
          <section className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-6 space-y-4">
            <div>
              <h2 className="font-serif text-xl font-semibold text-[#F5F3FA]">
                Add Verified Titles
              </h2>
              <p className="text-xs text-[#A1A1B2] mt-0.5">
                Search live TMDB, AniList, and TVMaze records to add verified entries to the active viewing order.
              </p>
            </div>

            <form onSubmit={handleSearchTitles} className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-[#A1A1B2] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="search"
                  value={titleQuery}
                  onChange={(e) => setTitleQuery(e.target.value)}
                  placeholder="Search a verified movie, series, or anime..."
                  className="w-full h-10 pl-9 pr-3 rounded-lg bg-[#08090D] border border-white/10 text-sm text-[#F5F3FA]"
                />
              </div>
              <button
                type="submit"
                disabled={searchingTitles}
                className="px-4 h-10 rounded-lg bg-[#191C27] border border-white/10 text-xs font-medium text-[#F5F3FA] hover:border-[#A78BFA]/60 whitespace-nowrap"
              >
                {searchingTitles ? 'Searching…' : 'Search Providers'}
              </button>
            </form>

            {searchResults.length > 0 && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-64 overflow-y-auto pr-1">
                {searchResults.map((item) => (
                  <div
                    key={item.titleKey}
                    className="flex items-center gap-3 p-2.5 rounded-lg bg-[#08090D]/70 border border-white/[0.06]"
                  >
                    <PosterImage
                      src={item.posterUrl}
                      alt={item.title}
                      className="w-9 h-13 rounded shrink-0"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-[#F5F3FA] truncate">{item.title}</p>
                      <p className="text-[11px] text-[#A1A1B2] truncate tabular-nums">
                        {item.releaseYear || 'TBA'} · {item.mediaType} · {item.source.toUpperCase()}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => addVerifiedTitleToOrder(item)}
                      className="px-2.5 py-1.5 rounded-md bg-[#A78BFA] text-[#08090D] text-[11px] font-semibold hover:bg-[#b89efc] shrink-0"
                    >
                      Add
                    </button>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Viewing Order Builder */}
          <section className="rounded-2xl bg-[#11131B] border border-white/[0.06] p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-1.5">
                {ORDER_TABS.map((t) => (
                  <button
                    key={t.key}
                    type="button"
                    onClick={() => setActiveOrder(t.key)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                      activeOrder === t.key
                        ? 'bg-[#A78BFA] text-[#08090D]'
                        : 'bg-[#191C27] text-[#A1A1B2] hover:text-[#F5F3FA]'
                    }`}
                  >
                    {t.label} ({(draft.orders[t.key] || []).length})
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={copyActiveOrderToAll}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#191C27] border border-white/10 text-xs text-[#A1A1B2] hover:text-[#F5F3FA] whitespace-nowrap"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy to all orders</span>
              </button>
            </div>

            {currentOrderEntries.length === 0 ? (
              <div className="p-8 rounded-xl bg-[#08090D]/60 border border-dashed border-white/10 text-center text-xs text-[#A1A1B2]">
                No entries in {activeOrder} order yet. Search above to add verified movies or series.
              </div>
            ) : (
              <div className="space-y-3">
                {currentOrderEntries.map((entry, idx) => (
                  <div
                    key={`${activeOrder}_${entry.titleKey}`}
                    className="p-4 rounded-xl bg-[#08090D]/65 border border-white/[0.06] space-y-3"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="font-mono text-sm font-semibold text-[#D6B477] w-7 shrink-0">
                          {String(idx + 1).padStart(2, '0')}
                        </span>
                        <PosterImage
                          src={entry.posterUrl}
                          alt={entry.title}
                          className="w-9 h-13 rounded shrink-0"
                        />
                        <div className="min-w-0">
                          <p className="text-sm font-semibold text-[#F5F3FA] truncate">
                            {entry.title}
                          </p>
                          <p className="text-[11px] text-[#A1A1B2] font-mono">
                            {entry.titleKey} · {entry.releaseYear || 'TBA'}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 shrink-0">
                        <button
                          type="button"
                          onClick={() => moveEntry(idx, -1)}
                          disabled={idx === 0}
                          aria-label="Move up"
                          className="p-1.5 rounded-md bg-[#191C27] text-[#A1A1B2] hover:text-[#F5F3FA] disabled:opacity-30"
                        >
                          <ArrowUp className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => moveEntry(idx, 1)}
                          disabled={idx === currentOrderEntries.length - 1}
                          aria-label="Move down"
                          className="p-1.5 rounded-md bg-[#191C27] text-[#A1A1B2] hover:text-[#F5F3FA] disabled:opacity-30"
                        >
                          <ArrowDown className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => removeEntry(entry.titleKey)}
                          aria-label="Remove entry"
                          className="p-1.5 rounded-md bg-[#191C27] text-[#A1A1B2] hover:text-red-400"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Multi-relationship selector */}
                    <div className="flex flex-wrap items-center gap-1.5">
                      {RELATIONSHIPS.map((rel) => {
                        const selected = (entry.relationships || []).includes(rel);
                        return (
                          <button
                            key={rel}
                            type="button"
                            onClick={() => toggleRelationship(entry, rel)}
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] border transition-colors ${
                              selected
                                ? 'bg-[#D6B477]/15 border-[#D6B477]/50 text-[#D6B477]'
                                : 'bg-[#191C27] border-white/[0.06] text-[#A1A1B2] hover:text-[#F5F3FA]'
                            }`}
                          >
                            {selected && <Check className="w-3 h-3" />}
                            <span>{rel}</span>
                          </button>
                        );
                      })}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <input
                        type="text"
                        value={entry.description}
                        onChange={(e) =>
                          updateEntryField(entry.titleKey, { description: e.target.value })
                        }
                        placeholder="Short description..."
                        className="h-9 px-3 rounded-lg bg-[#11131B] border border-white/10 text-xs text-[#F5F3FA]"
                      />
                      <input
                        type="text"
                        value={entry.relationNote}
                        onChange={(e) =>
                          updateEntryField(entry.titleKey, { relationNote: e.target.value })
                        }
                        placeholder={`Order continuity note for ${activeOrder}...`}
                        className="h-9 px-3 rounded-lg bg-[#11131B] border border-white/10 text-xs text-[#F5F3FA]"
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Delete Section */}
          {isExistingCustom && (
            <div className="flex items-center justify-between gap-4 p-4 rounded-xl bg-[#11131B] border border-red-500/20">
              <div className="text-xs text-[#A1A1B2]">
                Remove this custom Firestore override (built-in catalog guides remain unaffected).
              </div>
              {confirmDelete ? (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setConfirmDelete(false)}
                    className="px-3 py-1.5 rounded-lg bg-[#191C27] text-xs text-[#A1A1B2]"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={saving}
                    onClick={handleDelete}
                    className="px-3 py-1.5 rounded-lg bg-red-500/80 text-white text-xs font-semibold hover:bg-red-500"
                  >
                    Confirm Delete
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmDelete(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#191C27] border border-red-500/30 text-xs text-red-400 hover:bg-red-500/10 whitespace-nowrap"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Override</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
