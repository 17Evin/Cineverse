import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';
import type { MediaSummary } from '../types/media';
import { GLOBAL_COUNTRIES } from '../constants/catalog';
import { discoverTitlesApi } from '../services/api';
import { TitleCard, TitleCardSkeleton } from '../components/TitleCard';

export function CountriesPage() {
  const [selectedCode, setSelectedCode] = useState('KR');
  const [items, setItems] = useState<MediaSummary[]>([]);
  const [loading, setLoading] = useState(true);

  const selectedCountry = GLOBAL_COUNTRIES.find((c) => c.code === selectedCode) || GLOBAL_COUNTRIES[0];

  useEffect(() => {
    const controller = new AbortController();
    setLoading(true);
    discoverTitlesApi({ country: selectedCode, sortBy: 'rating', page: 1 }, controller.signal)
      .then((res) => setItems(res.items))
      .catch((err: any) => {
        if (err?.name !== 'AbortError') setItems([]);
      })
      .finally(() => setLoading(false));
    return () => controller.abort();
  }, [selectedCode]);

  return (
    <div className="space-y-8">
      <div className="pb-5 border-b border-white/[0.06]">
        <p className="text-xs font-medium tracking-[0.16em] uppercase text-[#D6B477] mb-2">
          World Cinema & Television Atlas
        </p>
        <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-[#F5F3FA]">
          Explore by Country
        </h1>
        <p className="mt-2 text-sm text-[#A1A1B2] max-w-2xl">
          Browse verified dramas, series, anime, and cinema organized by country of origin — from Seoul and Mumbai to Tokyo, Istanbul, Madrid, and London.
        </p>
      </div>

      {/* Country selector grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
        {GLOBAL_COUNTRIES.map((country) => {
          const active = country.code === selectedCode;
          return (
            <button
              key={country.code}
              type="button"
              onClick={() => setSelectedCode(country.code)}
              className={`p-3.5 rounded-xl border text-left transition-colors ${
                active
                  ? 'bg-[#191C27] border-[#A78BFA]/70'
                  : 'bg-[#11131B] border-white/[0.06] hover:border-white/20'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-xs font-mono ${active ? 'text-[#A78BFA]' : 'text-[#D6B477]'}`}>
                  {country.code}
                </span>
                <span className="text-[11px] text-[#A1A1B2]">{country.regionLabel}</span>
              </div>
              <p className="mt-1.5 text-sm font-medium text-[#F5F3FA] truncate">{country.name}</p>
              <p className="text-xs text-[#A1A1B2] truncate">{country.language}</p>
            </button>
          );
        })}
      </div>

      {/* Selected Country Spotlight */}
      <section className="space-y-5 pt-2">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
          <div>
            <h2 className="font-serif text-2xl font-semibold text-[#F5F3FA]">
              {selectedCountry.name}
            </h2>
            <p className="text-xs sm:text-sm text-[#A1A1B2] mt-1">
              Primary language: {selectedCountry.language} · Region: {selectedCountry.regionLabel}
            </p>
          </div>
          <Link
            to={`/discover?country=${selectedCountry.code}`}
            className="inline-flex items-center gap-1.5 text-sm font-medium text-[#A78BFA] hover:text-[#c4b0ff] whitespace-nowrap"
          >
            <span>Open full {selectedCountry.name} filters</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-5">
            {Array.from({ length: 12 }).map((_, i) => (
              <TitleCardSkeleton key={i} />
            ))}
          </div>
        ) : items.length === 0 ? (
          <div className="rounded-xl bg-[#11131B] border border-white/[0.06] p-10 text-center text-sm text-[#A1A1B2]">
            No titles were returned for {selectedCountry.name} from the currently active providers. Configure <code className="font-mono text-[#F5F3FA]">TMDB_API_KEY</code> for expanded regional film and drama coverage.
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-5">
            {items.map((item) => (
              <TitleCard key={item.titleKey} item={item} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
