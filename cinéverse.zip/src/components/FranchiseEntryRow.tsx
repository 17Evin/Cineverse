import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Check,
  ChevronDown,
  ChevronUp,
  Clock,
  ExternalLink,
  Film,
  Lock,
  PlayCircle,
  Tv,
} from 'lucide-react';
import type { EpisodeItem, FranchiseEntry, MediaDetail } from '../types/media';
import { getTitleDetailApi, getTitleRoute } from '../services/api';
import { useUserData } from '../context/UserDataContext';
import { PosterImage } from './PosterImage';

interface FranchiseEntryRowProps {
  entry: FranchiseEntry;
  originCountry: string;
  region: string;
  isHighlighted?: boolean;
  autoExpandEpisodes?: boolean;
  rowRef?: (el: HTMLDivElement | null) => void;
}

function formatEpisodeCode(ep: EpisodeItem): string {
  if (ep.isSpecial) return `SP${String(ep.episodeNumber).padStart(2, '0')}`;
  return `S${String(ep.seasonNumber).padStart(2, '0')}E${String(ep.episodeNumber).padStart(2, '0')}`;
}

export function FranchiseEntryRow({
  entry,
  originCountry,
  region,
  isHighlighted = false,
  autoExpandEpisodes = false,
  rowRef,
}: FranchiseEntryRowProps) {
  const {
    library,
    episodeProgress,
    upsertTitleStatus,
    toggleEpisodeWatched,
    markSeasonWatched,
  } = useUserData();

  const [expanded, setExpanded] = useState(false);
  const [detail, setDetail] = useState<MediaDetail | null>(null);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [detailError, setDetailError] = useState<string | null>(null);
  const [selectedSeasonNum, setSelectedSeasonNum] = useState<number>(1);
  const [savingStatus, setSavingStatus] = useState(false);

  const isEpisodic = entry.mediaType !== 'movie';
  const savedRecord = library[entry.titleKey];
  const completed = savedRecord?.status === 'completed';

  useEffect(() => {
    if (autoExpandEpisodes && isEpisodic) {
      setExpanded(true);
    }
  }, [autoExpandEpisodes, isEpisodic]);

  useEffect(() => {
    if (!expanded || !isEpisodic || detail) return;
    const controller = new AbortController();
    setLoadingDetail(true);
    setDetailError(null);

    getTitleDetailApi(entry.source, entry.mediaType, entry.externalId, region, controller.signal)
      .then((data) => {
        setDetail(data);
        if (data.seasons.length > 0) {
          const firstRegular = data.seasons.find((s) => !s.isSpecials) || data.seasons[0];
          setSelectedSeasonNum(firstRegular.seasonNumber);
        }
      })
      .catch((err: any) => {
        if (err?.name !== 'AbortError') {
          setDetailError(err?.message || 'Unable to load season and episode list.');
        }
      })
      .finally(() => setLoadingDetail(false));

    return () => controller.abort();
  }, [expanded, isEpisodic, detail, entry.source, entry.mediaType, entry.externalId, region]);

  const activeSeason = useMemo(() => {
    if (!detail) return null;
    return detail.seasons.find((s) => s.seasonNumber === selectedSeasonNum) || detail.seasons[0] || null;
  }, [detail, selectedSeasonNum]);

  const seasonProgress = useMemo(() => {
    if (!activeSeason) return { completed: 0, released: 0, pct: 0 };
    const released = activeSeason.episodes.filter((e) => e.isReleased);
    const done = released.filter((e) => Boolean(episodeProgress[e.episodeKey])).length;
    return {
      completed: done,
      released: released.length,
      pct: released.length > 0 ? Math.round((done / released.length) * 100) : 0,
    };
  }, [activeSeason, episodeProgress]);

  const seriesEpisodeSummary = useMemo(() => {
    const completedCount = savedRecord?.completedEpisodesCount || 0;
    const totalCount = savedRecord?.totalReleasedEpisodes || entry.totalEpisodes || 0;
    if (!isEpisodic || (completedCount === 0 && !savedRecord)) return null;
    if (totalCount > 0) {
      return `${completedCount}/${totalCount} eps watched`;
    }
    if (completedCount > 0) {
      return `${completedCount} eps watched`;
    }
    return null;
  }, [isEpisodic, savedRecord, entry.totalEpisodes]);

  const handleToggleCompleted = async () => {
    setSavingStatus(true);
    try {
      const nextStatus = completed ? 'want_to_watch' : 'completed';
      await upsertTitleStatus(
        {
          titleKey: entry.titleKey,
          source: entry.source,
          mediaType: entry.mediaType,
          externalId: entry.externalId,
          title: entry.title,
          originalTitle: entry.title,
          synopsis: entry.description || '',
          posterUrl: entry.posterUrl,
          backdropUrl: null,
          releaseDate: entry.releaseYear ? `${entry.releaseYear}-01-01` : null,
          releaseYear: entry.releaseYear,
          country: originCountry || 'International',
          countryCode: 'US',
          language: 'English',
          genres: [entry.entryType],
          rating: null,
          voteCount: null,
          popularity: null,
          status: null,
          runtimeMinutes: entry.runtimeMinutes ?? null,
          totalSeasons: entry.totalSeasons ?? null,
          totalEpisodes: entry.totalEpisodes ?? null,
          sourceAttribution:
            entry.source === 'tmdb'
              ? 'TMDB'
              : entry.source === 'jikan'
                ? 'AniList / MyAnimeList'
                : 'TVMaze',
          fetchedAt: new Date().toISOString(),
        },
        { status: nextStatus }
      );
    } finally {
      setSavingStatus(false);
    }
  };

  const relationshipsText =
    entry.relationships && entry.relationships.length > 0
      ? entry.relationships.join(' · ')
      : entry.entryType;

  const providers = entry.streamingProviders || [];
  const primaryProviders = providers.filter((p) => p.type === 'subscription' || p.type === 'free');
  const displayProviders = (primaryProviders.length > 0 ? primaryProviders : providers).slice(0, 4);

  return (
    <div
      ref={rowRef}
      className={`rounded-xl bg-[#11131B] border transition-colors ${
        isHighlighted
          ? 'border-[#A78BFA]/70 ring-1 ring-[#A78BFA]/40'
          : completed
            ? 'border-white/[0.08] bg-[#11131B]/80'
            : 'border-white/[0.06] hover:border-white/15'
      }`}
    >
      <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-start gap-4">
        {/* Left: Position + Poster */}
        <div className="flex items-start gap-3.5 shrink-0">
          <div className="w-8 pt-1 text-center shrink-0">
            <span className="font-mono tabular-nums text-sm font-semibold text-[#D6B477]">
              {String(entry.position).padStart(2, '0')}
            </span>
            {isHighlighted && !completed && (
              <p className="mt-1 text-[10px] font-semibold uppercase tracking-wider text-[#A78BFA]">
                Next
              </p>
            )}
          </div>

          <Link
            to={getTitleRoute(entry)}
            className="w-16 sm:w-20 aspect-[2/3] rounded-lg overflow-hidden shrink-0 border border-white/10"
          >
            <PosterImage src={entry.posterUrl} alt={entry.title} className="w-full h-full" />
          </Link>
        </div>

        {/* Center: Details, Relationships, Description, Streaming */}
        <div className="flex-1 min-w-0 space-y-2">
          <div>
            <p className="text-[11px] font-medium text-[#D6B477] tracking-wide">
              {relationshipsText}
            </p>
            <Link
              to={getTitleRoute(entry)}
              className="mt-0.5 inline-block text-base sm:text-lg font-serif font-semibold text-[#F5F3FA] hover:text-[#A78BFA] transition-colors leading-snug"
            >
              {entry.title}
            </Link>

            {/* Unboxed Metadata Line */}
            <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-[#A1A1B2] tabular-nums">
              <span>{entry.releaseYear || 'TBA'}</span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1">
                {entry.mediaType === 'movie' ? (
                  <Film className="w-3 h-3 text-[#A1A1B2]" aria-hidden="true" />
                ) : (
                  <Tv className="w-3 h-3 text-[#A1A1B2]" aria-hidden="true" />
                )}
                {entry.mediaType === 'movie'
                  ? 'Feature Film'
                  : entry.mediaType === 'anime'
                    ? 'Anime Series'
                    : 'Television Series'}
              </span>
              {entry.mediaType === 'movie' && entry.runtimeMinutes ? (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="inline-flex items-center gap-1">
                    <Clock className="w-3 h-3" aria-hidden="true" />
                    {entry.runtimeMinutes} min
                  </span>
                </>
              ) : null}
              {isEpisodic && entry.totalSeasons ? (
                <>
                  <span aria-hidden="true">·</span>
                  <span>
                    {entry.totalSeasons} {entry.totalSeasons === 1 ? 'Season' : 'Seasons'}
                  </span>
                </>
              ) : null}
              {isEpisodic && entry.totalEpisodes ? (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{entry.totalEpisodes} Episodes</span>
                </>
              ) : null}
              {seriesEpisodeSummary && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-[#A78BFA] font-medium">{seriesEpisodeSummary}</span>
                </>
              )}
            </div>
          </div>

          {entry.description && (
            <p className="text-xs sm:text-sm text-[#F5F3FA]/80 leading-relaxed">
              {entry.description}
            </p>
          )}

          {entry.relationNote && (
            <p className="text-xs text-[#A1A1B2] leading-relaxed">
              <span className="text-[#D6B477] font-medium">Continuity:</span> {entry.relationNote}
            </p>
          )}

          {/* Streaming Availability Line */}
          <div className="pt-1 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs">
            {displayProviders.length > 0 ? (
              <>
                <span className="text-[#A1A1B2]">
                  Watch ({entry.availabilityRegion || region}):
                </span>
                <div className="flex flex-wrap items-center gap-2.5">
                  {displayProviders.map((p) => (
                    <span
                      key={`${p.providerId}_${p.type}`}
                      className="inline-flex items-center gap-1.5 text-[#F5F3FA]/90"
                    >
                      {p.logoUrl && (
                        <img
                          src={p.logoUrl}
                          alt={p.providerName}
                          referrerPolicy="no-referrer"
                          className="w-4 h-4 rounded-sm object-cover"
                        />
                      )}
                      <span>{p.providerName}</span>
                      <span className="text-[10px] text-[#A1A1B2]">
                        ({p.type === 'subscription' ? 'Stream' : p.type === 'free' ? 'Free' : p.type === 'rent' ? 'Rent' : 'Buy'})
                      </span>
                    </span>
                  ))}
                  {displayProviders[0]?.link && (
                    <a
                      href={displayProviders[0].link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-[#A78BFA] hover:text-[#c4b0ff]"
                    >
                      <span>Options</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              </>
            ) : (
              <span className="text-[#A1A1B2]/75">
                Availability information unavailable for {entry.availabilityRegion || region}.
              </span>
            )}
          </div>
        </div>

        {/* Right: Actions (Watched Checkbox + Episode Tracker Expand) */}
        <div className="flex sm:flex-col items-center sm:items-end justify-end gap-2 shrink-0 pt-1 sm:pt-0">
          <button
            type="button"
            disabled={savingStatus}
            onClick={handleToggleCompleted}
            aria-pressed={completed}
            aria-label={completed ? `Unmark ${entry.title} watched` : `Mark ${entry.title} watched`}
            className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap border transition-colors ${
              completed
                ? 'bg-[#A78BFA] text-[#08090D] border-[#A78BFA]'
                : 'bg-[#191C27] text-[#F5F3FA] border-white/10 hover:border-[#A78BFA]/70'
            }`}
          >
            <Check className="w-3.5 h-3.5" />
            <span>{completed ? 'Watched' : 'Mark Watched'}</span>
          </button>

          {isEpisodic && (
            <button
              type="button"
              onClick={() => setExpanded((v) => !v)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-[#A1A1B2] hover:text-[#F5F3FA] bg-[#191C27]/60 border border-white/[0.06] hover:border-white/20 whitespace-nowrap transition-colors"
            >
              <PlayCircle className="w-3.5 h-3.5 text-[#D6B477]" />
              <span>Track Episodes</span>
              {expanded ? (
                <ChevronUp className="w-3.5 h-3.5" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5" />
              )}
            </button>
          )}
        </div>
      </div>

      {/* Expandable Inline Season & Episode Tracker */}
      {expanded && isEpisodic && (
        <div className="border-t border-white/[0.06] bg-[#08090D]/55 px-4 sm:px-6 py-4 space-y-4">
          {loadingDetail ? (
            <div className="space-y-2 animate-pulse">
              <div className="h-7 w-48 rounded bg-[#191C27]" />
              <div className="h-10 w-full rounded bg-[#191C27]" />
              <div className="h-10 w-full rounded bg-[#191C27]" />
            </div>
          ) : detailError ? (
            <p className="text-xs text-[#A1A1B2]">{detailError}</p>
          ) : !detail || detail.seasons.length === 0 ? (
            <div className="flex items-center justify-between gap-3 text-xs text-[#A1A1B2]">
              <span>Detailed episode breakdown is unavailable from the upstream metadata provider.</span>
              <Link
                to={getTitleRoute(entry)}
                className="text-[#A78BFA] hover:underline whitespace-nowrap"
              >
                Open title page →
              </Link>
            </div>
          ) : (
            <>
              {/* Season Selector + Mark Season Watched */}
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-1.5">
                  {detail.seasons.map((season) => {
                    const active = activeSeason?.seasonNumber === season.seasonNumber;
                    return (
                      <button
                        key={season.seasonNumber}
                        type="button"
                        onClick={() => setSelectedSeasonNum(season.seasonNumber)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors ${
                          active
                            ? 'bg-[#A78BFA] text-[#08090D]'
                            : 'bg-[#191C27] text-[#A1A1B2] hover:text-[#F5F3FA]'
                        }`}
                      >
                        {season.isSpecials ? 'Specials' : `Season ${season.seasonNumber}`}
                      </button>
                    );
                  })}
                </div>

                {activeSeason && seasonProgress.released > 0 && (
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-mono tabular-nums text-[#A1A1B2]">
                      {seasonProgress.completed}/{seasonProgress.released} ({seasonProgress.pct}%)
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        markSeasonWatched(
                          detail,
                          activeSeason,
                          seasonProgress.completed < seasonProgress.released
                        )
                      }
                      className="px-3 py-1.5 rounded-lg bg-[#191C27] border border-white/10 hover:border-[#A78BFA]/60 text-xs font-medium text-[#F5F3FA] whitespace-nowrap transition-colors"
                    >
                      {seasonProgress.completed < seasonProgress.released
                        ? 'Mark Season Watched'
                        : 'Unmark Season'}
                    </button>
                  </div>
                )}
              </div>

              {/* Episodes List */}
              {activeSeason && (
                <div className="max-h-72 overflow-y-auto divide-y divide-white/[0.05] rounded-lg border border-white/[0.06] bg-[#11131B]">
                  {activeSeason.episodes.map((ep) => {
                    const watched = Boolean(episodeProgress[ep.episodeKey]);
                    return (
                      <div
                        key={ep.episodeKey}
                        className="flex items-center justify-between gap-3 px-3.5 py-2.5 hover:bg-white/[0.02]"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <span className="font-mono text-xs tabular-nums text-[#D6B477] w-14 shrink-0">
                            {formatEpisodeCode(ep)}
                          </span>
                          <div className="min-w-0">
                            <p className="text-xs sm:text-sm text-[#F5F3FA] truncate">{ep.name}</p>
                            <p className="text-[11px] text-[#A1A1B2] tabular-nums">
                              {ep.airDate || 'Air date TBA'}
                              {ep.runtimeMinutes ? ` · ${ep.runtimeMinutes}m` : ''}
                              {ep.isFiller ? ' · Filler' : ''}
                            </p>
                          </div>
                        </div>

                        {ep.isReleased ? (
                          <button
                            type="button"
                            onClick={() => toggleEpisodeWatched(detail, ep)}
                            aria-label={`Toggle ${formatEpisodeCode(ep)} ${ep.name}`}
                            className={`w-7 h-7 rounded-md border flex items-center justify-center shrink-0 transition-colors ${
                              watched
                                ? 'bg-[#A78BFA] border-[#A78BFA] text-[#08090D]'
                                : 'bg-[#191C27] border-white/15 text-transparent hover:border-[#A78BFA]'
                            }`}
                          >
                            <Check className="w-3.5 h-3.5" />
                          </button>
                        ) : (
                          <span
                            className="inline-flex items-center gap-1 text-[11px] text-[#A1A1B2] shrink-0"
                            title="Unreleased episode"
                          >
                            <Lock className="w-3 h-3" />
                            <span>Upcoming</span>
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}
