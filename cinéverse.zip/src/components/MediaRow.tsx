import { useRef } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { MediaSummary } from '../types/media';
import { TitleCard, TitleCardSkeleton } from './TitleCard';

interface MediaRowProps {
  title: string;
  subtitle?: string;
  items: MediaSummary[];
  loading?: boolean;
  viewAllTo?: string;
  emptyMessage?: string;
}

export function MediaRow({
  title,
  subtitle,
  items,
  loading = false,
  viewAllTo,
  emptyMessage,
}: MediaRowProps) {
  const scrollerRef = useRef<HTMLDivElement>(null);

  const scrollByAmount = (dir: -1 | 1) => {
    const el = scrollerRef.current;
    if (!el) return;
    el.scrollBy({ left: dir * Math.max(420, el.clientWidth * 0.75), behavior: 'smooth' });
  };

  if (!loading && items.length === 0 && !emptyMessage) {
    return null;
  }

  return (
    <section className="space-y-4">
      {(title || viewAllTo) && (
        <div className="flex items-end justify-between gap-4">
          <div className="min-w-0">
            {title && (
              <h2 className="font-serif text-xl sm:text-2xl font-semibold text-[#F5F3FA] tracking-tight">
                {title}
              </h2>
            )}
            {subtitle && <p className="text-xs sm:text-sm text-[#A1A1B2] mt-1">{subtitle}</p>}
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {viewAllTo && (
              <Link
                to={viewAllTo}
                className="text-xs sm:text-sm font-medium text-[#A1A1B2] hover:text-[#A78BFA] transition-colors whitespace-nowrap"
              >
                Explore all
              </Link>
            )}
            <div className="hidden sm:flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => scrollByAmount(-1)}
                aria-label={`Scroll ${title || 'titles'} left`}
                className="w-8 h-8 rounded-lg bg-[#11131B] border border-white/[0.08] flex items-center justify-center text-[#A1A1B2] hover:text-[#F5F3FA] hover:border-white/20 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => scrollByAmount(1)}
                aria-label={`Scroll ${title || 'titles'} right`}
                className="w-8 h-8 rounded-lg bg-[#11131B] border border-white/[0.08] flex items-center justify-center text-[#A1A1B2] hover:text-[#F5F3FA] hover:border-white/20 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {loading ? (
        <div className="flex gap-4 overflow-hidden">
          {Array.from({ length: 7 }).map((_, i) => (
            <TitleCardSkeleton key={i} compact />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-xl bg-[#11131B] border border-white/[0.06] px-6 py-8 text-sm text-[#A1A1B2]">
          {emptyMessage}
        </div>
      ) : (
        <div
          ref={scrollerRef}
          className="flex gap-4 overflow-x-auto no-scrollbar pb-1 snap-x"
        >
          {items.map((item) => (
            <div key={item.titleKey} className="snap-start">
              <TitleCard item={item} compact />
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
