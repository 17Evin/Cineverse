import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Layers, RotateCcw, Search, User, X } from 'lucide-react';
import type { SearchResponse } from '../types/media';
import { getTitleRoute, searchAllApi } from '../services/api';
import { PosterImage } from './PosterImage';

export function UniversalSearch() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [data, setData] = useState<SearchResponse | null>(null);
  const [retryTick, setRetryTick] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const requestIdRef = useRef(0);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        inputRef.current?.focus();
        setOpen(true);
      } else if (e.key === 'Escape') {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      requestIdRef.current += 1;
      setData(null);
      setError(null);
      setLoading(false);
      return;
    }

    const controller = new AbortController();
    const reqId = ++requestIdRef.current;
    setLoading(true);
    setError(null);

    const timer = setTimeout(async () => {
      try {
        const res = await searchAllApi(trimmed, controller.signal);
        if (requestIdRef.current === reqId) {
          setData(res);
          setLoading(false);
        }
      } catch (err: any) {
        if (err?.name === 'AbortError') return;
        if (requestIdRef.current === reqId) {
          setData(null);
          setError(err?.message || 'Search timed out. Please try again.');
          setLoading(false);
        }
      }
    }, 250);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [query, retryTick]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = query.trim();
    if (!trimmed) return;
    setOpen(false);
    navigate(`/search?q=${encodeURIComponent(trimmed)}`);
  };

  return (
    <div ref={containerRef} className="relative w-full max-w-xl">
      <form onSubmit={handleSubmit} className="relative flex items-center">
        <Search className="w-4 h-4 text-[#A1A1B2] absolute left-3.5 pointer-events-none" aria-hidden="true" />
        <input
          ref={inputRef}
          type="search"
          value={query}
          onFocus={() => setOpen(true)}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          placeholder="Search titles, actors, directors, countries, franchises..."
          aria-label="Universal search"
          className="w-full h-10 pl-10 pr-9 rounded-lg bg-[#11131B] border border-white/[0.08] text-sm text-[#F5F3FA] placeholder:text-[#A1A1B2]/70 focus:outline-none focus:border-[#A78BFA]/70 transition-colors"
        />
        {query && (
          <button
            type="button"
            onClick={() => {
              setQuery('');
              setData(null);
              setError(null);
              inputRef.current?.focus();
            }}
            aria-label="Clear search"
            className="absolute right-2.5 p-1 text-[#A1A1B2] hover:text-[#F5F3FA]"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </form>

      {open && query.trim().length >= 2 && (
        <div className="absolute left-0 right-0 top-12 z-50 rounded-xl bg-[#11131B] border border-white/10 shadow-2xl overflow-hidden max-h-[75vh] overflow-y-auto">
          {loading ? (
            <div className="p-4 space-y-3">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-10 h-14 rounded bg-[#191C27] animate-pulse shrink-0" />
                  <div className="flex-1 space-y-2">
                    <div className="h-3.5 w-2/3 rounded bg-[#191C27] animate-pulse" />
                    <div className="h-3 w-1/3 rounded bg-[#191C27] animate-pulse" />
                  </div>
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="p-5 flex items-center justify-between gap-3 text-sm text-[#A1A1B2]">
              <span>{error}</span>
              <button
                type="button"
                onClick={() => setRetryTick((t) => t + 1)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#191C27] text-xs font-medium text-[#A78BFA] hover:text-[#c4b0ff] whitespace-nowrap"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Retry</span>
              </button>
            </div>
          ) : !data ||
            (data.results.length === 0 &&
              data.franchiseMatches.length === 0 &&
              data.peopleMatches.length === 0) ? (
            <div className="p-5 text-sm text-[#A1A1B2]">
              No matches found for &ldquo;{query.trim()}&rdquo;. Try a title, actor, country, or franchise name.
            </div>
          ) : (
            <div className="divide-y divide-white/[0.06]">
              {data.franchiseMatches.length > 0 && (
                <div className="p-2 bg-[#A78BFA]/[0.04]">
                  <p className="px-2.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-[#D6B477]">
                    Franchise &amp; Universe Guides
                  </p>
                  {data.franchiseMatches.slice(0, 4).map((fr) => (
                    <button
                      key={fr.id}
                      type="button"
                      onClick={() => {
                        setOpen(false);
                        navigate(`/franchises/${encodeURIComponent(fr.id)}`);
                      }}
                      className="w-full flex items-center gap-3 px-2.5 py-2 rounded-lg hover:bg-white/[0.06] text-left transition-colors"
                    >
                      {fr.posterUrl ? (
                        <PosterImage
                          src={fr.posterUrl}
                          alt={fr.name}
                          className="w-9 h-13 rounded shrink-0 border border-[#D6B477]/30"
                        />
                      ) : (
                        <div className="w-9 h-13 rounded bg-[#191C27] border border-[#D6B477]/30 flex items-center justify-center shrink-0">
                          <Layers className="w-4 h-4 text-[#D6B477]" />
                        </div>
                      )}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <p className="text-sm font-semibold text-[#F5F3FA] truncate">{fr.name}</p>
                          <span className="text-[11px] text-[#A78BFA] whitespace-nowrap shrink-0">
                            Watch Order →
                          </span>
                        </div>
                        <p className="text-xs text-[#A1A1B2] truncate tabular-nums mt-0.5">
                          {fr.matchReason} · {fr.movieCount > 0 ? `${fr.movieCount} films` : ''}
                          {fr.movieCount > 0 && fr.seriesCount > 0 ? ', ' : ''}
                          {fr.seriesCount > 0 ? `${fr.seriesCount} series` : ''}
                          {fr.movieCount === 0 && fr.seriesCount === 0 ? `${fr.entryCount} entries` : ''}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {data.results.length > 0 && (
                <div className="p-2">
                  <p className="px-2.5 py-1.5 text-xs font-medium text-[#A1A1B2]">Individual Titles</p>
                  {data.results.slice(0, 6).map((item) => (
                    <button
                      key={item.titleKey}
                      type="button"
                      onClick={() => {
                        setOpen(false);
                        navigate(getTitleRoute(item));
                      }}
                      className="w-full flex items-center gap-3 px-2.5 py-2 rounded-lg hover:bg-white/[0.04] text-left transition-colors"
                    >
                      <PosterImage
                        src={item.posterUrl}
                        alt={item.title}
                        className="w-9 h-13 rounded shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-[#F5F3FA] truncate">{item.title}</p>
                        <p className="text-xs text-[#A1A1B2] truncate tabular-nums">
                          {item.releaseYear || 'TBA'} · {item.country} ·{' '}
                          {item.mediaType === 'movie'
                            ? 'Film'
                            : item.mediaType === 'anime'
                              ? 'Anime'
                              : 'Series'}
                          {item.rating ? ` · ${item.rating.toFixed(1)}` : ''}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {data.peopleMatches.length > 0 && (
                <div className="p-2">
                  <p className="px-2.5 py-1.5 text-xs font-medium text-[#A1A1B2]">Cast & Crew</p>
                  {data.peopleMatches.slice(0, 3).map((person) => (
                    <button
                      key={person.id}
                      type="button"
                      onClick={() => {
                        setOpen(false);
                        navigate(`/search?q=${encodeURIComponent(person.name)}`);
                      }}
                      className="w-full flex items-center gap-3 px-2.5 py-2 rounded-lg hover:bg-white/[0.04] text-left transition-colors"
                    >
                      <div className="w-8 h-8 rounded-full bg-[#191C27] overflow-hidden flex items-center justify-center shrink-0">
                        {person.imageUrl ? (
                          <img
                            src={person.imageUrl}
                            alt={person.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <User className="w-4 h-4 text-[#A1A1B2]" />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-[#F5F3FA] truncate">{person.name}</p>
                        <p className="text-xs text-[#A1A1B2] truncate">
                          {person.role}
                          {person.country ? ` · ${person.country}` : ''}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              <button
                type="button"
                onClick={handleSubmit}
                className="w-full px-4 py-3 text-xs font-medium text-[#A78BFA] hover:bg-white/[0.04] text-center transition-colors"
              >
                View all search results for &ldquo;{query.trim()}&rdquo;
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
