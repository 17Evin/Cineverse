import { useState } from 'react';
import { Film } from 'lucide-react';
import { GENERATED_ASSETS } from '../constants/catalog';

interface PosterImageProps {
  src: string | null | undefined;
  alt: string;
  variant?: 'poster' | 'backdrop';
  className?: string;
}

export function PosterImage({
  src,
  alt,
  variant = 'poster',
  className = '',
}: PosterImageProps) {
  const [failed, setFailed] = useState(false);
  const fallback =
    variant === 'backdrop' ? GENERATED_ASSETS.heroBackdrop : GENERATED_ASSETS.posterFallback;
  const activeSrc = !src || failed ? fallback : src;

  return (
    <div className={`relative overflow-hidden bg-[#191C27] ${className}`}>
      <img
        src={activeSrc}
        alt={alt}
        referrerPolicy="no-referrer"
        loading="lazy"
        onError={() => {
          if (!failed) setFailed(true);
        }}
        className="w-full h-full object-cover"
      />
      {(!src || failed) && variant === 'poster' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center p-4 text-center bg-gradient-to-t from-[#08090D]/90 via-[#08090D]/30 to-transparent">
          <Film className="w-6 h-6 text-[#D6B477]/70 mb-2" aria-hidden="true" />
          <span className="font-serif text-sm text-[#F5F3FA]/90 line-clamp-3 leading-snug">
            {alt}
          </span>
        </div>
      )}
    </div>
  );
}
