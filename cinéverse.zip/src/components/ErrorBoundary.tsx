import React from 'react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      message: error?.message || 'An unexpected rendering error occurred.',
    };
  }

  componentDidCatch(error: Error) {
    console.error('CINÉVERSE ErrorBoundary caught:', error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#08090D] text-[#F5F3FA] flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-[#11131B] border border-white/10 rounded-xl p-8 text-center">
            <p className="text-xs tracking-[0.2em] uppercase text-[#D6B477] mb-3">CINÉVERSE</p>
            <h1 className="font-serif text-2xl font-semibold text-[#F5F3FA] mb-3">
              Something interrupted the screening
            </h1>
            <p className="text-sm text-[#A1A1B2] mb-6 leading-relaxed">
              We encountered an unexpected error while displaying this view. Reloading usually restores normal playback.
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-5 py-2.5 text-sm font-medium rounded-lg bg-[#A78BFA] text-[#08090D] hover:bg-[#b89efc] transition-colors"
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
