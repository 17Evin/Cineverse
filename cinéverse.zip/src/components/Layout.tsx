import React, { useEffect, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import {
  BarChart3,
  Bookmark,
  Clapperboard,
  Compass,
  Film,
  FolderHeart,
  Globe2,
  Home,
  Layers,
  LogIn,
  Menu,
  PlayCircle,
  RefreshCw,
  Settings,
  Sparkles,
  Tv,
  X,
} from 'lucide-react';
import { useUserData } from '../context/UserDataContext';
import { UniversalSearch } from './UniversalSearch';

interface NavItem {
  to: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const EXPLORE_NAV: NavItem[] = [
  { to: '/', label: 'Home', icon: Home },
  { to: '/discover', label: 'Discover', icon: Compass },
  { to: '/movies', label: 'Movies', icon: Film },
  { to: '/series', label: 'Series', icon: Tv },
  { to: '/anime', label: 'Anime', icon: Sparkles },
  { to: '/countries', label: 'Countries', icon: Globe2 },
  { to: '/franchises', label: 'Franchises', icon: Layers },
  { to: '/updates', label: 'New Updates', icon: RefreshCw },
];

const LIBRARY_NAV: NavItem[] = [
  { to: '/continue-watching', label: 'Continue Watching', icon: PlayCircle },
  { to: '/watchlist', label: 'My Watchlist', icon: Bookmark },
  { to: '/collections', label: 'Collections', icon: FolderHeart },
  { to: '/statistics', label: 'Statistics', icon: BarChart3 },
  { to: '/settings', label: 'Profile & Settings', icon: Settings },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { user, profile, authReady, signInWithGoogle, toasts, dismissToast } = useUserData();
  const location = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior });
  }, [location.pathname]);

  const renderNavGroup = (heading: string, items: NavItem[]) => (
    <div className="space-y-1">
      <p className="px-3 pb-1 text-[11px] font-medium tracking-[0.14em] uppercase text-[#A1A1B2]/70">
        {heading}
      </p>
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            onClick={() => setMobileOpen(false)}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                isActive
                  ? 'bg-[#191C27] text-[#F5F3FA]'
                  : 'text-[#A1A1B2] hover:text-[#F5F3FA] hover:bg-white/[0.03]'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <Icon
                  className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#A78BFA]' : 'text-[#A1A1B2]'}`}
                />
                <span className="truncate">{item.label}</span>
              </>
            )}
          </NavLink>
        );
      })}
    </div>
  );

  return (
    <div className="min-h-screen bg-[#08090D] text-[#F5F3FA] flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:flex-col lg:w-60 lg:fixed lg:inset-y-0 bg-[#0B0C12] border-r border-white/[0.06] z-30">
        <div className="h-16 px-6 flex items-center border-b border-white/[0.06]">
          <Link
            to="/"
            className="flex items-center gap-2.5 text-[#F5F3FA] whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A78BFA] rounded"
          >
            <Clapperboard className="w-5 h-5 text-[#D6B477]" aria-hidden="true" />
            <span className="font-serif text-lg font-semibold tracking-[0.12em]">CINÉVERSE</span>
          </Link>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-5 space-y-6" aria-label="Primary Navigation">
          {renderNavGroup('Explore', EXPLORE_NAV)}
          {renderNavGroup('Personal Library', LIBRARY_NAV)}
        </nav>

        <div className="px-5 py-4 border-t border-white/[0.06] text-[11px] text-[#A1A1B2]/75 leading-relaxed">
          Every story. Every world. One universe.
        </div>
      </aside>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/75"
            onClick={() => setMobileOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative w-72 max-w-[85vw] bg-[#0B0C12] border-r border-white/10 flex flex-col z-10">
            <div className="h-14 px-5 flex items-center justify-between border-b border-white/[0.06]">
              <Link
                to="/"
                onClick={() => setMobileOpen(false)}
                className="flex items-center gap-2 font-serif text-base font-semibold tracking-[0.12em]"
              >
                <Clapperboard className="w-4 h-4 text-[#D6B477]" aria-hidden="true" />
                <span>CINÉVERSE</span>
              </Link>
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                aria-label="Close navigation menu"
                className="p-2 text-[#A1A1B2] hover:text-[#F5F3FA]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto px-3 py-5 space-y-6" aria-label="Mobile Navigation">
              {renderNavGroup('Explore', EXPLORE_NAV)}
              {renderNavGroup('Personal Library', LIBRARY_NAV)}
            </nav>
          </aside>
        </div>
      )}

      {/* Main Content Workspace */}
      <div className="flex-1 lg:pl-60 flex flex-col min-w-0">
        {/* Top Bar */}
        <header className="sticky top-0 z-20 h-14 lg:h-16 bg-[#08090D]/90 backdrop-blur-md border-b border-white/[0.06] px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-1 min-w-0">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden p-2 -ml-2 rounded-lg text-[#A1A1B2] hover:text-[#F5F3FA] hover:bg-white/5"
            >
              <Menu className="w-5 h-5" />
            </button>

            <Link
              to="/"
              className="lg:hidden font-serif text-base font-semibold tracking-[0.12em] whitespace-nowrap shrink-0 mr-1"
            >
              CINÉVERSE
            </Link>

            <div className="flex-1 min-w-0">
              <UniversalSearch />
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {!authReady ? (
              <div className="h-9 w-24 rounded-lg bg-[#11131B] animate-pulse" />
            ) : user ? (
              <Link
                to="/settings"
                className="flex items-center gap-2.5 px-3 py-1.5 rounded-lg bg-[#11131B] border border-white/[0.08] hover:border-white/20 transition-colors whitespace-nowrap shrink-0"
              >
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={profile?.displayName || 'Account'}
                    referrerPolicy="no-referrer"
                    className="w-6 h-6 rounded-full object-cover"
                  />
                ) : (
                  <span className="w-6 h-6 rounded-full bg-[#A78BFA]/20 text-[#A78BFA] text-xs font-semibold flex items-center justify-center">
                    {(profile?.displayName || user.displayName || 'C')[0].toUpperCase()}
                  </span>
                )}
                <span className="hidden sm:inline text-xs font-medium text-[#F5F3FA] max-w-[120px] truncate">
                  {profile?.displayName || user.displayName || 'Account'}
                </span>
              </Link>
            ) : (
              <button
                type="button"
                onClick={signInWithGoogle}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#A78BFA] text-[#08090D] text-xs sm:text-sm font-semibold hover:bg-[#b89efc] transition-colors whitespace-nowrap shrink-0"
              >
                <LogIn className="w-4 h-4" />
                <span>Sign In</span>
              </button>
            )}
          </div>
        </header>

        {/* Main Viewport */}
        <main className="flex-1 w-full max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-10 py-6 sm:py-8">
          {children}
        </main>

        {/* Quiet Editorial Footer */}
        <footer className="mt-16 border-t border-white/[0.06] px-4 sm:px-6 lg:px-10 py-8 text-xs text-[#A1A1B2] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <span className="font-serif text-sm text-[#F5F3FA] tracking-[0.12em]">CINÉVERSE</span>
            <span className="mx-2 text-white/20">·</span>
            <span>Every story. Every world. One universe.</span>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <Link to="/discover" className="hover:text-[#F5F3FA] transition-colors">
              Discover
            </Link>
            <Link to="/countries" className="hover:text-[#F5F3FA] transition-colors">
              Countries
            </Link>
            <Link to="/franchises" className="hover:text-[#F5F3FA] transition-colors">
              Franchises
            </Link>
            <Link to="/settings" className="hover:text-[#F5F3FA] transition-colors">
              Settings
            </Link>
          </div>
        </footer>
      </div>

      {/* Toast Notifications */}
      <div
        aria-live="polite"
        className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm w-[calc(100%-2.5rem)] pointer-events-none"
      >
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-center justify-between gap-3 px-4 py-3 rounded-lg border text-sm shadow-xl ${
              toast.tone === 'error'
                ? 'bg-[#221318] border-red-500/30 text-red-100'
                : toast.tone === 'success'
                  ? 'bg-[#151824] border-[#A78BFA]/40 text-[#F5F3FA]'
                  : 'bg-[#11131B] border-white/10 text-[#F5F3FA]'
            }`}
          >
            <span>{toast.text}</span>
            <button
              type="button"
              onClick={() => dismissToast(toast.id)}
              aria-label="Dismiss notification"
              className="text-[#A1A1B2] hover:text-[#F5F3FA]"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
