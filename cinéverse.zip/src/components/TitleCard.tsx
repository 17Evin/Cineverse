import React from 'react';
import { Link } from 'react-router-dom';
import { Bookmark, Check, Star } from 'lucide-react';
import type { MediaSummary } from '../types/media';
import { getTitleRoute } from '../services/api';
import { useUserData } from '../context/UserDataContext';
import { PosterImage } from './PosterImage';

interface TitleCardProps {
  item: MediaSummary;
  compact?: boolean;
}

export function TitleCard({ item, compact = false }: TitleCardProps) {
  const { library, upsertTitleStatus, removeTitleFromLibrary } = useUserData();
  const saved = library[item.titleKey];
  const detailPath = getTitleRoute(item);

  const mediaLabel =
    item.mediaType === 'movie' ? 'Film' : item.mediaType === 'anime' ? 'Anime' : 'Series';

  const handleWatchlistClick = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (saved) {
      await removeTitleFromLibrary(item.titleKey);
    } else {
      await upsertTitleStatus(item, { status: 'want_to_watch' });
    }
  };

  return (
    <article className={`group relative flex flex-col ${compact ? 'w-[164px] sm:w-[180px] shrink-0' : 'w-full'}`}>
      <Link
        to={detailPath}
        className="relative block aspect-[2/3] rounded-xl overflow-hidden bg-[#191C27] border border-white/[0.06] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A78BFA]"
      >
        <PosterImage
          src={item.posterUrl}
          alt={item.title}
          className="w-full h-full transition-transform duration-300 ease-out group-hover:scale-[1.04]"
        />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#08090D]/90 via-[#08090D]/35 to-transparent" />

        {/* Subtle rating metric at bottom-left, clean unboxed text */}
        {item.rating !== null && (
          <div className="absolute bottom-2.5 left-3 flex items-center gap-1 text-xs font-mono tabular-nums text-[#D6B477]">
            <Star className="w-3 h-3 fill-[#D6B477] text-[#D6B477]" aria-hidden="true" />
            <span>{item.rating.toFixed(1)}</span>
          </div>
        )}

        {/* Quick watchlist toggle */}
        <button
          type="button"
          onClick={handleWatchlistClick}
          aria-label={saved ? `Remove ${item.title} from watchlist` : `Add ${item.title} to watchlist`}
          title={saved ? 'In your library' : 'Add to watchlist'}
          className={`absolute top-2.5 right-2.5 w-9 h-9 rounded-lg flex items-center justify-center transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A78BFA] ${
            saved
              ? 'bg-[#A78BFA] text-[#08090D]'
              : 'bg-[#08090D]/75 text-[#F5F3FA] hover:bg-[#191C27] border border-white/10'
          }`}
        >
          {saved ? <Check className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
        </button>

        {/* Progress strip if currently tracked */}
        {saved && saved.totalReleasedEpisodes > 0 && (
          <div className="absolute inset-x-0 bottom-0 h-1 bg-white/15">
            <div
              className="h-full bg-[#A78BFA] transition-all duration-300"
              style={{
                width: `${Math.min(
                  100,
                  Math.round((saved.completedEpisodesCount / saved.totalReleasedEpisodes) * 100)
                )}%`,
              }}
            />
          </div>
        )}
      </Link>

      <div className="mt-2.5 px-0.5">
        <Link
          to={detailPath}
          className="block text-sm font-medium text-[#F5F3FA] group-hover:text-[#A78BFA] transition-colors line-clamp-1"
        >
          {item.title}
        </Link>
        <p className="mt-1 text-xs text-[#A1A1B2] flex items-center gap-1.5 truncate tabular-nums">
          <span>{item.releaseYear || 'TBA'}</span>
          <span aria-hidden="true">·</span>
          <span className="truncate">{item.country}</span>
          <span aria-hidden="true">·</span>
          <span>{mediaLabel}</span>
        </p>
      </div>
    </article>
  );
}

export function TitleCardSkeleton({ compact = false }: { compact?: boolean }) {
  return (
    <div className={compact ? 'w-[164px] sm:w-[180px] shrink-0' : 'w-full'}>
      <div className="aspect-[2/3] rounded-xl bg-[#191C27] animate-pulse" />
      <div className="mt-2.5 h-4 w-4/5 rounded bg-[#191C27] animate-pulse" />
      <div className="mt-1.5 h-3 w-3/5 rounded bg-[#11131B] animate-pulse" />
    </div>
  );
}
