import type {
  DetectedFranchiseMatch,
  FranchiseDetail,
  FranchiseEntry,
  FranchiseOrderKey,
  FranchiseSearchMatch,
  MediaSummary,
  MediaType,
  MetadataSource,
  ParentFranchiseRef,
} from '../types/media.ts';

interface BaseFranchiseEntryDef {
  source: MetadataSource;
  mediaType: MediaType;
  externalId: string;
  title: string;
  releaseYear: number | null;
  entryType: string;
  relationships: string[];
  description: string;
  defaultNote: string;
  totalSeasons?: number | null;
  totalEpisodes?: number | null;
}

type OrderSpecItem = string | [string, string]; // titleKey OR [titleKey, specificOrderNote]

interface FranchiseSeedDef {
  id: string;
  name: string;
  description: string;
  originCountry: string;
  mediaScope: string;
  orderAttribution: 'Verified Official Order' | 'Community-Curated Order';
  sourceNote: string;
  disputedOrderNote?: string;
  orderNotes?: Partial<Record<FranchiseOrderKey, string>>;
  searchAliases: string[];
  relatedFranchiseIds?: string[];
  entries: Record<string, BaseFranchiseEntryDef>;
  orders: {
    recommended: OrderSpecItem[];
    release: OrderSpecItem[];
    chronological: OrderSpecItem[];
    complete: OrderSpecItem[];
  };
}

function buildOrderList(
  entries: Record<string, BaseFranchiseEntryDef>,
  spec: OrderSpecItem[]
): FranchiseEntry[] {
  const result: FranchiseEntry[] = [];
  spec.forEach((item, idx) => {
    const [key, customNote] = Array.isArray(item) ? item : [item, ''];
    const base = entries[key];
    if (!base) return;
    result.push({
      position: idx + 1,
      titleKey: key,
      source: base.source,
      mediaType: base.mediaType,
      externalId: base.externalId,
      title: base.title,
      releaseYear: base.releaseYear,
      entryType: base.entryType,
      relationships: base.relationships,
      description: base.description,
      relationNote: customNote || base.defaultNote,
      posterUrl: null,
      totalSeasons: base.totalSeasons ?? null,
      totalEpisodes: base.totalEpisodes ?? null,
    });
  });
  return result;
}

function defineFranchise(seed: FranchiseSeedDef): FranchiseDetail {
  const uniqueEntries = Object.values(seed.entries);
  const confirmedMovieCount = uniqueEntries.filter((e) => e.mediaType === 'movie').length;
  const confirmedSeriesCount = uniqueEntries.filter((e) => e.mediaType !== 'movie').length;
  const spinoffCount = uniqueEntries.filter(
    (e) =>
      e.entryType.toLowerCase().includes('spin-off') ||
      e.relationships.some((r) => r.toLowerCase().includes('spin-off'))
  ).length;
  const prequelSequelCount = uniqueEntries.filter((e) =>
    e.relationships.some((r) => {
      const l = r.toLowerCase();
      return l.includes('prequel') || l.includes('sequel');
    })
  ).length;

  return {
    id: seed.id,
    name: seed.name,
    description: seed.description,
    originCountry: seed.originCountry,
    mediaScope: seed.mediaScope,
    posterUrl: null,
    backdropUrl: null,
    orderAttribution: seed.orderAttribution,
    sourceNote: seed.sourceNote,
    disputedOrderNote: seed.disputedOrderNote || null,
    orderNotes: seed.orderNotes,
    searchAliases: seed.searchAliases,
    relatedFranchiseIds: seed.relatedFranchiseIds || [],
    confirmedMovieCount,
    confirmedSeriesCount,
    spinoffCount,
    prequelSequelCount,
    isCustom: false,
    isPublished: true,
    orders: {
      recommended: buildOrderList(seed.entries, seed.orders.recommended),
      release: buildOrderList(seed.entries, seed.orders.release),
      chronological: buildOrderList(seed.entries, seed.orders.chronological),
      complete: buildOrderList(seed.entries, seed.orders.complete),
    },
  };
}

/**
 * Verified and transparently attributed franchise catalogs using live-verified
 * TMDB, AniList/MyAnimeList (jikan), and TVMaze IDs.
 * Poster artwork, runtimes, seasons/episodes, and regional streaming providers
 * are enriched dynamically from upstream APIs.
 */
export const CURATED_FRANCHISES: FranchiseDetail[] = [
  // =========================================================================
  // 1. AVENGERS SAGA (Focused Guide linked to Complete MCU)
  // =========================================================================
  defineFranchise({
    id: 'avengers-saga',
    name: 'The Avengers Saga (Focused Team-Up Guide)',
    description:
      'Earth’s Mightiest Heroes assemble across four landmark ensemble films—plus the pivotal Avengers schism in Captain America: Civil War—forming the narrative spine of the Infinity Saga.',
    originCountry: 'United States',
    mediaScope: 'Core Avengers Ensemble Films & Essential Bridge',
    orderAttribution: 'Verified Official Order',
    sourceNote:
      'Verified against Marvel Studios official theatrical release sequence. For every solo origin and Multiverse Saga Disney+ series, switch to the Complete Marvel Cinematic Universe guide.',
    disputedOrderNote:
      'Captain America: Civil War (2016) is officially a Captain America film, yet it directly fractures the Avengers roster between Age of Ultron and Infinity War. Recommended and Complete tabs include Civil War; Release Order can be watched either standalone or alongside the full MCU.',
    orderNotes: {
      recommended:
        'Includes Captain America: Civil War between Age of Ultron and Infinity War so the broken team dynamic entering Infinity War makes complete sense.',
      release: 'The four headline Avengers films in theatrical release order.',
      chronological: 'Chronological progression from the 2012 Battle of New York to the 2023 Time Heist.',
      complete: 'All four Avengers films plus Captain America: Civil War as the essential bridge.',
    },
    searchAliases: [
      'avengers',
      'the avengers',
      'infinity war',
      'endgame',
      'age of ultron',
      'earth mightiest heroes',
      'thanos',
      'marvel avengers',
    ],
    relatedFranchiseIds: ['marvel-cinematic-universe'],
    entries: {
      tmdb_movie_24428: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '24428',
        title: 'The Avengers',
        releaseYear: 2012,
        entryType: 'Movie',
        relationships: ['Core Entry', 'Crossover', 'Shared Universe'],
        description: 'Nick Fury unites Iron Man, Captain America, Thor, Hulk, Black Widow, and Hawkeye against Loki’s Chitauri invasion.',
        defaultNote: 'Phase 1 culmination — formation of the original six Avengers.',
      },
      tmdb_movie_99861: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '99861',
        title: 'Avengers: Age of Ultron',
        releaseYear: 2015,
        entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Crossover', 'Shared Universe'],
        description: 'Tony Stark’s peacekeeping AI awakens with a plan for human extinction, introducing Vision and Wanda Maximoff.',
        defaultNote: 'Phase 2 crossover — Sokovia fallout directly triggers the Sokovia Accords.',
      },
      tmdb_movie_271110: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '271110',
        title: 'Captain America: Civil War',
        releaseYear: 2016,
        entryType: 'Crossover',
        relationships: ['Crossover', 'Sequel', 'Shared Universe'],
        description: 'Government oversight divides Steve Rogers and Tony Stark into opposing factions, fracturing the Avengers.',
        defaultNote: 'Essential Avengers bridge ("Avengers 2.5") introducing Spider-Man and Black Panther.',
      },
      tmdb_movie_299536: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '299536',
        title: 'Avengers: Infinity War',
        releaseYear: 2018,
        entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Crossover', 'Shared Universe'],
        description: 'The splintered Avengers and Guardians of the Galaxy race to stop Thanos from assembling all six Infinity Stones.',
        defaultNote: 'Part 1 of the Infinity Saga climax.',
      },
      tmdb_movie_299534: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '299534',
        title: 'Avengers: Endgame',
        releaseYear: 2019,
        entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Crossover', 'Shared Universe'],
        description: 'Five years after the Blip, the surviving Avengers launch a daring quantum time heist to undo Thanos’s snap.',
        defaultNote: 'Culmination of the 22-film Infinity Saga.',
      },
    },
    orders: {
      recommended: [
        'tmdb_movie_24428',
        'tmdb_movie_99861',
        ['tmdb_movie_271110', 'Essential bridge explaining why the Avengers are divided in Infinity War'],
        'tmdb_movie_299536',
        'tmdb_movie_299534',
      ],
      release: ['tmdb_movie_24428', 'tmdb_movie_99861', 'tmdb_movie_299536', 'tmdb_movie_299534'],
      chronological: [
        ['tmdb_movie_24428', 'Set in May 2012 (Battle of New York)'],
        ['tmdb_movie_99861', 'Set in 2015 (Battle of Sokovia)'],
        ['tmdb_movie_271110', 'Set in 2016 (Sokovia Accords)'],
        ['tmdb_movie_299536', 'Set in 2018 (The Snap)'],
        ['tmdb_movie_299534', 'Set in 2018 & 2023 (The Blip reversed)'],
      ],
      complete: [
        'tmdb_movie_24428',
        'tmdb_movie_99861',
        'tmdb_movie_271110',
        'tmdb_movie_299536',
        'tmdb_movie_299534',
      ],
    },
  }),

  // =========================================================================
  // 2. MARVEL CINEMATIC UNIVERSE (Complete Saga)
  // =========================================================================
  defineFranchise({
    id: 'marvel-cinematic-universe',
    name: 'Marvel Cinematic Universe (Complete Saga)',
    description:
      'Marvel Studios’ interconnected shared universe spanning the complete Infinity Saga (Phases 1–3) and pivotal Multiverse Saga theatrical films and Disney+ series.',
    originCountry: 'United States',
    mediaScope: 'Feature Films & Flagship Disney+ Series',
    orderAttribution: 'Verified Official Order',
    sourceNote:
      'Verified against Marvel Studios’ official Phase release slate and Disney+ official MCU Timeline Order.',
    disputedOrderNote:
      'First-time viewers are strongly advised to watch in Release / Recommended Order: Captain Marvel (set in 1995), Black Widow (set in 2016), and Ant-Man and the Wasp contain post-credits scenes that directly spoil Avengers: Infinity War and Endgame if watched purely chronologically.',
    orderNotes: {
      recommended:
        'Follows theatrical release pacing so post-credits scenes and Infinity Stone reveals land without spoilers.',
      release: 'Strict theatrical and Disney+ premiere release order.',
      chronological:
        'In-universe timeline order per Marvel Studios’ official chronology (starting with 1940s Captain America and 1995 Captain Marvel).',
      complete: 'Complete curated guide covering Infinity Saga films and major Multiverse Saga movies & series.',
    },
    searchAliases: [
      'marvel',
      'mcu',
      'marvel cinematic universe',
      'avengers',
      'iron man',
      'tony stark',
      'captain america',
      'steve rogers',
      'thor',
      'hulk',
      'guardians of the galaxy',
      'spider-man',
      'peter parker',
      'doctor strange',
      'black panther',
      'wakanda',
      'ant-man',
      'black widow',
      'wandavision',
      'loki',
      'shang-chi',
      'deadpool',
      'wolverine',
      'thanos',
    ],
    relatedFranchiseIds: ['avengers-saga'],
    entries: {
      tmdb_movie_1726: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '1726',
        title: 'Iron Man',
        releaseYear: 2008,
        entryType: 'Movie',
        relationships: ['Core Entry', 'Shared Universe'],
        description: 'Billionaire inventor Tony Stark builds a powered suit of armor after escaping captivity and launches the MCU.',
        defaultNote: 'Phase 1 launch — introduces Tony Stark and Nick Fury’s Avengers Initiative.',
      },
      tmdb_movie_1724: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '1724',
        title: 'The Incredible Hulk',
        releaseYear: 2008,
        entryType: 'Movie',
        relationships: ['Shared Universe'],
        description: 'Bruce Banner searches for a cure while pursued by General Thaddeus Ross and Emil Blonsky.',
        defaultNote: 'Phase 1 — takes place during "Fury’s Big Week" alongside Iron Man 2 and Thor.',
      },
      tmdb_movie_10138: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '10138',
        title: 'Iron Man 2',
        releaseYear: 2010,
        entryType: 'Sequel',
        relationships: ['Sequel', 'Shared Universe'],
        description: 'Tony Stark confronts palladium poisoning, Ivan Vanko, and S.H.I.E.L.D. agent Natasha Romanoff.',
        defaultNote: 'Phase 1 — introduces Black Widow and War Machine.',
      },
      tmdb_movie_10195: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '10195',
        title: 'Thor',
        releaseYear: 2011,
        entryType: 'Movie',
        relationships: ['Core Entry', 'Shared Universe'],
        description: 'Banished from Asgard to Earth, Thor must prove himself worthy while Loki schemes for the throne.',
        defaultNote: 'Phase 1 — introduces Asgard, Loki, and Hawkeye.',
      },
      tmdb_movie_1771: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '1771',
        title: 'Captain America: The First Avenger',
        releaseYear: 2011,
        entryType: 'Prequel',
        relationships: ['Core Entry', 'Prequel', 'Shared Universe'],
        description: 'During World War II, Steve Rogers becomes super-soldier Captain America to battle Hydra and the Tesseract.',
        defaultNote: 'Chronological opening (1942–1945) — introduces the Space Stone.',
      },
      tmdb_movie_24428: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '24428',
        title: 'The Avengers',
        releaseYear: 2012,
        entryType: 'Crossover',
        relationships: ['Core Entry', 'Crossover', 'Shared Universe'],
        description: 'Earth’s Mightiest Heroes assemble for the first time to defend New York from Loki and the Chitauri.',
        defaultNote: 'Phase 1 finale — introduces the Mind Stone and teases Thanos.',
      },
      tmdb_movie_68721: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '68721',
        title: 'Iron Man 3',
        releaseYear: 2013,
        entryType: 'Sequel',
        relationships: ['Sequel', 'Shared Universe'],
        description: 'Haunted by the Battle of New York, Tony Stark faces Aldrich Killian and the Extremis conspiracy.',
        defaultNote: 'Phase 2 opener.',
      },
      tmdb_movie_76338: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '76338',
        title: 'Thor: The Dark World',
        releaseYear: 2013,
        entryType: 'Sequel',
        relationships: ['Sequel', 'Shared Universe'],
        description: 'Thor reluctantly allies with Loki to stop Malekith from using the Aether during the Convergence.',
        defaultNote: 'Phase 2 — introduces the Reality Stone.',
      },
      tmdb_movie_100402: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '100402',
        title: 'Captain America: The Winter Soldier',
        releaseYear: 2014,
        entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Shared Universe'],
        description: 'Steve Rogers and Natasha Romanoff uncover a Hydra conspiracy inside S.H.I.E.L.D. and confront the Winter Soldier.',
        defaultNote: 'Phase 2 turning point — reshapes S.H.I.E.L.D. and introduces Sam Wilson.',
      },
      tmdb_movie_118340: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '118340',
        title: 'Guardians of the Galaxy',
        releaseYear: 2014,
        entryType: 'Movie',
        relationships: ['Core Entry', 'Shared Universe'],
        description: 'A band of cosmic misfits led by Peter Quill unites to keep the Power Stone from Ronan the Accuser.',
        defaultNote: 'Phase 2 — expands the cosmic MCU and introduces the Power Stone.',
      },
      tmdb_movie_99861: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '99861',
        title: 'Avengers: Age of Ultron',
        releaseYear: 2015,
        entryType: 'Crossover',
        relationships: ['Core Entry', 'Sequel', 'Crossover', 'Shared Universe'],
        description: 'The Avengers battle Ultron in Sokovia, birthing Vision and setting the stage for Civil War.',
        defaultNote: 'Phase 2 crossover.',
      },
      tmdb_movie_102899: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '102899',
        title: 'Ant-Man',
        releaseYear: 2015,
        entryType: 'Movie',
        relationships: ['Shared Universe'],
        description: 'Former thief Scott Lang inherits Hank Pym’s size-shifting suit and enters the Quantum Realm.',
        defaultNote: 'Phase 2 finale — introduces Quantum Realm physics vital to Endgame.',
      },
      tmdb_movie_271110: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '271110',
        title: 'Captain America: Civil War',
        releaseYear: 2016,
        entryType: 'Crossover',
        relationships: ['Core Entry', 'Sequel', 'Crossover', 'Shared Universe'],
        description: 'The Sokovia Accords divide Captain America and Iron Man, introducing Black Panther and Spider-Man.',
        defaultNote: 'Phase 3 opener — fractures the Avengers ahead of Infinity War.',
      },
      tmdb_movie_284052: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '284052',
        title: 'Doctor Strange',
        releaseYear: 2016,
        entryType: 'Movie',
        relationships: ['Core Entry', 'Shared Universe'],
        description: 'Neurosurgeon Stephen Strange trains in Kamar-Taj and defends Earth using the Eye of Agamotto.',
        defaultNote: 'Phase 3 — introduces mystic arts and the Time Stone.',
      },
      tmdb_movie_283995: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '283995',
        title: 'Guardians of the Galaxy Vol. 2',
        releaseYear: 2017,
        entryType: 'Sequel',
        relationships: ['Sequel', 'Shared Universe'],
        description: 'The Guardians unravel the mystery of Peter Quill’s celestial heritage.',
        defaultNote: 'Chronologically set just months after Vol. 1 (late 2014).',
      },
      tmdb_movie_315635: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '315635',
        title: 'Spider-Man: Homecoming',
        releaseYear: 2017,
        entryType: 'Movie',
        relationships: ['Spin-off', 'Shared Universe'],
        description: 'After Berlin, young Peter Parker tries to balance high school with stopping Adrian Toomes’s weapons ring.',
        defaultNote: 'Follows directly after Spider-Man’s debut in Civil War.',
      },
      tmdb_movie_284053: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '284053',
        title: 'Thor: Ragnarok',
        releaseYear: 2017,
        entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Shared Universe'],
        description: 'Imprisoned on Sakaar with Hulk, Thor races to stop Hela from destroying Asgard.',
        defaultNote: 'Leads directly into the opening scene of Infinity War.',
      },
      tmdb_movie_284054: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '284054',
        title: 'Black Panther',
        releaseYear: 2018,
        entryType: 'Movie',
        relationships: ['Core Entry', 'Spin-off', 'Shared Universe'],
        description: 'T’Challa returns to Wakanda to claim the throne and confronts Erik Killmonger.',
        defaultNote: 'Chronologically set immediately after Civil War (2016).',
      },
      tmdb_movie_299536: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '299536',
        title: 'Avengers: Infinity War',
        releaseYear: 2018,
        entryType: 'Crossover',
        relationships: ['Core Entry', 'Sequel', 'Crossover', 'Shared Universe'],
        description: 'Every corner of the MCU collides as Thanos hunts down the six Infinity Stones.',
        defaultNote: 'Infinity Saga climax Part 1.',
      },
      tmdb_movie_363088: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '363088',
        title: 'Ant-Man and the Wasp',
        releaseYear: 2018,
        entryType: 'Sequel',
        relationships: ['Sequel', 'Shared Universe'],
        description: 'Scott Lang and Hope van Dyne attempt to rescue Janet van Dyne from the Quantum Realm.',
        defaultNote: 'Set just before Infinity War; post-credits directly sets up Endgame.',
      },
      tmdb_movie_299537: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '299537',
        title: 'Captain Marvel',
        releaseYear: 2019,
        entryType: 'Prequel',
        relationships: ['Prequel', 'Shared Universe'],
        description: 'Set in 1995, Carol Danvers uncovers her Earth past amid the Kree-Skrull conflict.',
        defaultNote: 'Chronologically #2 (1995), but watch before Endgame for post-credits continuity.',
      },
      tmdb_movie_299534: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '299534',
        title: 'Avengers: Endgame',
        releaseYear: 2019,
        entryType: 'Crossover',
        relationships: ['Core Entry', 'Sequel', 'Crossover', 'Shared Universe'],
        description: 'The Avengers reunite for one final mission across time to restore half of all life.',
        defaultNote: 'Infinity Saga culmination.',
      },
      tmdb_movie_429617: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '429617',
        title: 'Spider-Man: Far From Home',
        releaseYear: 2019,
        entryType: 'Sequel',
        relationships: ['Sequel', 'Shared Universe'],
        description: 'On a European school trip after Endgame, Peter Parker encounters Quentin Beck (Mysterio).',
        defaultNote: 'Infinity Saga epilogue.',
      },
      tmdb_tv_85271: {
        source: 'tmdb',
        mediaType: 'tv',
        externalId: '85271',
        title: 'WandaVision',
        releaseYear: 2021,
        entryType: 'Series',
        relationships: ['Spin-off', 'Shared Universe'],
        description: 'Grieving after Endgame, Wanda Maximoff creates a sitcom reality in Westview, New Jersey.',
        defaultNote: 'Phase 4 opener — directly sets up Doctor Strange in the Multiverse of Madness.',
        totalSeasons: 1,
        totalEpisodes: 9,
      },
      tmdb_tv_88396: {
        source: 'tmdb',
        mediaType: 'tv',
        externalId: '88396',
        title: 'The Falcon and the Winter Soldier',
        releaseYear: 2021,
        entryType: 'Series',
        relationships: ['Spin-off', 'Sequel', 'Shared Universe'],
        description: 'Sam Wilson and Bucky Barnes wrestle with the legacy of Captain America’s shield.',
        defaultNote: 'Phase 4 Disney+ series.',
        totalSeasons: 1,
        totalEpisodes: 6,
      },
      tmdb_tv_84958: {
        source: 'tmdb',
        mediaType: 'tv',
        externalId: '84958',
        title: 'Loki',
        releaseYear: 2021,
        entryType: 'Series',
        relationships: ['Core Entry', 'Spin-off', 'Shared Universe'],
        description: 'An alternate 2012 Loki is arrested by the Time Variance Authority and unravels the Multiverse.',
        defaultNote: 'Key Multiverse Saga pillar (2 seasons).',
        totalSeasons: 2,
        totalEpisodes: 12,
      },
      tmdb_movie_497698: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '497698',
        title: 'Black Widow',
        releaseYear: 2021,
        entryType: 'Prequel',
        relationships: ['Prequel', 'Spin-off', 'Shared Universe'],
        description: 'On the run after Civil War, Natasha Romanoff confronts her Red Room past and sister Yelena Belova.',
        defaultNote: 'Main story set in 2016; post-credits takes place post-Endgame.',
      },
      tmdb_movie_566525: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '566525',
        title: 'Shang-Chi and the Legend of the Ten Rings',
        releaseYear: 2021,
        entryType: 'Movie',
        relationships: ['Shared Universe'],
        description: 'Shang-Chi must confront the father he left behind and the mystic power of the Ten Rings.',
        defaultNote: 'Phase 4 martial arts origin.',
      },
      tmdb_movie_634649: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '634649',
        title: 'Spider-Man: No Way Home',
        releaseYear: 2021,
        entryType: 'Crossover',
        relationships: ['Core Entry', 'Sequel', 'Crossover', 'Shared Universe'],
        description: 'A fractured spell pulls Spider-Man villains and multiversal allies into Peter Parker’s world.',
        defaultNote: 'Phase 4 multiversal crossover.',
      },
      tmdb_movie_453395: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '453395',
        title: 'Doctor Strange in the Multiverse of Madness',
        releaseYear: 2022,
        entryType: 'Sequel',
        relationships: ['Sequel', 'Crossover', 'Shared Universe'],
        description: 'Doctor Strange protects America Chavez across parallel realities from the Scarlet Witch.',
        defaultNote: 'Direct follow-up to WandaVision and No Way Home.',
      },
      tmdb_movie_447365: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '447365',
        title: 'Guardians of the Galaxy Vol. 3',
        releaseYear: 2023,
        entryType: 'Sequel',
        relationships: ['Sequel', 'Shared Universe'],
        description: 'The Guardians embark on a high-stakes mission to save Rocket’s life and confront the High Evolutionary.',
        defaultNote: 'Phase 5 — emotional finale for the original Guardians team.',
      },
      tmdb_movie_533535: {
        source: 'tmdb',
        mediaType: 'movie',
        externalId: '533535',
        title: 'Deadpool & Wolverine',
        releaseYear: 2024,
        entryType: 'Crossover',
        relationships: ['Crossover', 'Shared Universe'],
        description: 'Wade Wilson recruits a reluctant Wolverine variant with TVA intervention to save his timeline.',
        defaultNote: 'Phase 5 — ties into Loki’s TVA multiverse lore.',
      },
    },
    orders: {
      recommended: [
        'tmdb_movie_1726', 'tmdb_movie_1724', 'tmdb_movie_10138', 'tmdb_movie_10195', 'tmdb_movie_1771',
        'tmdb_movie_24428', 'tmdb_movie_68721', 'tmdb_movie_76338', 'tmdb_movie_100402', 'tmdb_movie_118340',
        'tmdb_movie_99861', 'tmdb_movie_102899', 'tmdb_movie_271110', 'tmdb_movie_284052', 'tmdb_movie_283995',
        'tmdb_movie_315635', 'tmdb_movie_284053', 'tmdb_movie_284054', 'tmdb_movie_299536', 'tmdb_movie_363088',
        'tmdb_movie_299537', 'tmdb_movie_299534', 'tmdb_movie_429617', 'tmdb_tv_85271', 'tmdb_tv_88396',
        'tmdb_tv_84958', 'tmdb_movie_497698', 'tmdb_movie_566525', 'tmdb_movie_634649', 'tmdb_movie_453395',
        'tmdb_movie_447365', 'tmdb_movie_533535',
      ],
      release: [
        'tmdb_movie_1726', 'tmdb_movie_1724', 'tmdb_movie_10138', 'tmdb_movie_10195', 'tmdb_movie_1771',
        'tmdb_movie_24428', 'tmdb_movie_68721', 'tmdb_movie_76338', 'tmdb_movie_100402', 'tmdb_movie_118340',
        'tmdb_movie_99861', 'tmdb_movie_102899', 'tmdb_movie_271110', 'tmdb_movie_284052', 'tmdb_movie_283995',
        'tmdb_movie_315635', 'tmdb_movie_284053', 'tmdb_movie_284054', 'tmdb_movie_299536', 'tmdb_movie_363088',
        'tmdb_movie_299537', 'tmdb_movie_299534', 'tmdb_movie_429617', 'tmdb_tv_85271', 'tmdb_tv_88396',
        'tmdb_tv_84958', 'tmdb_movie_497698', 'tmdb_movie_566525', 'tmdb_movie_634649', 'tmdb_movie_453395',
        'tmdb_movie_447365', 'tmdb_movie_533535',
      ],
      chronological: [
        ['tmdb_movie_1771', 'Set in 1942–1945 (WWII)'],
        ['tmdb_movie_299537', 'Set in 1995 (Skip mid-credits scene if first watch)'],
        ['tmdb_movie_1726', 'Set in 2008–2010'],
        ['tmdb_movie_10138', 'Set in 2010 (Fury’s Big Week)'],
        ['tmdb_movie_1724', 'Set in 2010 (Fury’s Big Week)'],
        ['tmdb_movie_10195', 'Set in 2010 (Fury’s Big Week)'],
        ['tmdb_movie_24428', 'Set in May 2012'],
        ['tmdb_movie_76338', 'Set in 2013'],
        ['tmdb_movie_68721', 'Set in December 2013'],
        ['tmdb_movie_100402', 'Set in 2014'],
        ['tmdb_movie_118340', 'Set in 2014'],
        ['tmdb_movie_283995', 'Set in late 2014 (months after Vol. 1)'],
        ['tmdb_movie_99861', 'Set in 2015'],
        ['tmdb_movie_102899', 'Set in 2015'],
        ['tmdb_movie_271110', 'Set in 2016'],
        ['tmdb_movie_497698', 'Main story set immediately after Civil War (2016)'],
        ['tmdb_movie_284054', 'Set days after Civil War (2016)'],
        ['tmdb_movie_315635', 'Set autumn 2016'],
        ['tmdb_movie_284052', 'Set 2016–2017'],
        ['tmdb_movie_284053', 'Set late 2017, ending right before Infinity War'],
        ['tmdb_movie_363088', 'Main story concurrent with Infinity War (2018)'],
        ['tmdb_movie_299536', 'Set in 2018'],
        ['tmdb_movie_299534', 'Set in 2018 & 2023'],
        ['tmdb_tv_84958', 'Branches directly from Endgame’s 2012 sequence (exists outside time)'],
        ['tmdb_tv_85271', 'Set weeks after Endgame (late 2023)'],
        ['tmdb_movie_566525', 'Set spring 2024'],
        ['tmdb_tv_88396', 'Set spring 2024'],
        ['tmdb_movie_429617', 'Set summer 2024'],
        ['tmdb_movie_634649', 'Set summer–winter 2024'],
        ['tmdb_movie_453395', 'Set late 2024'],
        ['tmdb_movie_447365', 'Set in 2026'],
        ['tmdb_movie_533535', 'Set in 2024+ (Multiverse TVA timeline)'],
      ],
      complete: [
        'tmdb_movie_1726', 'tmdb_movie_1724', 'tmdb_movie_10138', 'tmdb_movie_10195', 'tmdb_movie_1771',
        'tmdb_movie_24428', 'tmdb_movie_68721', 'tmdb_movie_76338', 'tmdb_movie_100402', 'tmdb_movie_118340',
        'tmdb_movie_99861', 'tmdb_movie_102899', 'tmdb_movie_271110', 'tmdb_movie_284052', 'tmdb_movie_283995',
        'tmdb_movie_315635', 'tmdb_movie_284053', 'tmdb_movie_284054', 'tmdb_movie_299536', 'tmdb_movie_363088',
        'tmdb_movie_299537', 'tmdb_movie_299534', 'tmdb_movie_429617', 'tmdb_tv_85271', 'tmdb_tv_88396',
        'tmdb_tv_84958', 'tmdb_movie_497698', 'tmdb_movie_566525', 'tmdb_movie_634649', 'tmdb_movie_453395',
        'tmdb_movie_447365', 'tmdb_movie_533535',
      ],
    },
  }),

  // =========================================================================
  // 3. HARRY POTTER (8-Film Core Guide)
  // =========================================================================
  defineFranchise({
    id: 'harry-potter',
    name: 'Harry Potter',
    description:
      'All eight theatrical films chronicling Harry Potter, Hermione Granger, and Ron Weasley across their seven years at Hogwarts School of Witchcraft and Wizardry.',
    originCountry: 'United Kingdom',
    mediaScope: '8 Theatrical Feature Films',
    orderAttribution: 'Verified Official Order',
    sourceNote:
      'Verified against Warner Bros. Pictures official Hogwarts film chronology (1991–1998 in-universe). For the 1920s Fantastic Beasts prequels, open the Complete Wizarding World guide.',
    searchAliases: [
      'harry potter',
      'hogwarts',
      'voldemort',
      'hermione granger',
      'ron weasley',
      'dumbledore',
      'snape',
      'philosopher stone',
      'sorcerer stone',
      'deathly hallows',
      'wizarding world',
    ],
    relatedFranchiseIds: ['wizarding-world'],
    entries: {
      tmdb_movie_671: {
        source: 'tmdb', mediaType: 'movie', externalId: '671',
        title: "Harry Potter and the Philosopher's Stone", releaseYear: 2001, entryType: 'Movie',
        relationships: ['Core Entry'],
        description: 'An orphaned boy discovers he is a wizard and enters his first year at Hogwarts.',
        defaultNote: 'Year 1 at Hogwarts (1991–1992).',
      },
      tmdb_movie_672: {
        source: 'tmdb', mediaType: 'movie', externalId: '672',
        title: 'Harry Potter and the Chamber of Secrets', releaseYear: 2002, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Mysterious attacks petrify Hogwarts students as an ancient chamber is reopened.',
        defaultNote: 'Year 2 at Hogwarts (1992–1993).',
      },
      tmdb_movie_673: {
        source: 'tmdb', mediaType: 'movie', externalId: '673',
        title: 'Harry Potter and the Prisoner of Azkaban', releaseYear: 2004, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Escaped convict Sirius Black looms over Harry’s third year as Dementors guard the castle.',
        defaultNote: 'Year 3 at Hogwarts (1993–1994).',
      },
      tmdb_movie_674: {
        source: 'tmdb', mediaType: 'movie', externalId: '674',
        title: 'Harry Potter and the Goblet of Fire', releaseYear: 2005, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Harry is unexpectedly entered into the perilous Triwizard Tournament.',
        defaultNote: 'Year 4 at Hogwarts (1994–1995) — Lord Voldemort returns.',
      },
      tmdb_movie_675: {
        source: 'tmdb', mediaType: 'movie', externalId: '675',
        title: 'Harry Potter and the Order of the Phoenix', releaseYear: 2007, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'With the Ministry in denial, Harry trains Dumbledore’s Army to prepare for coming war.',
        defaultNote: 'Year 5 at Hogwarts (1995–1996).',
      },
      tmdb_movie_767: {
        source: 'tmdb', mediaType: 'movie', externalId: '767',
        title: 'Harry Potter and the Half-Blood Prince', releaseYear: 2009, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Dumbledore reveals Tom Riddle’s past and the secret of the Horcruxes.',
        defaultNote: 'Year 6 at Hogwarts (1996–1997).',
      },
      tmdb_movie_12444: {
        source: 'tmdb', mediaType: 'movie', externalId: '12444',
        title: 'Harry Potter and the Deathly Hallows: Part 1', releaseYear: 2010, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Harry, Ron, and Hermione go on the run across Britain to hunt down Voldemort’s Horcruxes.',
        defaultNote: 'Year 7 Part 1 (1997–1998).',
      },
      tmdb_movie_12445: {
        source: 'tmdb', mediaType: 'movie', externalId: '12445',
        title: 'Harry Potter and the Deathly Hallows: Part 2', releaseYear: 2011, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'The final battle for Hogwarts decides the fate of the Wizarding World.',
        defaultNote: 'Series finale (1998 + 2017 epilogue).',
      },
    },
    orders: {
      recommended: ['tmdb_movie_671', 'tmdb_movie_672', 'tmdb_movie_673', 'tmdb_movie_674', 'tmdb_movie_675', 'tmdb_movie_767', 'tmdb_movie_12444', 'tmdb_movie_12445'],
      release: ['tmdb_movie_671', 'tmdb_movie_672', 'tmdb_movie_673', 'tmdb_movie_674', 'tmdb_movie_675', 'tmdb_movie_767', 'tmdb_movie_12444', 'tmdb_movie_12445'],
      chronological: ['tmdb_movie_671', 'tmdb_movie_672', 'tmdb_movie_673', 'tmdb_movie_674', 'tmdb_movie_675', 'tmdb_movie_767', 'tmdb_movie_12444', 'tmdb_movie_12445'],
      complete: ['tmdb_movie_671', 'tmdb_movie_672', 'tmdb_movie_673', 'tmdb_movie_674', 'tmdb_movie_675', 'tmdb_movie_767', 'tmdb_movie_12444', 'tmdb_movie_12445'],
    },
  }),

  // =========================================================================
  // 4. WIZARDING WORLD: FANTASTIC BEASTS & HARRY POTTER
  // =========================================================================
  defineFranchise({
    id: 'wizarding-world',
    name: 'Wizarding World (Fantastic Beasts & Harry Potter)',
    description:
      'The complete 11-film Wizarding World canon uniting Newt Scamander and Albus Dumbledore’s 1920s–1930s struggle against Gellert Grindelwald with the entire Harry Potter saga.',
    originCountry: 'United Kingdom',
    mediaScope: '11 Theatrical Films (Prequel Trilogy + Core Saga)',
    orderAttribution: 'Verified Official Order',
    sourceNote:
      'Verified against Warner Bros. Wizarding World official canon timeline (1926–1998).',
    disputedOrderNote:
      'First-time viewers are advised to watch Harry Potter (1–8) before Fantastic Beasts so Hogwarts lore, Dumbledore’s backstory, and Grindelwald’s history carry full emotional weight. Chronological order places the three Fantastic Beasts prequels first.',
    searchAliases: [
      'fantastic beasts',
      'wizarding world',
      'newt scamander',
      'grindelwald',
      'secrets of dumbledore',
      'crimes of grindelwald',
      'harry potter',
    ],
    relatedFranchiseIds: ['harry-potter'],
    entries: {
      tmdb_movie_259316: {
        source: 'tmdb', mediaType: 'movie', externalId: '259316',
        title: 'Fantastic Beasts and Where to Find Them', releaseYear: 2016, entryType: 'Prequel',
        relationships: ['Prequel', 'Spin-off', 'Shared Universe'],
        description: 'Magizoologist Newt Scamander arrives in 1926 New York as magical creatures escape his enchanted case.',
        defaultNote: 'Set in 1926 — 65 years before Harry Potter enters Hogwarts.',
      },
      tmdb_movie_338952: {
        source: 'tmdb', mediaType: 'movie', externalId: '338952',
        title: 'Fantastic Beasts: The Crimes of Grindelwald', releaseYear: 2018, entryType: 'Prequel',
        relationships: ['Prequel', 'Sequel', 'Spin-off', 'Shared Universe'],
        description: 'Albus Dumbledore enlists Newt Scamander to thwart Grindelwald’s rise in 1927 Paris.',
        defaultNote: 'Set in 1927.',
      },
      tmdb_movie_338953: {
        source: 'tmdb', mediaType: 'movie', externalId: '338953',
        title: 'Fantastic Beasts: The Secrets of Dumbledore', releaseYear: 2022, entryType: 'Prequel',
        relationships: ['Prequel', 'Sequel', 'Spin-off', 'Shared Universe'],
        description: 'Dumbledore assembles an unlikely team to disrupt Grindelwald’s bid to control the wizarding world.',
        defaultNote: 'Set in 1932.',
      },
      tmdb_movie_671: {
        source: 'tmdb', mediaType: 'movie', externalId: '671',
        title: "Harry Potter and the Philosopher's Stone", releaseYear: 2001, entryType: 'Movie',
        relationships: ['Core Entry', 'Shared Universe'],
        description: 'Harry Potter discovers Hogwarts and the magical world.',
        defaultNote: 'Set in 1991–1992.',
      },
      tmdb_movie_672: {
        source: 'tmdb', mediaType: 'movie', externalId: '672',
        title: 'Harry Potter and the Chamber of Secrets', releaseYear: 2002, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Shared Universe'],
        description: 'The heir of Slytherin threatens Hogwarts during Harry’s second year.',
        defaultNote: 'Set in 1992–1993.',
      },
      tmdb_movie_673: {
        source: 'tmdb', mediaType: 'movie', externalId: '673',
        title: 'Harry Potter and the Prisoner of Azkaban', releaseYear: 2004, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Shared Universe'],
        description: 'Sirius Black escapes Azkaban and secrets of Harry’s parents surface.',
        defaultNote: 'Set in 1993–1994.',
      },
      tmdb_movie_674: {
        source: 'tmdb', mediaType: 'movie', externalId: '674',
        title: 'Harry Potter and the Goblet of Fire', releaseYear: 2005, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Shared Universe'],
        description: 'The Triwizard Tournament turns deadly as Voldemort rises again.',
        defaultNote: 'Set in 1994–1995.',
      },
      tmdb_movie_675: {
        source: 'tmdb', mediaType: 'movie', externalId: '675',
        title: 'Harry Potter and the Order of the Phoenix', releaseYear: 2007, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Shared Universe'],
        description: 'Students secretly train to resist Voldemort and Ministry interference.',
        defaultNote: 'Set in 1995–1996.',
      },
      tmdb_movie_767: {
        source: 'tmdb', mediaType: 'movie', externalId: '767',
        title: 'Harry Potter and the Half-Blood Prince', releaseYear: 2009, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Shared Universe'],
        description: 'Harry and Dumbledore probe Voldemort’s past to locate the Horcruxes.',
        defaultNote: 'Set in 1996–1997.',
      },
      tmdb_movie_12444: {
        source: 'tmdb', mediaType: 'movie', externalId: '12444',
        title: 'Harry Potter and the Deathly Hallows: Part 1', releaseYear: 2010, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Shared Universe'],
        description: 'The trio leaves Hogwarts to destroy the Horcruxes.',
        defaultNote: 'Set in 1997–1998.',
      },
      tmdb_movie_12445: {
        source: 'tmdb', mediaType: 'movie', externalId: '12445',
        title: 'Harry Potter and the Deathly Hallows: Part 2', releaseYear: 2011, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Shared Universe'],
        description: 'The culminating Battle of Hogwarts.',
        defaultNote: 'Set in 1998.',
      },
    },
    orders: {
      recommended: [
        'tmdb_movie_671', 'tmdb_movie_672', 'tmdb_movie_673', 'tmdb_movie_674',
        'tmdb_movie_675', 'tmdb_movie_767', 'tmdb_movie_12444', 'tmdb_movie_12445',
        ['tmdb_movie_259316', 'Begin the 1920s Grindelwald prequel era after finishing Hogwarts'],
        'tmdb_movie_338952', 'tmdb_movie_338953',
      ],
      release: [
        'tmdb_movie_671', 'tmdb_movie_672', 'tmdb_movie_673', 'tmdb_movie_674',
        'tmdb_movie_675', 'tmdb_movie_767', 'tmdb_movie_12444', 'tmdb_movie_12445',
        'tmdb_movie_259316', 'tmdb_movie_338952', 'tmdb_movie_338953',
      ],
      chronological: [
        ['tmdb_movie_259316', '1926 — New York'],
        ['tmdb_movie_338952', '1927 — Paris'],
        ['tmdb_movie_338953', '1932 — Bhutan & Berlin'],
        ['tmdb_movie_671', '1991 — Harry’s Year 1'],
        'tmdb_movie_672', 'tmdb_movie_673', 'tmdb_movie_674', 'tmdb_movie_675',
        'tmdb_movie_767', 'tmdb_movie_12444', 'tmdb_movie_12445',
      ],
      complete: [
        'tmdb_movie_259316', 'tmdb_movie_338952', 'tmdb_movie_338953',
        'tmdb_movie_671', 'tmdb_movie_672', 'tmdb_movie_673', 'tmdb_movie_674',
        'tmdb_movie_675', 'tmdb_movie_767', 'tmdb_movie_12444', 'tmdb_movie_12445',
      ],
    },
  }),

  // =========================================================================
  // 5. STAR WARS
  // =========================================================================
  defineFranchise({
    id: 'star-wars',
    name: 'Star Wars',
    description:
      'George Lucas and Lucasfilm’s galactic space opera spanning the nine-film Skywalker Saga, anthology films Rogue One and Solo, and canonical live-action & animated television series.',
    originCountry: 'United States',
    mediaScope: '11 Feature Films & 6 Flagship Canon Series',
    orderAttribution: 'Verified Official Order',
    sourceNote:
      'Verified against Lucasfilm official galactic chronology (BBY/ABY timeline) and theatrical release history.',
    disputedOrderNote:
      'Star Wars has a classic viewing-order debate: Release Order (Episodes IV–VI first) preserves the iconic Empire Strikes Back twist, whereas Chronological Order (Episodes I–IX) tells Anakin Skywalker’s rise and fall sequentially. Recommended Order starts with the Original Trilogy before exploring the Prequels, Anthologies, and Disney+ era.',
    orderNotes: {
      recommended: 'Original Trilogy (IV–VI) first to preserve classic twists, followed by Prequels (I–III), Anthologies, and Sequels.',
      release: 'Exact theatrical & television premiere order starting with 1977’s Star Wars.',
      chronological: 'Galactic Standard Timeline from 32 BBY (The Phantom Menace) to 35 ABY (The Rise of Skywalker).',
      complete: 'All 11 canon theatrical films interleaved with key animated and live-action series.',
    },
    searchAliases: [
      'star wars',
      'skywalker',
      'luke skywalker',
      'darth vader',
      'jedi',
      'sith',
      'mandalorian',
      'grogu',
      'baby yoda',
      'andor',
      'obi-wan',
      'ahsoka',
      'clone wars',
      'rogue one',
      'solo',
    ],
    entries: {
      tmdb_movie_1893: {
        source: 'tmdb', mediaType: 'movie', externalId: '1893',
        title: 'Star Wars: Episode I - The Phantom Menace', releaseYear: 1999, entryType: 'Prequel',
        relationships: ['Core Entry', 'Prequel'],
        description: 'Jedi Knights Qui-Gon Jinn and Obi-Wan Kenobi discover young Anakin Skywalker on Tatooine.',
        defaultNote: '32 BBY — Beginning of the Prequel Trilogy.',
      },
      tmdb_movie_1894: {
        source: 'tmdb', mediaType: 'movie', externalId: '1894',
        title: 'Star Wars: Episode II - Attack of the Clones', releaseYear: 2002, entryType: 'Prequel',
        relationships: ['Core Entry', 'Prequel', 'Sequel'],
        description: 'The Galactic Republic descends into the Clone Wars as Anakin falls for Padmé Amidala.',
        defaultNote: '22 BBY.',
      },
      tmdb_tv_4194: {
        source: 'tmdb', mediaType: 'tv', externalId: '4194',
        title: 'Star Wars: The Clone Wars', releaseYear: 2008, entryType: 'Series',
        relationships: ['Spin-off', 'Shared Universe'],
        description: 'Anakin Skywalker, Obi-Wan Kenobi, and Ahsoka Tano lead clone troopers across the galaxy.',
        defaultNote: '22–19 BBY — Bridges Episodes II and III (7 seasons).',
        totalSeasons: 7, totalEpisodes: 133,
      },
      tmdb_movie_1895: {
        source: 'tmdb', mediaType: 'movie', externalId: '1895',
        title: 'Star Wars: Episode III - Revenge of the Sith', releaseYear: 2005, entryType: 'Prequel',
        relationships: ['Core Entry', 'Prequel', 'Sequel'],
        description: 'Palpatine executes Order 66 as Anakin Skywalker falls to the dark side and becomes Darth Vader.',
        defaultNote: '19 BBY — Fall of the Republic.',
      },
      tmdb_movie_348350: {
        source: 'tmdb', mediaType: 'movie', externalId: '348350',
        title: 'Solo: A Star Wars Story', releaseYear: 2018, entryType: 'Spin-off',
        relationships: ['Prequel', 'Spin-off', 'Shared Universe'],
        description: 'Young Han Solo meets Chewbacca, Lando Calrissian, and the Millennium Falcon.',
        defaultNote: '13–10 BBY — Standalone origin film.',
      },
      tmdb_tv_92830: {
        source: 'tmdb', mediaType: 'tv', externalId: '92830',
        title: 'Obi-Wan Kenobi', releaseYear: 2022, entryType: 'Series',
        relationships: ['Spin-off', 'Shared Universe'],
        description: 'Ten years after Revenge of the Sith, exiled Obi-Wan rescues young Leia Organa.',
        defaultNote: '9 BBY — Limited series.',
        totalSeasons: 1, totalEpisodes: 6,
      },
      tmdb_tv_60554: {
        source: 'tmdb', mediaType: 'tv', externalId: '60554',
        title: 'Star Wars Rebels', releaseYear: 2014, entryType: 'Series',
        relationships: ['Spin-off', 'Shared Universe'],
        description: 'The Ghost crew sparks the earliest cells of the Rebel Alliance against Grand Admiral Thrawn.',
        defaultNote: '5–1 BBY — Directly sets up Ahsoka (4 seasons).',
        totalSeasons: 4, totalEpisodes: 75,
      },
      tmdb_tv_83867: {
        source: 'tmdb', mediaType: 'tv', externalId: '83867',
        title: 'Andor', releaseYear: 2022, entryType: 'Series',
        relationships: ['Prequel', 'Spin-off', 'Shared Universe'],
        description: 'Cassian Andor transforms from cynical thief into a committed revolutionary against the Empire.',
        defaultNote: '5–0 BBY — Direct prequel series to Rogue One.',
        totalSeasons: 2, totalEpisodes: 24,
      },
      tmdb_movie_330459: {
        source: 'tmdb', mediaType: 'movie', externalId: '330459',
        title: 'Rogue One: A Star Wars Story', releaseYear: 2016, entryType: 'Prequel',
        relationships: ['Prequel', 'Spin-off', 'Shared Universe'],
        description: 'Jyn Erso and Cassian Andor lead a desperate raid to steal the Death Star plans.',
        defaultNote: '0 BBY — Ends minutes before Episode IV begins.',
      },
      tmdb_movie_11: {
        source: 'tmdb', mediaType: 'movie', externalId: '11',
        title: 'Star Wars (Episode IV: A New Hope)', releaseYear: 1977, entryType: 'Movie',
        relationships: ['Core Entry'],
        description: 'Farm boy Luke Skywalker joins Obi-Wan, Han Solo, and Princess Leia to destroy the Death Star.',
        defaultNote: '0 BBY — The 1977 original that began the saga.',
      },
      tmdb_movie_1891: {
        source: 'tmdb', mediaType: 'movie', externalId: '1891',
        title: 'The Empire Strikes Back', releaseYear: 1980, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Luke trains with Yoda on Dagobah while Darth Vader pursues the Rebels to Cloud City.',
        defaultNote: '3 ABY — Episode V.',
      },
      tmdb_movie_1892: {
        source: 'tmdb', mediaType: 'movie', externalId: '1892',
        title: 'Return of the Jedi', releaseYear: 1983, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'The Rebel Alliance assaults the second Death Star as Luke confronts Darth Vader and the Emperor.',
        defaultNote: '4 ABY — Episode VI.',
      },
      tmdb_tv_82856: {
        source: 'tmdb', mediaType: 'tv', externalId: '82856',
        title: 'The Mandalorian', releaseYear: 2019, entryType: 'Series',
        relationships: ['Spin-off', 'Shared Universe'],
        description: 'Lone bounty hunter Din Djarin protects Force-sensitive foundling Grogu in the Outer Rim.',
        defaultNote: '9 ABY — Post-Return of the Jedi New Republic era.',
        totalSeasons: 3, totalEpisodes: 24,
      },
      tmdb_tv_114461: {
        source: 'tmdb', mediaType: 'tv', externalId: '114461',
        title: 'Ahsoka', releaseYear: 2023, entryType: 'Series',
        relationships: ['Spin-off', 'Sequel', 'Shared Universe'],
        description: 'Former Jedi Ahsoka Tano investigates an emerging threat from Grand Admiral Thrawn.',
        defaultNote: '9 ABY — Live-action continuation of Star Wars Rebels.',
        totalSeasons: 1, totalEpisodes: 8,
      },
      tmdb_movie_140607: {
        source: 'tmdb', mediaType: 'movie', externalId: '140607',
        title: 'Star Wars: The Force Awakens', releaseYear: 2015, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Scavenger Rey and defecting stormtrooper Finn cross paths with Han Solo against the First Order.',
        defaultNote: '34 ABY — Episode VII.',
      },
      tmdb_movie_181808: {
        source: 'tmdb', mediaType: 'movie', externalId: '181808',
        title: 'Star Wars: The Last Jedi', releaseYear: 2017, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Rey seeks training from exiled Luke Skywalker while the Resistance flees the First Order.',
        defaultNote: '34 ABY — Episode VIII.',
      },
      tmdb_movie_181812: {
        source: 'tmdb', mediaType: 'movie', externalId: '181812',
        title: 'Star Wars: The Rise of Skywalker', releaseYear: 2019, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'The Resistance faces a final showdown against a resurrected Emperor Palpatine.',
        defaultNote: '35 ABY — Episode IX, Skywalker Saga finale.',
      },
    },
    orders: {
      recommended: [
        ['tmdb_movie_11', 'Start with the original classic (Episode IV)'],
        'tmdb_movie_1891', 'tmdb_movie_1892',
        ['tmdb_movie_1893', 'Flash back to Anakin Skywalker’s origin (Episode I)'],
        'tmdb_movie_1894', 'tmdb_movie_1895',
        ['tmdb_movie_330459', 'Revisit the Death Star heist with full saga context'],
        'tmdb_movie_140607', 'tmdb_movie_181808', 'tmdb_movie_181812',
        'tmdb_tv_82856', 'tmdb_tv_83867',
      ],
      release: [
        'tmdb_movie_11', 'tmdb_movie_1891', 'tmdb_movie_1892',
        'tmdb_movie_1893', 'tmdb_movie_1894', 'tmdb_movie_1895',
        'tmdb_tv_4194', 'tmdb_tv_60554', 'tmdb_movie_140607', 'tmdb_movie_330459',
        'tmdb_movie_181808', 'tmdb_movie_348350', 'tmdb_tv_82856', 'tmdb_movie_181812',
        'tmdb_tv_92830', 'tmdb_tv_83867', 'tmdb_tv_114461',
      ],
      chronological: [
        'tmdb_movie_1893', 'tmdb_movie_1894', 'tmdb_tv_4194', 'tmdb_movie_1895',
        'tmdb_movie_348350', 'tmdb_tv_92830', 'tmdb_tv_60554', 'tmdb_tv_83867',
        'tmdb_movie_330459', 'tmdb_movie_11', 'tmdb_movie_1891', 'tmdb_movie_1892',
        'tmdb_tv_82856', 'tmdb_tv_114461', 'tmdb_movie_140607', 'tmdb_movie_181808', 'tmdb_movie_181812',
      ],
      complete: [
        'tmdb_movie_1893', 'tmdb_movie_1894', 'tmdb_tv_4194', 'tmdb_movie_1895',
        'tmdb_movie_348350', 'tmdb_tv_92830', 'tmdb_tv_60554', 'tmdb_tv_83867',
        'tmdb_movie_330459', 'tmdb_movie_11', 'tmdb_movie_1891', 'tmdb_movie_1892',
        'tmdb_tv_82856', 'tmdb_tv_114461', 'tmdb_movie_140607', 'tmdb_movie_181808', 'tmdb_movie_181812',
      ],
    },
  }),

  // =========================================================================
  // 6. MIDDLE-EARTH: THE LORD OF THE RINGS & THE HOBBIT
  // =========================================================================
  defineFranchise({
    id: 'middle-earth',
    name: 'Middle-earth: The Lord of the Rings & The Hobbit',
    description:
      'J. R. R. Tolkien’s legendary fantasy world on screen—spanning Peter Jackson’s Academy Award-winning Lord of the Rings trilogy, The Hobbit prequel trilogy, and the Second Age series The Rings of Power.',
    originCountry: 'New Zealand',
    mediaScope: '6 Feature Films & Second Age Television Series',
    orderAttribution: 'Verified Official Order',
    sourceNote:
      'Verified against New Line Cinema theatrical continuity (Third Age) and Tolkien’s Second Age timeline.',
    disputedOrderNote:
      'Peter Jackson’s The Hobbit trilogy was filmed after The Lord of the Rings and includes visual callbacks assuming familiarity with the Ring and Sauron; Recommended Order therefore places The Lord of the Rings first. Note also that Amazon’s The Rings of Power is a separate studio adaptation set thousands of years earlier in the Second Age.',
    searchAliases: [
      'lord of the rings',
      'lotr',
      'the hobbit',
      'hobbit',
      'middle earth',
      'middle-earth',
      'frodo',
      'gandalf',
      'aragorn',
      'bilbo baggins',
      'sauron',
      'rings of power',
      'tolkien',
    ],
    entries: {
      tmdb_tv_84773: {
        source: 'tmdb', mediaType: 'tv', externalId: '84773',
        title: 'The Lord of the Rings: The Rings of Power', releaseYear: 2022, entryType: 'Series',
        relationships: ['Prequel', 'Alternate Timeline', 'Shared Universe'],
        description: 'Set thousands of years before The Hobbit, charting the forging of the Rings of Power in the Second Age.',
        defaultNote: 'Second Age prequel series (separate Amazon adaptation from Jackson’s films).',
        totalSeasons: 2, totalEpisodes: 16,
      },
      tmdb_movie_49051: {
        source: 'tmdb', mediaType: 'movie', externalId: '49051',
        title: 'The Hobbit: An Unexpected Journey', releaseYear: 2012, entryType: 'Prequel',
        relationships: ['Prequel', 'Core Entry'],
        description: 'Bilbo Baggins joins Thorin Oakenshield’s company to reclaim Erebor from Smaug.',
        defaultNote: 'Third Age 2941 — 60 years before Fellowship of the Ring.',
      },
      tmdb_movie_57158: {
        source: 'tmdb', mediaType: 'movie', externalId: '57158',
        title: 'The Hobbit: The Desolation of Smaug', releaseYear: 2013, entryType: 'Prequel',
        relationships: ['Prequel', 'Sequel', 'Core Entry'],
        description: 'The dwarves traverse Mirkwood and Lake-town to confront the dragon Smaug inside the Lonely Mountain.',
        defaultNote: 'Hobbit Trilogy Part 2.',
      },
      tmdb_movie_122917: {
        source: 'tmdb', mediaType: 'movie', externalId: '122917',
        title: 'The Hobbit: The Battle of the Five Armies', releaseYear: 2014, entryType: 'Prequel',
        relationships: ['Prequel', 'Sequel', 'Core Entry'],
        description: 'Armies of Elves, Men, Dwarves, and Orcs clash at the gates of Erebor.',
        defaultNote: 'Hobbit Trilogy finale — bridges directly into Bilbo’s 111th birthday.',
      },
      tmdb_movie_120: {
        source: 'tmdb', mediaType: 'movie', externalId: '120',
        title: 'The Lord of the Rings: The Fellowship of the Ring', releaseYear: 2001, entryType: 'Movie',
        relationships: ['Core Entry'],
        description: 'Frodo Baggins inherits the One Ring and sets out with eight companions to destroy it in Mordor.',
        defaultNote: 'Third Age 3018 — Original Trilogy Part 1.',
      },
      tmdb_movie_121: {
        source: 'tmdb', mediaType: 'movie', externalId: '121',
        title: 'The Lord of the Rings: The Two Towers', releaseYear: 2002, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'The Fellowship splits across Rohan, Fangorn, and Mordor’s borders as Saruman marches on Helm’s Deep.',
        defaultNote: 'Original Trilogy Part 2.',
      },
      tmdb_movie_122: {
        source: 'tmdb', mediaType: 'movie', externalId: '122',
        title: 'The Lord of the Rings: The Return of the King', releaseYear: 2003, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Gondor stands against Sauron’s armies while Frodo and Sam climb Mount Doom.',
        defaultNote: 'Original Trilogy finale.',
      },
    },
    orders: {
      recommended: [
        'tmdb_movie_120', 'tmdb_movie_121', 'tmdb_movie_122',
        ['tmdb_movie_49051', 'Watch The Hobbit trilogy next to enjoy Jackson’s callbacks'],
        'tmdb_movie_57158', 'tmdb_movie_122917',
        ['tmdb_tv_84773', 'Optional Second Age prequel series'],
      ],
      release: [
        'tmdb_movie_120', 'tmdb_movie_121', 'tmdb_movie_122',
        'tmdb_movie_49051', 'tmdb_movie_57158', 'tmdb_movie_122917',
        'tmdb_tv_84773',
      ],
      chronological: [
        ['tmdb_tv_84773', 'Second Age (separate studio adaptation)'],
        ['tmdb_movie_49051', 'Third Age 2941'],
        'tmdb_movie_57158', 'tmdb_movie_122917',
        ['tmdb_movie_120', 'Third Age 3018'],
        'tmdb_movie_121', 'tmdb_movie_122',
      ],
      complete: [
        'tmdb_tv_84773', 'tmdb_movie_49051', 'tmdb_movie_57158', 'tmdb_movie_122917',
        'tmdb_movie_120', 'tmdb_movie_121', 'tmdb_movie_122',
      ],
    },
  }),

  // =========================================================================
  // 7. JURASSIC PARK & JURASSIC WORLD
  // =========================================================================
  defineFranchise({
    id: 'jurassic-park',
    name: 'Jurassic Park & Jurassic World',
    description:
      'From John Hammond’s original Isla Nublar theme park to dinosaurs roaming modern Earth—six theatrical adventures plus the canon animated survival series Camp Cretaceous.',
    originCountry: 'United States',
    mediaScope: '6 Feature Films & Canon Animated Series',
    orderAttribution: 'Verified Official Order',
    sourceNote: 'Verified against Universal Pictures official Jurassic timeline.',
    searchAliases: ['jurassic park', 'jurassic world', 'dinosaurs', 'isla nublar', 'alan grant', 'owen grady', 'camp cretaceous'],
    entries: {
      tmdb_movie_329: {
        source: 'tmdb', mediaType: 'movie', externalId: '329',
        title: 'Jurassic Park', releaseYear: 1993, entryType: 'Movie',
        relationships: ['Core Entry'],
        description: 'Paleontologists tour a revolutionary island park where cloned dinosaurs break free during a tropical storm.',
        defaultNote: 'Original 1993 classic — Isla Nublar incident.',
      },
      tmdb_movie_330: {
        source: 'tmdb', mediaType: 'movie', externalId: '330',
        title: 'The Lost World: Jurassic Park', releaseYear: 1997, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Ian Malcolm travels to Site B (Isla Sorna) where dinosaurs thrive unchecked.',
        defaultNote: 'Set 4 years after Jurassic Park.',
      },
      tmdb_movie_331: {
        source: 'tmdb', mediaType: 'movie', externalId: '331',
        title: 'Jurassic Park III', releaseYear: 2001, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Alan Grant is tricked into returning to Isla Sorna for a rescue mission.',
        defaultNote: 'Final chapter of the original trilogy.',
      },
      tmdb_movie_135397: {
        source: 'tmdb', mediaType: 'movie', externalId: '135397',
        title: 'Jurassic World', releaseYear: 2015, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'A thriving luxury park on Isla Nublar descends into chaos when the hybrid Indominus rex escapes.',
        defaultNote: 'Set 22 years after the original Jurassic Park.',
      },
      tmdb_tv_93741: {
        source: 'tmdb', mediaType: 'tv', externalId: '93741',
        title: 'Jurassic World: Camp Cretaceous', releaseYear: 2020, entryType: 'Series',
        relationships: ['Spin-off', 'Shared Universe'],
        description: 'Six teenagers stranded on Isla Nublar during the fall of Jurassic World fight to survive.',
        defaultNote: 'Canon series taking place concurrently with Jurassic World and leading into Fallen Kingdom.',
        totalSeasons: 5, totalEpisodes: 49,
      },
      tmdb_movie_351286: {
        source: 'tmdb', mediaType: 'movie', externalId: '351286',
        title: 'Jurassic World: Fallen Kingdom', releaseYear: 2018, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Owen and Claire mount a rescue as Isla Nublar’s volcano erupts, unleashing dinosaurs onto the mainland.',
        defaultNote: 'Set 3 years after Jurassic World.',
      },
      tmdb_movie_507086: {
        source: 'tmdb', mediaType: 'movie', externalId: '507086',
        title: 'Jurassic World Dominion', releaseYear: 2022, entryType: 'Crossover',
        relationships: ['Core Entry', 'Sequel', 'Crossover'],
        description: 'Original Jurassic Park icons reunite with Owen and Claire in a world cohabited by dinosaurs.',
        defaultNote: 'Culminates both trilogies.',
      },
    },
    orders: {
      recommended: ['tmdb_movie_329', 'tmdb_movie_330', 'tmdb_movie_331', 'tmdb_movie_135397', 'tmdb_movie_351286', 'tmdb_movie_507086'],
      release: ['tmdb_movie_329', 'tmdb_movie_330', 'tmdb_movie_331', 'tmdb_movie_135397', 'tmdb_movie_351286', 'tmdb_tv_93741', 'tmdb_movie_507086'],
      chronological: ['tmdb_movie_329', 'tmdb_movie_330', 'tmdb_movie_331', 'tmdb_movie_135397', ['tmdb_tv_93741', 'Concurrent with Jurassic World through Fallen Kingdom'], 'tmdb_movie_351286', 'tmdb_movie_507086'],
      complete: ['tmdb_movie_329', 'tmdb_movie_330', 'tmdb_movie_331', 'tmdb_movie_135397', 'tmdb_tv_93741', 'tmdb_movie_351286', 'tmdb_movie_507086'],
    },
  }),

  // =========================================================================
  // 8. FAST & FURIOUS
  // =========================================================================
  defineFranchise({
    id: 'fast-and-furious',
    name: 'Fast & Furious Saga',
    description:
      'Dominic Toretto’s street-racing crew evolves into a global heist family across ten core theatrical films plus the Hobbs & Shaw spin-off—famous for its non-linear Tokyo Drift timeline.',
    originCountry: 'United States',
    mediaScope: '11 Theatrical Films (Core Saga + Spin-off)',
    orderAttribution: 'Verified Official Order',
    sourceNote: 'Verified against Universal Pictures’ official Fast Saga chronology.',
    disputedOrderNote:
      'The Fast and the Furious: Tokyo Drift was released 3rd (2006) but takes place chronologically between Fast & Furious 6 (2013) and Furious 7 (2015) so Han Lue’s story arc across films 4–6 makes sense. Both Chronological and Recommended tabs place Tokyo Drift after Fast & Furious 6.',
    searchAliases: ['fast and furious', 'fast & furious', 'dominic toretto', 'brian oconner', 'tokyo drift', 'hobbs and shaw', 'fast x', 'fast five'],
    entries: {
      tmdb_movie_9799: {
        source: 'tmdb', mediaType: 'movie', externalId: '9799',
        title: 'The Fast and the Furious', releaseYear: 2001, entryType: 'Movie',
        relationships: ['Core Entry'],
        description: 'Undercover LAPD officer Brian O’Conner infiltrates Dominic Toretto’s Los Angeles street-racing crew.',
        defaultNote: 'Origin of the Fast family.',
      },
      tmdb_movie_584: {
        source: 'tmdb', mediaType: 'movie', externalId: '584',
        title: '2 Fast 2 Furious', releaseYear: 2003, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Brian teams up with Roman Pearce and Tej Parker in Miami to take down drug lord Carter Verone.',
        defaultNote: 'Introduces Roman and Tej.',
      },
      tmdb_movie_9615: {
        source: 'tmdb', mediaType: 'movie', externalId: '9615',
        title: 'The Fast and the Furious: Tokyo Drift', releaseYear: 2006, entryType: 'Spin-off',
        relationships: ['Core Entry', 'Spin-off'],
        description: 'High school street racer Sean Boswell moves to Tokyo and learns drift racing under Han Lue.',
        defaultNote: 'Released 3rd (2006), but canonically set between Fast & Furious 6 and Furious 7.',
      },
      tmdb_movie_13804: {
        source: 'tmdb', mediaType: 'movie', externalId: '13804',
        title: 'Fast & Furious', releaseYear: 2009, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Dom and Brian reunite in Los Angeles and Mexico to hunt a cartel leader.',
        defaultNote: 'Direct chronological follow-up to 2 Fast 2 Furious.',
      },
      tmdb_movie_51497: {
        source: 'tmdb', mediaType: 'movie', externalId: '51497',
        title: 'Fast Five', releaseYear: 2011, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'The full crew gathers in Rio de Janeiro for a vault heist while pursued by DSS agent Luke Hobbs.',
        defaultNote: 'Introduces Luke Hobbs and unifies the entire ensemble.',
      },
      tmdb_movie_82992: {
        source: 'tmdb', mediaType: 'movie', externalId: '82992',
        title: 'Fast & Furious 6', releaseYear: 2013, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Hobbs recruits Dom’s crew in London to stop mercenary Owen Shaw and uncover Letty’s survival.',
        defaultNote: 'Post-credits directly connects into Tokyo Drift.',
      },
      tmdb_movie_168259: {
        source: 'tmdb', mediaType: 'movie', externalId: '168259',
        title: 'Furious 7', releaseYear: 2015, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Deckard Shaw hunts Dom’s family for vengeance after Owen’s defeat.',
        defaultNote: 'Follows directly after Tokyo Drift.',
      },
      tmdb_movie_337339: {
        source: 'tmdb', mediaType: 'movie', externalId: '337339',
        title: 'The Fate of the Furious', releaseYear: 2017, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Cyberterrorist Cipher coerces Dom into betraying his team.',
        defaultNote: '8th core installment.',
      },
      tmdb_movie_384018: {
        source: 'tmdb', mediaType: 'movie', externalId: '384018',
        title: 'Fast & Furious Presents: Hobbs & Shaw', releaseYear: 2019, entryType: 'Spin-off',
        relationships: ['Spin-off', 'Shared Universe'],
        description: 'Rivals Luke Hobbs and Deckard Shaw reluctantly partner to stop cyber-enhanced villain Brixton.',
        defaultNote: 'Standalone buddy-action spin-off set between Fate and F9.',
      },
      tmdb_movie_385128: {
        source: 'tmdb', mediaType: 'movie', externalId: '385128',
        title: 'F9', releaseYear: 2021, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Dom confronts his estranged brother Jakob while Han’s survival is revealed.',
        defaultNote: '9th core installment.',
      },
      tmdb_movie_385687: {
        source: 'tmdb', mediaType: 'movie', externalId: '385687',
        title: 'Fast X', releaseYear: 2023, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Dante Reyes returns to avenge the Rio vault heist from Fast Five.',
        defaultNote: '10th core installment.',
      },
    },
    orders: {
      recommended: [
        'tmdb_movie_9799', 'tmdb_movie_584', 'tmdb_movie_13804', 'tmdb_movie_51497', 'tmdb_movie_82992',
        ['tmdb_movie_9615', 'Watch Tokyo Drift right here to keep Han’s storyline seamless'],
        'tmdb_movie_168259', 'tmdb_movie_337339', 'tmdb_movie_384018', 'tmdb_movie_385128', 'tmdb_movie_385687',
      ],
      release: [
        'tmdb_movie_9799', 'tmdb_movie_584', 'tmdb_movie_9615', 'tmdb_movie_13804', 'tmdb_movie_51497',
        'tmdb_movie_82992', 'tmdb_movie_168259', 'tmdb_movie_337339', 'tmdb_movie_384018', 'tmdb_movie_385128', 'tmdb_movie_385687',
      ],
      chronological: [
        'tmdb_movie_9799', 'tmdb_movie_584', 'tmdb_movie_13804', 'tmdb_movie_51497', 'tmdb_movie_82992',
        ['tmdb_movie_9615', 'Chronologically occurs between Fast & Furious 6 and Furious 7'],
        'tmdb_movie_168259', 'tmdb_movie_337339', 'tmdb_movie_384018', 'tmdb_movie_385128', 'tmdb_movie_385687',
      ],
      complete: [
        'tmdb_movie_9799', 'tmdb_movie_584', 'tmdb_movie_13804', 'tmdb_movie_51497', 'tmdb_movie_82992',
        'tmdb_movie_9615', 'tmdb_movie_168259', 'tmdb_movie_337339', 'tmdb_movie_384018', 'tmdb_movie_385128', 'tmdb_movie_385687',
      ],
    },
  }),

  // =========================================================================
  // 9. MISSION: IMPOSSIBLE
  // =========================================================================
  defineFranchise({
    id: 'mission-impossible',
    name: 'Mission: Impossible',
    description:
      'IMF agent Ethan Hunt’s high-stakes espionage thrillers—renowned for practical stuntcraft and recurring threads from the Syndicate to the Entity.',
    originCountry: 'United States',
    mediaScope: '7 Theatrical Feature Films',
    orderAttribution: 'Verified Official Order',
    sourceNote: 'Verified against Paramount Pictures official theatrical sequence (release and chronological order are identical).',
    searchAliases: ['mission impossible', 'mission: impossible', 'ethan hunt', 'imf', 'tom cruise', 'fallout', 'dead reckoning', 'ghost protocol'],
    entries: {
      tmdb_movie_954: {
        source: 'tmdb', mediaType: 'movie', externalId: '954',
        title: 'Mission: Impossible', releaseYear: 1996, entryType: 'Movie',
        relationships: ['Core Entry'],
        description: 'Framed for the betrayal of his IMF team in Prague, Ethan Hunt clears his name by infiltrating Langley.',
        defaultNote: 'Original 1996 thriller directed by Brian De Palma.',
      },
      tmdb_movie_955: {
        source: 'tmdb', mediaType: 'movie', externalId: '955',
        title: 'Mission: Impossible II', releaseYear: 2000, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Ethan races rogue agent Sean Ambrose to recover the engineered Chimera virus in Sydney.',
        defaultNote: 'Standalone mission directed by John Woo.',
      },
      tmdb_movie_956: {
        source: 'tmdb', mediaType: 'movie', externalId: '956',
        title: 'Mission: Impossible III', releaseYear: 2006, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Ethan’s civilian life collides with ruthless arms dealer Owen Davian and the Rabbit’s Foot.',
        defaultNote: 'Introduces Benji Dunn and Julia Meade.',
      },
      tmdb_movie_56292: {
        source: 'tmdb', mediaType: 'movie', externalId: '56292',
        title: 'Mission: Impossible - Ghost Protocol', releaseYear: 2011, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Disavowed after the Kremlin bombing, Ethan’s skeleton crew prevents nuclear catastrophe from Dubai to Mumbai.',
        defaultNote: 'Reinvents the modern team formula.',
      },
      tmdb_movie_177677: {
        source: 'tmdb', mediaType: 'movie', externalId: '177677',
        title: 'Mission: Impossible - Rogue Nation', releaseYear: 2015, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Ethan and MI6 operative Ilsa Faust expose the shadowy rogue intelligence network known as the Syndicate.',
        defaultNote: 'Introduces Ilsa Faust and Solomon Lane.',
      },
      tmdb_movie_353081: {
        source: 'tmdb', mediaType: 'movie', externalId: '353081',
        title: 'Mission: Impossible - Fallout', releaseYear: 2018, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'After a Berlin mission goes sideways, Ethan tracks missing plutonium cores alongside CIA assassin August Walker.',
        defaultNote: 'Direct sequel to Rogue Nation.',
      },
      tmdb_movie_575264: {
        source: 'tmdb', mediaType: 'movie', externalId: '575264',
        title: 'Mission: Impossible - Dead Reckoning Part One', releaseYear: 2023, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Ethan races global powers to secure the two-part key controlling a rogue sentient AI called the Entity.',
        defaultNote: '7th installment — brings back Eugene Kittridge from the 1996 original.',
      },
    },
    orders: {
      recommended: ['tmdb_movie_954', 'tmdb_movie_955', 'tmdb_movie_956', 'tmdb_movie_56292', 'tmdb_movie_177677', 'tmdb_movie_353081', 'tmdb_movie_575264'],
      release: ['tmdb_movie_954', 'tmdb_movie_955', 'tmdb_movie_956', 'tmdb_movie_56292', 'tmdb_movie_177677', 'tmdb_movie_353081', 'tmdb_movie_575264'],
      chronological: ['tmdb_movie_954', 'tmdb_movie_955', 'tmdb_movie_956', 'tmdb_movie_56292', 'tmdb_movie_177677', 'tmdb_movie_353081', 'tmdb_movie_575264'],
      complete: ['tmdb_movie_954', 'tmdb_movie_955', 'tmdb_movie_956', 'tmdb_movie_56292', 'tmdb_movie_177677', 'tmdb_movie_353081', 'tmdb_movie_575264'],
    },
  }),

  // =========================================================================
  // 10. DC UNIVERSE / DCEU CONTINUITY
  // =========================================================================
  defineFranchise({
    id: 'dc-universe',
    name: 'DC Universe (DCEU Core Continuity)',
    description:
      'Warner Bros. and DC Studios’ interconnected superhero continuity spanning Superman, Batman, Wonder Woman, the Justice League, Aquaman, Shazam, Task Force X, and Peacemaker.',
    originCountry: 'United States',
    mediaScope: 'Core Continuity Films & Flagship Series',
    orderAttribution: 'Community-Curated Order',
    sourceNote:
      'Curated from verified Warner Bros. / DC Studios continuity. Standalone Elseworlds titles (such as Matt Reeves’s The Batman and Todd Phillips’s Joker) are intentionally excluded because they take place in separate universes.',
    disputedOrderNote:
      'Zack Snyder’s Justice League (2021) is recommended over the 2017 theatrical cut as the definitive 4-hour Justice League chapter. Wonder Woman (2017) is framed in modern day but primarily takes place during WWI (1918), placing it first chronologically.',
    searchAliases: [
      'dc',
      'dc universe',
      'dceu',
      'dcu',
      'justice league',
      'superman',
      'man of steel',
      'batman v superman',
      'wonder woman',
      'aquaman',
      'shazam',
      'the flash',
      'suicide squad',
      'peacemaker',
    ],
    entries: {
      tmdb_movie_49521: {
        source: 'tmdb', mediaType: 'movie', externalId: '49521',
        title: 'Man of Steel', releaseYear: 2013, entryType: 'Movie',
        relationships: ['Core Entry', 'Shared Universe'],
        description: 'Clark Kent embraces his Kryptonian heritage to defend Earth from General Zod.',
        defaultNote: 'Launches the DCEU continuity.',
      },
      tmdb_movie_209112: {
        source: 'tmdb', mediaType: 'movie', externalId: '209112',
        title: 'Batman v Superman: Dawn of Justice', releaseYear: 2016, entryType: 'Crossover',
        relationships: ['Core Entry', 'Sequel', 'Crossover', 'Shared Universe'],
        description: 'Fearing Superman’s unchecked power, Gotham’s vigilante clashes with the Man of Steel as Lex Luthor schemes.',
        defaultNote: 'Introduces Batman and Wonder Woman.',
      },
      tmdb_movie_297762: {
        source: 'tmdb', mediaType: 'movie', externalId: '297762',
        title: 'Wonder Woman', releaseYear: 2017, entryType: 'Prequel',
        relationships: ['Core Entry', 'Prequel', 'Shared Universe'],
        description: 'Amazon princess Diana leaves Themyscira in 1918 to end the Great War.',
        defaultNote: 'Chronologically set in 1918 (WWI), framed post-BvS.',
      },
      tmdb_movie_791373: {
        source: 'tmdb', mediaType: 'movie', externalId: '791373',
        title: "Zack Snyder's Justice League", releaseYear: 2021, entryType: 'Crossover',
        relationships: ['Core Entry', 'Sequel', 'Crossover', 'Shared Universe'],
        description: 'Batman and Wonder Woman recruit Aquaman, Cyborg, and The Flash to stop Steppenwolf and Darkseid.',
        defaultNote: 'Definitive director’s edition of the Justice League assembly (chronologically 2017).',
      },
      tmdb_movie_297802: {
        source: 'tmdb', mediaType: 'movie', externalId: '297802',
        title: 'Aquaman', releaseYear: 2018, entryType: 'Spin-off',
        relationships: ['Spin-off', 'Shared Universe'],
        description: 'Arthur Curry journeys to Atlantis to prevent King Orm from waging war on the surface world.',
        defaultNote: 'Follows directly after Justice League.',
      },
      tmdb_movie_287947: {
        source: 'tmdb', mediaType: 'movie', externalId: '287947',
        title: 'Shazam!', releaseYear: 2019, entryType: 'Movie',
        relationships: ['Shared Universe'],
        description: 'Foster teen Billy Batson gains the magical ability to transform into an adult superhero.',
        defaultNote: 'Standalone hero origin in the same universe.',
      },
      tmdb_movie_436969: {
        source: 'tmdb', mediaType: 'movie', externalId: '436969',
        title: 'The Suicide Squad', releaseYear: 2021, entryType: 'Spin-off',
        relationships: ['Spin-off', 'Shared Universe'],
        description: 'James Gunn’s Task Force X infiltrates Corto Maltese to destroy Project Starfish.',
        defaultNote: 'Leads directly into the Peacemaker series.',
      },
      tmdb_tv_110492: {
        source: 'tmdb', mediaType: 'tv', externalId: '110492',
        title: 'Peacemaker', releaseYear: 2022, entryType: 'Series',
        relationships: ['Spin-off', 'Sequel', 'Shared Universe'],
        description: 'Christopher Smith joins black-ops mission Project Butterfly after surviving Corto Maltese.',
        defaultNote: 'Direct series continuation of The Suicide Squad.',
        totalSeasons: 1, totalEpisodes: 8,
      },
      tmdb_movie_298618: {
        source: 'tmdb', mediaType: 'movie', externalId: '298618',
        title: 'The Flash', releaseYear: 2023, entryType: 'Crossover',
        relationships: ['Sequel', 'Crossover', 'Shared Universe'],
        description: 'Barry Allen uses the Speed Force to change the past, fracturing the DC multiverse.',
        defaultNote: 'Closes out the original DCEU continuity.',
      },
    },
    orders: {
      recommended: ['tmdb_movie_49521', 'tmdb_movie_209112', 'tmdb_movie_297762', 'tmdb_movie_791373', 'tmdb_movie_297802', 'tmdb_movie_287947', 'tmdb_movie_436969', 'tmdb_tv_110492', 'tmdb_movie_298618'],
      release: ['tmdb_movie_49521', 'tmdb_movie_209112', 'tmdb_movie_297762', 'tmdb_movie_297802', 'tmdb_movie_287947', 'tmdb_movie_791373', 'tmdb_movie_436969', 'tmdb_tv_110492', 'tmdb_movie_298618'],
      chronological: [['tmdb_movie_297762', 'Main story set in 1918 (WWI)'], 'tmdb_movie_49521', 'tmdb_movie_209112', 'tmdb_movie_791373', 'tmdb_movie_297802', 'tmdb_movie_287947', 'tmdb_movie_436969', 'tmdb_tv_110492', 'tmdb_movie_298618'],
      complete: ['tmdb_movie_49521', 'tmdb_movie_209112', 'tmdb_movie_297762', 'tmdb_movie_791373', 'tmdb_movie_297802', 'tmdb_movie_287947', 'tmdb_movie_436969', 'tmdb_tv_110492', 'tmdb_movie_298618'],
    },
  }),

  // =========================================================================
  // 11. JOHN WICK
  // =========================================================================
  defineFranchise({
    id: 'john-wick',
    name: 'The World of John Wick',
    description:
      'Neo-noir action saga following legendary retired assassin John Wick’s war against the High Table, plus the 1970s prequel event series The Continental.',
    originCountry: 'United States',
    mediaScope: '4 Theatrical Films & Prequel Limited Series',
    orderAttribution: 'Verified Official Order',
    sourceNote: 'Verified against Lionsgate official continuity. Chapters 1–3 take place within roughly two weeks in-universe.',
    disputedOrderNote:
      'The Continental (2023) is set in 1970s New York decades before John Wick (2014), so Chronological Order lists it first. First-time viewers should watch the four films before The Continental to appreciate the Continental hotel rules and Winston Scott’s legacy.',
    searchAliases: ['john wick', 'baba yaga', 'keanu reeves', 'the continental', 'high table', 'parabellum'],
    entries: {
      tmdb_tv_72710: {
        source: 'tmdb', mediaType: 'tv', externalId: '72710',
        title: 'The Continental: From the World of John Wick', releaseYear: 2023, entryType: 'Series',
        relationships: ['Prequel', 'Spin-off', 'Shared Universe'],
        description: 'Young Winston Scott fights to seize control of the New York Continental Hotel in 1970s Manhattan.',
        defaultNote: '1970s prequel limited series (3 feature-length episodes).',
        totalSeasons: 1, totalEpisodes: 3,
      },
      tmdb_movie_245891: {
        source: 'tmdb', mediaType: 'movie', externalId: '245891',
        title: 'John Wick', releaseYear: 2014, entryType: 'Movie',
        relationships: ['Core Entry'],
        description: 'After mobsters steal his car and kill his puppy, legendary hitman John Wick comes out of retirement.',
        defaultNote: 'Chapter 1 — introduces the Continental and assassin underworld.',
      },
      tmdb_movie_324552: {
        source: 'tmdb', mediaType: 'movie', externalId: '324552',
        title: 'John Wick: Chapter 2', releaseYear: 2017, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Bound by a blood oath marker, John is drawn to Rome and runs afoul of the High Table.',
        defaultNote: 'Begins four days after Chapter 1.',
      },
      tmdb_movie_458156: {
        source: 'tmdb', mediaType: 'movie', externalId: '458156',
        title: 'John Wick: Chapter 3 - Parabellum', releaseYear: 2019, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Declared excommunicado with a $14 million bounty on his head, John fights to survive out of New York.',
        defaultNote: 'Begins immediately after Chapter 2.',
      },
      tmdb_movie_603692: {
        source: 'tmdb', mediaType: 'movie', externalId: '603692',
        title: 'John Wick: Chapter 4', releaseYear: 2023, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'John uncovers a path to win his freedom through single combat against the Marquis de Gramont in Paris.',
        defaultNote: 'Culmination of the four-chapter saga.',
      },
    },
    orders: {
      recommended: ['tmdb_movie_245891', 'tmdb_movie_324552', 'tmdb_movie_458156', 'tmdb_movie_603692', ['tmdb_tv_72710', 'Watch after Chapter 4 for Winston’s 1970s origin']],
      release: ['tmdb_movie_245891', 'tmdb_movie_324552', 'tmdb_movie_458156', 'tmdb_movie_603692', 'tmdb_tv_72710'],
      chronological: [['tmdb_tv_72710', 'Set in the 1970s'], 'tmdb_movie_245891', 'tmdb_movie_324552', 'tmdb_movie_458156', 'tmdb_movie_603692'],
      complete: ['tmdb_tv_72710', 'tmdb_movie_245891', 'tmdb_movie_324552', 'tmdb_movie_458156', 'tmdb_movie_603692'],
    },
  }),

  // =========================================================================
  // 12. THE CONJURING UNIVERSE
  // =========================================================================
  defineFranchise({
    id: 'conjuring-universe',
    name: 'The Conjuring Universe',
    description:
      'James Wan and New Line Cinema’s supernatural horror universe centered on paranormal investigators Ed and Lorraine Warren, the cursed Annabelle doll, and the demon Valak.',
    originCountry: 'United States',
    mediaScope: '8 Interconnected Horror Feature Films',
    orderAttribution: 'Verified Official Order',
    sourceNote:
      'Verified against New Line Cinema official case-file dates (1952–1981). The Curse of La Llorona is omitted as director Michael Chaves confirmed it is not officially part of the core Conjuring Universe.',
    disputedOrderNote:
      'The Conjuring Universe jumps widely across decades: The Nun (2018) is set in 1952 and Annabelle: Creation (2017) in 1955, while The Conjuring (2013) is set in 1971. Release Order preserves the initial reveal of Valak in The Conjuring 2, while Chronological Order traces the curses from 1952 to 1981.',
    searchAliases: ['conjuring', 'the conjuring', 'conjuring universe', 'annabelle', 'the nun', 'valak', 'ed and lorraine warren', 'warrens'],
    entries: {
      tmdb_movie_439079: {
        source: 'tmdb', mediaType: 'movie', externalId: '439079',
        title: 'The Nun', releaseYear: 2018, entryType: 'Prequel',
        relationships: ['Prequel', 'Spin-off', 'Shared Universe'],
        description: 'A priest and novitiate investigate an unholy abbey in 1952 Romania haunted by Valak.',
        defaultNote: 'Set in 1952 — Earliest chronological chapter.',
      },
      tmdb_movie_396422: {
        source: 'tmdb', mediaType: 'movie', externalId: '396422',
        title: 'Annabelle: Creation', releaseYear: 2017, entryType: 'Prequel',
        relationships: ['Prequel', 'Spin-off', 'Shared Universe'],
        description: 'Orphaned girls move into a dollmaker’s farmhouse where a demonic spirit binds itself to Annabelle.',
        defaultNote: 'Set in 1955 — Origin of the Annabelle doll.',
      },
      tmdb_movie_968051: {
        source: 'tmdb', mediaType: 'movie', externalId: '968051',
        title: 'The Nun II', releaseYear: 2023, entryType: 'Prequel',
        relationships: ['Prequel', 'Sequel', 'Spin-off', 'Shared Universe'],
        description: 'Sister Irene confronts Valak once again in 1956 France.',
        defaultNote: 'Set in 1956 — Direct sequel to The Nun.',
      },
      tmdb_movie_250546: {
        source: 'tmdb', mediaType: 'movie', externalId: '250546',
        title: 'Annabelle', releaseYear: 2014, entryType: 'Prequel',
        relationships: ['Prequel', 'Spin-off', 'Shared Universe'],
        description: 'A vintage porcelain doll brings relentless supernatural terror to a young couple in 1967 California.',
        defaultNote: 'Set in 1967 — Leads into The Conjuring’s opening sequence.',
      },
      tmdb_movie_138843: {
        source: 'tmdb', mediaType: 'movie', externalId: '138843',
        title: 'The Conjuring', releaseYear: 2013, entryType: 'Movie',
        relationships: ['Core Entry', 'Shared Universe'],
        description: 'Ed and Lorraine Warren assist the Perron family in a haunted 1971 Rhode Island farmhouse.',
        defaultNote: 'Set in 1971 — Original flagship film.',
      },
      tmdb_movie_521029: {
        source: 'tmdb', mediaType: 'movie', externalId: '521029',
        title: 'Annabelle Comes Home', releaseYear: 2019, entryType: 'Spin-off',
        relationships: ['Sequel', 'Spin-off', 'Shared Universe'],
        description: 'Locked inside the Warrens’ artifact room, Annabelle awakens every spirit in the house during one night.',
        defaultNote: 'Set in 1972 — Features the Warrens’ daughter Judy.',
      },
      tmdb_movie_259693: {
        source: 'tmdb', mediaType: 'movie', externalId: '259693',
        title: 'The Conjuring 2', releaseYear: 2016, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Shared Universe'],
        description: 'The Warrens travel to 1977 London to investigate the Enfield poltergeist and first confront Valak.',
        defaultNote: 'Set in 1977 — First appearance of the Demon Nun.',
      },
      tmdb_movie_423108: {
        source: 'tmdb', mediaType: 'movie', externalId: '423108',
        title: 'The Conjuring: The Devil Made Me Do It', releaseYear: 2021, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel', 'Shared Universe'],
        description: 'In 1981, the Warrens investigate a murder case where the suspect claims demonic possession.',
        defaultNote: 'Set in 1981.',
      },
    },
    orders: {
      recommended: ['tmdb_movie_138843', 'tmdb_movie_259693', 'tmdb_movie_396422', 'tmdb_movie_250546', 'tmdb_movie_521029', 'tmdb_movie_439079', 'tmdb_movie_968051', 'tmdb_movie_423108'],
      release: ['tmdb_movie_138843', 'tmdb_movie_250546', 'tmdb_movie_259693', 'tmdb_movie_396422', 'tmdb_movie_439079', 'tmdb_movie_521029', 'tmdb_movie_423108', 'tmdb_movie_968051'],
      chronological: [
        ['tmdb_movie_439079', '1952 — Romania'],
        ['tmdb_movie_396422', '1955 — California'],
        ['tmdb_movie_968051', '1956 — France'],
        ['tmdb_movie_250546', '1967 — Santa Monica'],
        ['tmdb_movie_138843', '1971 — Rhode Island'],
        ['tmdb_movie_521029', '1972 — Connecticut'],
        ['tmdb_movie_259693', '1977 — Enfield, London'],
        ['tmdb_movie_423108', '1981 — Brookfield'],
      ],
      complete: ['tmdb_movie_439079', 'tmdb_movie_396422', 'tmdb_movie_968051', 'tmdb_movie_250546', 'tmdb_movie_138843', 'tmdb_movie_521029', 'tmdb_movie_259693', 'tmdb_movie_423108'],
    },
  }),

  // =========================================================================
  // 13. GAME OF THRONES — WESTEROS SCREEN SAGA
  // =========================================================================
  defineFranchise({
    id: 'westeros-chronicles',
    name: 'Game of Thrones — Westeros Screen Saga',
    description:
      'HBO’s television adaptations of George R. R. Martin’s A Song of Ice and Fire, spanning the Targaryen civil war in House of the Dragon and the battle for the Iron Throne in Game of Thrones.',
    originCountry: 'United States',
    mediaScope: 'Television Series & Prequel',
    orderAttribution: 'Verified Official Order',
    sourceNote: 'Verified against HBO official timeline (House of the Dragon takes place ~172 years before Daenerys Targaryen’s birth).',
    disputedOrderNote:
      'Game of Thrones Season 3 contains brief spoken spoilers about the outcome of the Dance of the Dragons; however, Recommended Order still puts Game of Thrones first because it introduces the houses, geography, and prophecies of Westeros organically.',
    searchAliases: ['game of thrones', 'got', 'westeros', 'house of the dragon', 'targaryen', 'stark', 'iron throne', 'a song of ice and fire', 'george rr martin'],
    entries: {
      tmdb_tv_1399: {
        source: 'tmdb', mediaType: 'tv', externalId: '1399',
        title: 'Game of Thrones', releaseYear: 2011, entryType: 'Series',
        relationships: ['Core Entry'],
        description: 'Nine noble families wage war for control over the Seven Kingdoms as an ancient enemy awakens beyond the Wall.',
        defaultNote: 'Original flagship series (8 seasons, 73 episodes).',
        totalSeasons: 8, totalEpisodes: 73,
      },
      tmdb_tv_94997: {
        source: 'tmdb', mediaType: 'tv', externalId: '94997',
        title: 'House of the Dragon', releaseYear: 2022, entryType: 'Prequel',
        relationships: ['Prequel', 'Spin-off', 'Shared Universe'],
        description: 'Set nearly two centuries earlier, House Targaryen fractures into a brutal civil war of succession.',
        defaultNote: 'Set ~172 years prior to Daenerys Targaryen’s birth.',
        totalSeasons: 2, totalEpisodes: 18,
      },
    },
    orders: {
      recommended: ['tmdb_tv_1399', 'tmdb_tv_94997'],
      release: ['tmdb_tv_1399', 'tmdb_tv_94997'],
      chronological: [['tmdb_tv_94997', 'Set ~172 years before Game of Thrones'], 'tmdb_tv_1399'],
      complete: ['tmdb_tv_94997', 'tmdb_tv_1399'],
    },
  }),

  // =========================================================================
  // 14. BREAKING BAD & ALBUQUERQUE CRIME SAGA
  // =========================================================================
  defineFranchise({
    id: 'breaking-bad-universe',
    name: 'Breaking Bad & Albuquerque Crime Saga',
    description:
      'Vince Gilligan and Peter Gould’s interconnected crime universe spanning Walter White’s rise as Heisenberg, Jesse Pinkman’s escape in El Camino, and Jimmy McGill’s transformation into Saul Goodman.',
    originCountry: 'United States',
    mediaScope: '2 Flagship Television Series & Sequel Film',
    orderAttribution: 'Verified Official Order',
    sourceNote: 'Verified against AMC / Sony Pictures Television official broadcast order and narrative continuity.',
    disputedOrderNote:
      'Although Better Call Saul begins six years before Breaking Bad, its black-and-white Gene Takavic flash-forwards—and its final four episodes—take place AFTER Breaking Bad and spoil major fates. Recommended / Release Order is strongly advised for first-time viewers.',
    searchAliases: ['breaking bad', 'better call saul', 'el camino', 'walter white', 'heisenberg', 'saul goodman', 'jesse pinkman'],
    entries: {
      tmdb_tv_1396: {
        source: 'tmdb', mediaType: 'tv', externalId: '1396',
        title: 'Breaking Bad', releaseYear: 2008, entryType: 'Series',
        relationships: ['Core Entry'],
        description: 'Chemistry teacher Walter White turns to manufacturing methamphetamine after a terminal diagnosis.',
        defaultNote: 'Original flagship drama (5 seasons, 62 episodes).',
        totalSeasons: 5, totalEpisodes: 62,
      },
      tmdb_movie_559969: {
        source: 'tmdb', mediaType: 'movie', externalId: '559969',
        title: 'El Camino: A Breaking Bad Movie', releaseYear: 2019, entryType: 'Sequel',
        relationships: ['Sequel', 'Spin-off'],
        description: 'Immediately after the Breaking Bad finale, fugitive Jesse Pinkman races to forge a new life.',
        defaultNote: 'Direct feature-film epilogue for Jesse Pinkman.',
      },
      tmdb_tv_60059: {
        source: 'tmdb', mediaType: 'tv', externalId: '60059',
        title: 'Better Call Saul', releaseYear: 2015, entryType: 'Prequel',
        relationships: ['Prequel', 'Spin-off', 'Sequel'],
        description: 'Struggling lawyer Jimmy McGill evolves into criminal attorney Saul Goodman while the cartel wars ignite.',
        defaultNote: 'Prequel (2002–2008) & post-Breaking Bad epilogue (6 seasons, 63 episodes).',
        totalSeasons: 6, totalEpisodes: 63,
      },
    },
    orders: {
      recommended: ['tmdb_tv_1396', 'tmdb_movie_559969', 'tmdb_tv_60059'],
      release: ['tmdb_tv_1396', 'tmdb_tv_60059', 'tmdb_movie_559969'],
      chronological: [
        ['tmdb_tv_60059', 'Main narrative set 2002–2008 (Final episodes take place after El Camino)'],
        ['tmdb_tv_1396', 'Set 2008–2010'],
        ['tmdb_movie_559969', 'Set immediately after Breaking Bad finale (2010)'],
      ],
      complete: ['tmdb_tv_1396', 'tmdb_movie_559969', 'tmdb_tv_60059'],
    },
  }),

  // =========================================================================
  // 15. ATTACK ON TITAN (ANIME)
  // =========================================================================
  defineFranchise({
    id: 'attack-on-titan',
    name: 'Attack on Titan (Shingeki no Kyojin)',
    description:
      'Hajime Isayama’s dark fantasy saga chronicling humanity’s struggle for survival behind concentric walls and the truths buried beyond the sea.',
    originCountry: 'Japan',
    mediaScope: 'Anime Series, OVAs & Specials',
    orderAttribution: 'Verified Official Order',
    sourceNote: 'Verified against official Wit Studio / MAPPA broadcast chronology and MyAnimeList relation records.',
    searchAliases: ['attack on titan', 'shingeki no kyojin', 'aot', 'eren yeager', 'levi ackerman', 'mikasa'],
    entries: {
      jikan_anime_16498: {
        source: 'jikan', mediaType: 'anime', externalId: '16498',
        title: 'Attack on Titan', releaseYear: 2013, entryType: 'Series',
        relationships: ['Core Entry'],
        description: 'Eren Yeager joins the Scout Regiment after Titans breach Wall Maria.',
        defaultNote: 'Season 1 (Episodes 1–25).',
        totalSeasons: 1, totalEpisodes: 25,
      },
      jikan_anime_18397: {
        source: 'jikan', mediaType: 'anime', externalId: '18397',
        title: 'Attack on Titan OVA', releaseYear: 2013, entryType: 'Special',
        relationships: ['Special', 'Spin-off'],
        description: 'Ilse’s Notebook and 104th Training Corps side stories.',
        defaultNote: 'Canon side-story OVAs.',
        totalSeasons: 1, totalEpisodes: 3,
      },
      jikan_anime_25781: {
        source: 'jikan', mediaType: 'anime', externalId: '25781',
        title: 'Attack on Titan: No Regrets', releaseYear: 2014, entryType: 'Prequel',
        relationships: ['Prequel', 'Special'],
        description: 'Levi Ackerman’s origin in the Underground before joining Erwin Smith’s Scout Regiment.',
        defaultNote: 'Two-part Levi prequel OVA.',
        totalSeasons: 1, totalEpisodes: 2,
      },
      jikan_anime_25777: {
        source: 'jikan', mediaType: 'anime', externalId: '25777',
        title: 'Attack on Titan Season 2', releaseYear: 2017, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Titans appear inside Wall Rose as shocking traitor identities emerge.',
        defaultNote: 'Season 2 (12 episodes).',
        totalSeasons: 1, totalEpisodes: 12,
      },
      jikan_anime_36106: {
        source: 'jikan', mediaType: 'anime', externalId: '36106',
        title: 'Attack on Titan: Lost Girls', releaseYear: 2017, entryType: 'Spin-off',
        relationships: ['Spin-off', 'Special'],
        description: 'Side stories exploring Annie Leonhart and Mikasa Ackerman.',
        defaultNote: 'Three-part side story OVA.',
        totalSeasons: 1, totalEpisodes: 3,
      },
      jikan_anime_35760: {
        source: 'jikan', mediaType: 'anime', externalId: '35760',
        title: 'Attack on Titan Season 3', releaseYear: 2018, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'The Scouts clash with the Royal Government and Military Police.',
        defaultNote: 'Royal Government Arc (12 episodes).',
        totalSeasons: 1, totalEpisodes: 12,
      },
      jikan_anime_38524: {
        source: 'jikan', mediaType: 'anime', externalId: '38524',
        title: 'Attack on Titan Season 3 Part 2', releaseYear: 2019, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'The battle to retake Wall Maria and unlock the secrets of Grisha’s basement.',
        defaultNote: 'Return to Shiganshina Arc (10 episodes).',
        totalSeasons: 1, totalEpisodes: 10,
      },
      jikan_anime_40028: {
        source: 'jikan', mediaType: 'anime', externalId: '40028',
        title: 'Attack on Titan: The Final Season', releaseYear: 2020, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Four years after reaching the sea, war erupts between Paradis Island and Marley.',
        defaultNote: 'Final Season Part 1 (16 episodes).',
        totalSeasons: 1, totalEpisodes: 16,
      },
      jikan_anime_48583: {
        source: 'jikan', mediaType: 'anime', externalId: '48583',
        title: 'Attack on Titan: The Final Season Part 2', releaseYear: 2022, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Battle returns to Shiganshina as the true purpose of the Founding Titan is unleashed.',
        defaultNote: 'Final Season Part 2 (12 episodes).',
        totalSeasons: 1, totalEpisodes: 12,
      },
      jikan_anime_51535: {
        source: 'jikan', mediaType: 'anime', externalId: '51535',
        title: 'Attack on Titan: The Final Season - The Final Chapters', releaseYear: 2023, entryType: 'Special',
        relationships: ['Core Entry', 'Sequel', 'Special'],
        description: 'The surviving alliance makes a final stand to stop the Rumbling.',
        defaultNote: 'Two feature-length concluding specials.',
        totalSeasons: 1, totalEpisodes: 2,
      },
    },
    orders: {
      recommended: ['jikan_anime_16498', ['jikan_anime_25781', 'Watch right after Season 1'], 'jikan_anime_25777', 'jikan_anime_35760', 'jikan_anime_38524', 'jikan_anime_40028', 'jikan_anime_48583', 'jikan_anime_51535'],
      release: ['jikan_anime_16498', 'jikan_anime_25777', 'jikan_anime_35760', 'jikan_anime_38524', 'jikan_anime_40028', 'jikan_anime_48583', 'jikan_anime_51535'],
      chronological: [['jikan_anime_25781', 'Levi’s origin prior to the fall of Wall Maria'], 'jikan_anime_16498', 'jikan_anime_25777', 'jikan_anime_35760', 'jikan_anime_38524', 'jikan_anime_40028', 'jikan_anime_48583', 'jikan_anime_51535'],
      complete: ['jikan_anime_16498', 'jikan_anime_18397', 'jikan_anime_25781', 'jikan_anime_25777', 'jikan_anime_36106', 'jikan_anime_35760', 'jikan_anime_38524', 'jikan_anime_40028', 'jikan_anime_48583', 'jikan_anime_51535'],
    },
  }),

  // =========================================================================
  // 16. DEMON SLAYER
  // =========================================================================
  defineFranchise({
    id: 'demon-slayer',
    name: 'Demon Slayer: Kimetsu no Yaiba',
    description:
      'Tanjiro Kamado joins the Demon Slayer Corps in Taisho-era Japan to avenge his family and restore his sister Nezuko’s humanity.',
    originCountry: 'Japan',
    mediaScope: 'Anime Series & Theatrical Film',
    orderAttribution: 'Verified Official Order',
    sourceNote: 'Verified against official Ufotable adaptation sequence and MyAnimeList relation records.',
    disputedOrderNote:
      'Mugen Train exists both as a 2020 theatrical film and a 2021 7-episode TV arc (which adds an original Episode 1 Rengoku prologue). Recommended Order suggests the TV arc, while Release Order starts with the theatrical film.',
    searchAliases: ['demon slayer', 'kimetsu no yaiba', 'tanjiro', 'nezuko', 'mugen train', 'hashira'],
    entries: {
      jikan_anime_38000: {
        source: 'jikan', mediaType: 'anime', externalId: '38000',
        title: 'Demon Slayer: Kimetsu no Yaiba', releaseYear: 2019, entryType: 'Series',
        relationships: ['Core Entry'],
        description: 'Tanjiro trains under Urokodaki and joins the Demon Slayer Corps.',
        defaultNote: 'Unwavering Resolve Arc (26 episodes).',
        totalSeasons: 1, totalEpisodes: 26,
      },
      jikan_anime_40456: {
        source: 'jikan', mediaType: 'movie', externalId: '40456',
        title: 'Demon Slayer: Mugen Train (Movie)', releaseYear: 2020, entryType: 'Movie',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Tanjiro’s squad joins Flame Hashira Kyojuro Rengoku aboard the haunted Mugen Train.',
        defaultNote: 'Theatrical sequel to Season 1.',
      },
      jikan_anime_49926: {
        source: 'jikan', mediaType: 'anime', externalId: '49926',
        title: 'Demon Slayer: Mugen Train Arc (TV)', releaseYear: 2021, entryType: 'Series',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Episodic broadcast edition featuring an original Episode 1 focusing on Rengoku.',
        defaultNote: '7-episode TV broadcast version of Mugen Train.',
        totalSeasons: 1, totalEpisodes: 7,
      },
      jikan_anime_47778: {
        source: 'jikan', mediaType: 'anime', externalId: '47778',
        title: 'Demon Slayer: Entertainment District Arc', releaseYear: 2021, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Sound Hashira Tengen Uzui leads Tanjiro, Zenitsu, and Inosuke undercover in Yoshiwara.',
        defaultNote: 'Season 2 Part 2 (11 episodes).',
        totalSeasons: 1, totalEpisodes: 11,
      },
      jikan_anime_51019: {
        source: 'jikan', mediaType: 'anime', externalId: '51019',
        title: 'Demon Slayer: Swordsmith Village Arc', releaseYear: 2023, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'Upper Rank demons ambush the secret village where Nichirin blades are forged.',
        defaultNote: 'Season 3 (11 episodes).',
        totalSeasons: 1, totalEpisodes: 11,
      },
      jikan_anime_55701: {
        source: 'jikan', mediaType: 'anime', externalId: '55701',
        title: 'Demon Slayer: Hashira Training Arc', releaseYear: 2024, entryType: 'Sequel',
        relationships: ['Core Entry', 'Sequel'],
        description: 'The entire Corps undergoes grueling training with the Hashira before the final battle.',
        defaultNote: 'Season 4 (8 episodes).',
        totalSeasons: 1, totalEpisodes: 8,
      },
    },
    orders: {
      recommended: ['jikan_anime_38000', ['jikan_anime_49926', 'Includes original Episode 1 Rengoku prologue'], 'jikan_anime_47778', 'jikan_anime_51019', 'jikan_anime_55701'],
      release: ['jikan_anime_38000', 'jikan_anime_40456', 'jikan_anime_47778', 'jikan_anime_51019', 'jikan_anime_55701'],
      chronological: ['jikan_anime_38000', 'jikan_anime_40456', 'jikan_anime_47778', 'jikan_anime_51019', 'jikan_anime_55701'],
      complete: ['jikan_anime_38000', 'jikan_anime_40456', 'jikan_anime_49926', 'jikan_anime_47778', 'jikan_anime_51019', 'jikan_anime_55701'],
    },
  }),

  // =========================================================================
  // 17. STEINS;GATE
  // =========================================================================
  defineFranchise({
    id: 'steins-gate',
    name: 'Steins;Gate Timeline',
    description:
      'A science-fiction thriller following Akihabara lab members who accidentally invent a method of sending messages across worldlines.',
    originCountry: 'Japan',
    mediaScope: 'Anime Series, Alternate Worldline & Film',
    orderAttribution: 'Community-Curated Order',
    sourceNote: 'Release order is officially verified by White Fox; chronological/interleaved order reflects community-curated worldline placement.',
    disputedOrderNote:
      'Chronological purists sometimes pause the original Steins;Gate after Episode 22 to insert Episode 23β and Steins;Gate 0 before Episodes 23–24. Recommended Order avoids interrupting the original series climax.',
    searchAliases: ['steins gate', 'steins;gate', 'okabe rintarou', 'kurisu', 'worldline'],
    entries: {
      jikan_anime_9253: {
        source: 'jikan', mediaType: 'anime', externalId: '9253',
        title: 'Steins;Gate', releaseYear: 2011, entryType: 'Series',
        relationships: ['Core Entry'],
        description: 'Eccentric scientist Rintarou Okabe discovers a modified microwave can send texts into the past.',
        defaultNote: 'Original 24-episode series.',
        totalSeasons: 1, totalEpisodes: 24,
      },
      jikan_anime_10863: {
        source: 'jikan', mediaType: 'anime', externalId: '10863',
        title: 'Steins;Gate: Egoistic Poriomania', releaseYear: 2012, entryType: 'Special',
        relationships: ['Special', 'Sequel'],
        description: 'OVA Episode 25 following the Future Gadget Lab on a trip to Los Angeles.',
        defaultNote: 'OVA Episode 25.',
        totalSeasons: 1, totalEpisodes: 1,
      },
      jikan_anime_11577: {
        source: 'jikan', mediaType: 'movie', externalId: '11577',
        title: 'Steins;Gate: The Movie - Load Region of Déjà Vu', releaseYear: 2013, entryType: 'Movie',
        relationships: ['Sequel'],
        description: 'One year after reaching the Steins;Gate worldline, Kurisu must save Okabe from fading out of reality.',
        defaultNote: 'Post-series theatrical epilogue.',
      },
      jikan_anime_32188: {
        source: 'jikan', mediaType: 'anime', externalId: '32188',
        title: 'Steins;Gate: Open the Missing Link - Divide By Zero', releaseYear: 2015, entryType: 'Special',
        relationships: ['Special', 'Alternate Timeline'],
        description: 'Alternate Episode 23β branching directly into the Beta worldline of Steins;Gate 0.',
        defaultNote: 'Essential bridge special before Steins;Gate 0.',
        totalSeasons: 1, totalEpisodes: 1,
      },
      jikan_anime_30484: {
        source: 'jikan', mediaType: 'anime', externalId: '30484',
        title: 'Steins;Gate 0', releaseYear: 2018, entryType: 'Spin-off',
        relationships: ['Spin-off', 'Alternate Timeline'],
        description: 'Explores the Beta worldline where a broken Okabe ultimately enables the path to Steins;Gate.',
        defaultNote: 'Beta worldline midquel (23 episodes).',
        totalSeasons: 1, totalEpisodes: 23,
      },
    },
    orders: {
      recommended: ['jikan_anime_9253', 'jikan_anime_32188', 'jikan_anime_30484', 'jikan_anime_11577'],
      release: ['jikan_anime_9253', 'jikan_anime_11577', 'jikan_anime_32188', 'jikan_anime_30484'],
      chronological: [['jikan_anime_9253', 'Episodes 1–22 establish the Beta worldline crisis'], 'jikan_anime_32188', 'jikan_anime_30484', 'jikan_anime_11577'],
      complete: ['jikan_anime_9253', 'jikan_anime_10863', 'jikan_anime_11577', 'jikan_anime_32188', 'jikan_anime_30484'],
    },
  }),

  // =========================================================================
  // 18. FULLMETAL ALCHEMIST
  // =========================================================================
  defineFranchise({
    id: 'fullmetal-alchemist',
    name: 'Fullmetal Alchemist',
    description:
      'Brothers Edward and Alphonse Elric search for the Philosopher’s Stone across two distinct animated adaptations of Hiromu Arakawa’s masterpiece.',
    originCountry: 'Japan',
    mediaScope: 'Two Distinct Adaptations & Feature Films',
    orderAttribution: 'Verified Official Order',
    sourceNote: 'Verified against Bones studio releases: Brotherhood (2009) faithfully adapts the complete manga independently of the 2003 anime.',
    disputedOrderNote:
      'Fullmetal Alchemist (2003) and Brotherhood (2009) are separate continuities rather than prequel/sequel. Recommended Order leads with Brotherhood as the complete canonical manga story.',
    searchAliases: ['fullmetal alchemist', 'fma', 'fmab', 'brotherhood', 'edward elric', 'alphonse elric'],
    entries: {
      jikan_anime_121: {
        source: 'jikan', mediaType: 'anime', externalId: '121',
        title: 'Fullmetal Alchemist (2003)', releaseYear: 2003, entryType: 'Series',
        relationships: ['Alternate Timeline'],
        description: 'Original 2003 adaptation that diverges into an anime-original second half.',
        defaultNote: '2003 continuity (51 episodes).',
        totalSeasons: 1, totalEpisodes: 51,
      },
      jikan_anime_430: {
        source: 'jikan', mediaType: 'movie', externalId: '430',
        title: 'Fullmetal Alchemist: The Conqueror of Shamballa', releaseYear: 2005, entryType: 'Movie',
        relationships: ['Sequel', 'Alternate Timeline'],
        description: 'Direct theatrical finale concluding the 2003 anime’s alternate timeline.',
        defaultNote: 'Concludes the 2003 series.',
      },
      jikan_anime_5114: {
        source: 'jikan', mediaType: 'anime', externalId: '5114',
        title: 'Fullmetal Alchemist: Brotherhood', releaseYear: 2009, entryType: 'Series',
        relationships: ['Core Entry'],
        description: 'Faithful full-manga adaptation chronicling the Elric brothers’ battle against the Homunculi.',
        defaultNote: 'Definitive complete manga adaptation (64 episodes).',
        totalSeasons: 1, totalEpisodes: 64,
      },
      jikan_anime_9135: {
        source: 'jikan', mediaType: 'movie', externalId: '9135',
        title: 'Fullmetal Alchemist: The Sacred Star of Milos', releaseYear: 2011, entryType: 'Movie',
        relationships: ['Spin-off'],
        description: 'Standalone side-story adventure set mid-journey in Brotherhood continuity.',
        defaultNote: 'Optional side-story film.',
      },
    },
    orders: {
      recommended: ['jikan_anime_5114', 'jikan_anime_121', 'jikan_anime_430'],
      release: ['jikan_anime_121', 'jikan_anime_430', 'jikan_anime_5114', 'jikan_anime_9135'],
      chronological: ['jikan_anime_5114', 'jikan_anime_9135'],
      complete: ['jikan_anime_121', 'jikan_anime_430', 'jikan_anime_5114', 'jikan_anime_9135'],
    },
  }),

  // =========================================================================
  // 19. MONEY HEIST (LA CASA DE PAPEL)
  // =========================================================================
  defineFranchise({
    id: 'money-heist-universe',
    name: 'La Casa de Papel (Money Heist) Universe',
    description:
      'Álex Pina’s Spanish heist thriller universe spanning the Royal Mint of Spain, the Bank of Spain, Berlin’s Parisian caper, and the Korean adaptation.',
    originCountry: 'Spain',
    mediaScope: 'Spanish Series, Prequel & International Adaptation',
    orderAttribution: 'Verified Official Order',
    sourceNote: 'Verified against official Vancouver Media / Netflix release records and narrative chronology.',
    searchAliases: ['money heist', 'la casa de papel', 'berlin', 'the professor', 'bella ciao'],
    entries: {
      tvmaze_tv_27436: {
        source: 'tvmaze', mediaType: 'tv', externalId: '27436',
        title: 'La Casa de Papel (Money Heist)', releaseYear: 2017, entryType: 'Series',
        relationships: ['Core Entry'],
        description: 'The Professor recruits eight specialists to rob the Royal Mint of Spain and the Bank of Spain.',
        defaultNote: 'Original Spanish flagship series (Parts 1–5).',
        totalSeasons: 5, totalEpisodes: 41,
      },
      tvmaze_tv_59217: {
        source: 'tvmaze', mediaType: 'tv', externalId: '59217',
        title: 'Berlin', releaseYear: 2023, entryType: 'Prequel',
        relationships: ['Prequel', 'Spin-off', 'Shared Universe'],
        description: 'In his golden years before the Royal Mint, Andrés de Fonollosa plans a €44 million Parisian jewel heist.',
        defaultNote: 'Spanish prequel spin-off centered on Berlin.',
        totalSeasons: 1, totalEpisodes: 8,
      },
      tvmaze_tv_52400: {
        source: 'tvmaze', mediaType: 'tv', externalId: '52400',
        title: 'Money Heist: Korea - Joint Economic Area', releaseYear: 2022, entryType: 'Spin-off',
        relationships: ['Spin-off', 'Alternate Timeline'],
        description: 'Korean reimagining set during the reunification of North and South Korea.',
        defaultNote: 'Standalone Korean adaptation.',
        totalSeasons: 1, totalEpisodes: 12,
      },
    },
    orders: {
      recommended: ['tvmaze_tv_27436', 'tvmaze_tv_59217', 'tvmaze_tv_52400'],
      release: ['tvmaze_tv_27436', 'tvmaze_tv_52400', 'tvmaze_tv_59217'],
      chronological: [['tvmaze_tv_59217', 'Set years before the Royal Mint heist'], 'tvmaze_tv_27436'],
      complete: ['tvmaze_tv_59217', 'tvmaze_tv_27436', 'tvmaze_tv_52400'],
    },
  }),
];

// ---------------------------------------------------------------------------
// Intelligent Franchise Matcher & Title-to-Franchise Resolver
// ---------------------------------------------------------------------------

function normalizeQuery(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function matchFranchisesForQuery(
  rawQuery: string,
  extraFranchises: FranchiseDetail[] = []
): FranchiseSearchMatch[] {
  const q = normalizeQuery(rawQuery);
  if (q.length < 2) return [];

  const allFranchises = mergeFranchisesById(CURATED_FRANCHISES, extraFranchises);
  const byId = new Map(allFranchises.map((f) => [f.id, f]));
  const scored: Array<{ franchise: FranchiseDetail; score: number; reason: string }> = [];

  for (const fr of allFranchises) {
    const normName = normalizeQuery(fr.name);
    let score = 0;
    let reason = '';

    // 1. Exact or prefix franchise name match
    if (normName === q) {
      score = 120;
      reason = 'Exact Franchise Guide';
    } else if (normName.includes(q) || q.includes(normName)) {
      score = 100;
      reason = 'Franchise Viewing Guide';
    }

    // 2. Verified search alias match (characters, universes, acronyms)
    if (score < 110) {
      for (const alias of fr.searchAliases || []) {
        const normAlias = normalizeQuery(alias);
        if (!normAlias) continue;
        if (normAlias === q) {
          if (score < 115) {
            score = 115;
            reason = `Verified Universe Match`;
          }
          break;
        } else if (normAlias.includes(q) && q.length >= 3) {
          if (score < 92) {
            score = 92;
            reason = `Connected Universe`;
          }
        } else if (q.includes(normAlias) && normAlias.length >= 4) {
          if (score < 88) {
            score = 88;
            reason = `Connected Universe`;
          }
        }
      }
    }

    // 3. Verified entry title match (never fuzzy title-guessing outside curated entries!)
    if (score < 85) {
      const matchedEntry = fr.orders.complete.find((entry) => {
        const normTitle = normalizeQuery(entry.title);
        return normTitle === q || (q.length >= 3 && normTitle.includes(q));
      });
      if (matchedEntry) {
        score = 82;
        reason = `Includes “${matchedEntry.title}”`;
      }
    }

    if (score > 0) {
      scored.push({ franchise: fr, score, reason });
    }
  }

  // Pull in related parent/companion franchises (e.g. Avengers -> MCU, Harry Potter -> Wizarding World)
  const existingIds = new Set(scored.map((s) => s.franchise.id));
  const companions: Array<{ franchise: FranchiseDetail; score: number; reason: string }> = [];
  for (const item of scored) {
    for (const relId of item.franchise.relatedFranchiseIds || []) {
      if (!existingIds.has(relId)) {
        const rel = byId.get(relId);
        if (rel) {
          existingIds.add(relId);
          companions.push({
            franchise: rel,
            score: Math.max(70, item.score - 12),
            reason: `Expanded Universe Guide`,
          });
        }
      }
    }
  }

  const combined = [...scored, ...companions].sort(
    (a, b) => b.score - a.score || b.franchise.orders.complete.length - a.franchise.orders.complete.length
  );

  return combined.slice(0, 6).map(({ franchise, reason }) => ({
    id: franchise.id,
    name: franchise.name,
    description: franchise.description,
    originCountry: franchise.originCountry,
    posterUrl: franchise.posterUrl || franchise.orders.recommended[0]?.posterUrl || null,
    orderAttribution: franchise.orderAttribution,
    entryCount: franchise.orders.complete.length,
    movieCount: franchise.confirmedMovieCount,
    seriesCount: franchise.confirmedSeriesCount,
    matchReason: reason,
    relatedGuides: (franchise.relatedFranchiseIds || [])
      .map((rid) => byId.get(rid))
      .filter((x): x is FranchiseDetail => Boolean(x))
      .map((x) => ({ id: x.id, name: x.name })),
  }));
}

export function getParentFranchisesForTitle(
  titleKey: string,
  extraFranchises: FranchiseDetail[] = []
): ParentFranchiseRef[] {
  const all = mergeFranchisesById(CURATED_FRANCHISES, extraFranchises);
  const refs: ParentFranchiseRef[] = [];

  for (const fr of all) {
    const inComplete = fr.orders.complete.some((e) => e.titleKey === titleKey);
    const recEntry = fr.orders.recommended.find((e) => e.titleKey === titleKey);
    if (inComplete || recEntry) {
      refs.push({
        id: fr.id,
        name: fr.name,
        originCountry: fr.originCountry,
        orderAttribution: fr.orderAttribution,
        entryCount: fr.orders.complete.length,
        positionInRecommended: recEntry?.position ?? null,
      });
    }
  }
  return refs;
}

export function mergeFranchisesById(
  base: FranchiseDetail[],
  overrides: FranchiseDetail[]
): FranchiseDetail[] {
  const map = new Map<string, FranchiseDetail>();
  for (const f of base) map.set(f.id, f);
  for (const f of overrides) map.set(f.id, f);
  return Array.from(map.values());
}

// ---------------------------------------------------------------------------
// Verified New-Release Franchise Relationship Detector
// ---------------------------------------------------------------------------

/**
 * Official TMDB Collection IDs mapped to verified CINÉVERSE franchise guides.
 * Never relies on fuzzy word overlap alone.
 */
const TMDB_COLLECTION_TO_FRANCHISE: Record<number, { franchiseId: string; label: string }> = {
  // Avengers & Marvel Cinematic Universe
  86311: { franchiseId: 'avengers-saga', label: 'The Avengers Collection' },
  131292: { franchiseId: 'marvel-cinematic-universe', label: 'Iron Man Collection' },
  131295: { franchiseId: 'marvel-cinematic-universe', label: 'Captain America Collection' },
  131296: { franchiseId: 'marvel-cinematic-universe', label: 'Thor Collection' },
  284433: { franchiseId: 'marvel-cinematic-universe', label: 'Guardians of the Galaxy Collection' },
  422834: { franchiseId: 'marvel-cinematic-universe', label: 'Ant-Man Collection' },
  531241: { franchiseId: 'marvel-cinematic-universe', label: 'Spider-Man (MCU) Collection' },
  529892: { franchiseId: 'marvel-cinematic-universe', label: 'Black Panther Collection' },
  618529: { franchiseId: 'marvel-cinematic-universe', label: 'Doctor Strange Collection' },
  623911: { franchiseId: 'marvel-cinematic-universe', label: 'Captain Marvel Collection' },
  448150: { franchiseId: 'marvel-cinematic-universe', label: 'Deadpool Collection' },
  // Harry Potter & Wizarding World
  1241: { franchiseId: 'harry-potter', label: 'Harry Potter Collection' },
  435259: { franchiseId: 'wizarding-world', label: 'Fantastic Beasts Collection' },
  // Star Wars
  10: { franchiseId: 'star-wars', label: 'Star Wars Collection' },
  // Middle-earth
  119: { franchiseId: 'middle-earth', label: 'The Lord of the Rings Collection' },
  121938: { franchiseId: 'middle-earth', label: 'The Hobbit Collection' },
  // Jurassic Park / World
  328: { franchiseId: 'jurassic-park', label: 'Jurassic Park Collection' },
  // Fast & Furious
  9485: { franchiseId: 'fast-and-furious', label: 'The Fast and the Furious Collection' },
  // Mission: Impossible
  87359: { franchiseId: 'mission-impossible', label: 'Mission: Impossible Collection' },
  // DC Universe
  209131: { franchiseId: 'dc-universe', label: 'Man of Steel / Justice League Collection' },
  468552: { franchiseId: 'dc-universe', label: 'Wonder Woman Collection' },
  573693: { franchiseId: 'dc-universe', label: 'Aquaman Collection' },
  724848: { franchiseId: 'dc-universe', label: 'Shazam! Collection' },
  531242: { franchiseId: 'dc-universe', label: 'Suicide Squad Collection' },
  // John Wick
  404609: { franchiseId: 'john-wick', label: 'John Wick Collection' },
  // The Conjuring Universe
  313086: { franchiseId: 'conjuring-universe', label: 'The Conjuring Collection' },
  402074: { franchiseId: 'conjuring-universe', label: 'Annabelle Collection' },
  968052: { franchiseId: 'conjuring-universe', label: 'The Nun Collection' },
  // Anime
  925155: { franchiseId: 'demon-slayer', label: 'Demon Slayer Collection' },
};

interface VerifiedTitleLineageRule {
  franchiseId: string;
  patterns: RegExp[];
  requireStudio?: RegExp;
  label: string;
  defaultRelationships: string[];
}

const VERIFIED_LINEAGE_RULES: VerifiedTitleLineageRule[] = [
  {
    franchiseId: 'avengers-saga',
    patterns: [/\bavengers\b/i],
    label: 'Avengers Headline Installment',
    defaultRelationships: ['Core Entry', 'Sequel', 'Crossover', 'Shared Universe'],
  },
  {
    franchiseId: 'marvel-cinematic-universe',
    patterns: [
      /\bcaptain america\b/i,
      /\bthunderbolts\b/i,
      /\bfantastic four\b/i,
      /\bdaredevil:\s*born again\b/i,
      /\bagatha all along\b/i,
      /\bironheart\b/i,
      /\bwonder man\b/i,
      /\bvision quest\b/i,
      /\bdeadpool\s*(&|and)\s*wolverine\b/i,
      /\beyes of wakanda\b/i,
      /\byour friendly neighborhood spider-man\b/i,
      /\bmarvel zombies\b/i,
      /\bspider-man:\s*brand new day\b/i,
    ],
    label: 'Marvel Studios Continuity',
    defaultRelationships: ['Shared Universe', 'Sequel'],
  },
  {
    franchiseId: 'harry-potter',
    patterns: [/\bharry potter\b/i],
    label: 'Harry Potter Adaptation / Series',
    defaultRelationships: ['Core Entry', 'Shared Universe'],
  },
  {
    franchiseId: 'wizarding-world',
    patterns: [/\bfantastic beasts\b/i, /\bwizarding world\b/i],
    label: 'Wizarding World Continuity',
    defaultRelationships: ['Prequel', 'Spin-off', 'Shared Universe'],
  },
  {
    franchiseId: 'star-wars',
    patterns: [
      /\bstar wars\b/i,
      /\bthe mandalorian\b/i,
      /\bahsoka\b/i,
      /\bandor\b/i,
      /\bskeleton crew\b/i,
      /\bthe acolyte\b/i,
      /\btales of the (jedi|empire|underworld)\b/i,
    ],
    label: 'Lucasfilm Star Wars Galaxy',
    defaultRelationships: ['Spin-off', 'Shared Universe'],
  },
  {
    franchiseId: 'middle-earth',
    patterns: [
      /\blord of the rings\b/i,
      /\bthe rings of power\b/i,
      /\bwar of the rohirrim\b/i,
      /\bhunt for gollum\b/i,
    ],
    label: 'Middle-earth Legendarium',
    defaultRelationships: ['Prequel', 'Spin-off', 'Shared Universe'],
  },
  {
    franchiseId: 'jurassic-park',
    patterns: [/\bjurassic (park|world)\b/i],
    label: 'Jurassic Franchise',
    defaultRelationships: ['Core Entry', 'Sequel'],
  },
  {
    franchiseId: 'fast-and-furious',
    patterns: [/\bfast\s*(&|and)\s*furious\b/i, /\bfast x\b/i, /\bhobbs\s*(&|and)\s*(shaw|reyes)\b/i],
    label: 'Fast Saga Continuity',
    defaultRelationships: ['Core Entry', 'Sequel'],
  },
  {
    franchiseId: 'mission-impossible',
    patterns: [/\bmission:\s*impossible\b/i],
    label: 'Mission: Impossible Franchise',
    defaultRelationships: ['Core Entry', 'Sequel'],
  },
  {
    franchiseId: 'dc-universe',
    patterns: [
      /\bpeacemaker\b/i,
      /\bcreature commandos\b/i,
      /\bsupergirl:\s*woman of tomorrow\b/i,
      /\blanterns\b/i,
      /\bjustice league\b/i,
    ],
    label: 'DC Studios Continuity',
    defaultRelationships: ['Shared Universe', 'Spin-off'],
  },
  {
    franchiseId: 'dc-universe',
    patterns: [/^superman$/i],
    requireStudio: /dc studios|dc films/i,
    label: 'DC Studios Flagship Film',
    defaultRelationships: ['Core Entry', 'Shared Universe'],
  },
  {
    franchiseId: 'john-wick',
    patterns: [/\bjohn wick\b/i, /\bfrom the world of john wick\b/i, /\bthe continental\b/i],
    label: 'World of John Wick',
    defaultRelationships: ['Spin-off', 'Shared Universe'],
  },
  {
    franchiseId: 'conjuring-universe',
    patterns: [/\bthe conjuring\b/i, /\bannabelle\b/i, /\bthe nun\b/i],
    label: 'The Conjuring Universe',
    defaultRelationships: ['Sequel', 'Shared Universe'],
  },
  {
    franchiseId: 'westeros-chronicles',
    patterns: [
      /\bgame of thrones\b/i,
      /\bhouse of the dragon\b/i,
      /\bknight of the seven kingdoms\b/i,
    ],
    label: 'Westeros / A Song of Ice & Fire',
    defaultRelationships: ['Prequel', 'Spin-off', 'Shared Universe'],
  },
  {
    franchiseId: 'demon-slayer',
    patterns: [/\bdemon slayer\b/i, /\bkimetsu no yaiba\b/i],
    label: 'Demon Slayer Anime Saga',
    defaultRelationships: ['Core Entry', 'Sequel'],
  },
  {
    franchiseId: 'attack-on-titan',
    patterns: [/\battack on titan\b/i, /\bshingeki no kyojin\b/i],
    label: 'Attack on Titan Saga',
    defaultRelationships: ['Sequel', 'Special'],
  },
  {
    franchiseId: 'money-heist-universe',
    patterns: [/\bmoney heist\b/i, /\bla casa de papel\b/i],
    label: 'La Casa de Papel Universe',
    defaultRelationships: ['Spin-off', 'Shared Universe'],
  },
];

export interface FranchiseDetectionContext {
  tmdbCollectionId?: number | null;
  tmdbCollectionName?: string | null;
  productionCompanies?: string[];
}

/**
 * Detects whether a newly released or upcoming movie, series, drama, or anime
 * belongs to a verified franchise using official TMDB collections, production
 * studios, and strict franchise lineage rules.
 */
export function detectRelatedFranchise(
  item: MediaSummary,
  context: FranchiseDetectionContext = {},
  extraFranchises: FranchiseDetail[] = []
): DetectedFranchiseMatch | null {
  const allFranchises = mergeFranchisesById(CURATED_FRANCHISES, extraFranchises);
  const byId = new Map(allFranchises.map((f) => [f.id, f]));

  const buildMatch = (
    franchiseId: string,
    matchReason: string,
    confidence: 'high' | 'medium',
    suggestedRelationships: string[]
  ): DetectedFranchiseMatch | null => {
    const fr = byId.get(franchiseId);
    if (!fr) return null;
    const alreadyInFranchise = fr.orders.complete.some((e) => e.titleKey === item.titleKey);
    const yearTag = item.releaseYear ? ` (${item.releaseYear})` : '';
    const rels =
      item.mediaType !== 'movie' && !suggestedRelationships.includes('Spin-off')
        ? Array.from(new Set([...suggestedRelationships, 'Shared Universe']))
        : suggestedRelationships;
    return {
      franchiseId: fr.id,
      franchiseName: fr.name,
      matchReason,
      confidence,
      suggestedRelationships: rels.slice(0, 4),
      suggestedOrderNote: `New ${item.mediaType === 'movie' ? 'film' : item.mediaType === 'anime' ? 'anime' : 'series'} release${yearTag} detected via ${matchReason}.`,
      alreadyInFranchise,
    };
  };

  // 1. Direct exact titleKey membership in any curated franchise
  for (const fr of allFranchises) {
    if (fr.orders.complete.some((e) => e.titleKey === item.titleKey)) {
      return buildMatch(fr.id, 'Verified Franchise Entry', 'high', ['Core Entry']);
    }
  }

  // 2. Official TMDB Collection ID match (highest precision for films)
  if (context.tmdbCollectionId && TMDB_COLLECTION_TO_FRANCHISE[context.tmdbCollectionId]) {
    const mapped = TMDB_COLLECTION_TO_FRANCHISE[context.tmdbCollectionId];
    return buildMatch(
      mapped.franchiseId,
      `TMDB Official Collection (${context.tmdbCollectionName || mapped.label})`,
      'high',
      ['Core Entry', 'Sequel', 'Shared Universe']
    );
  }

  // 3. Official Studio + Title Lineage Check
  const studiosJoined = (context.productionCompanies || []).join(' | ');
  const combinedTitle = `${item.title} ${item.originalTitle || ''}`.trim();

  for (const rule of VERIFIED_LINEAGE_RULES) {
    if (rule.patterns.some((re) => re.test(combinedTitle))) {
      if (rule.requireStudio && (!studiosJoined || !rule.requireStudio.test(studiosJoined))) {
        continue;
      }
      return buildMatch(
        rule.franchiseId,
        rule.label,
        'high',
        rule.defaultRelationships
      );
    }
  }

  // 4. Verified Production Studio match for Marvel Studios / DC Studios / Lucasfilm
  if (studiosJoined) {
    if (/\bmarvel studios\b/i.test(studiosJoined)) {
      return buildMatch(
        'marvel-cinematic-universe',
        'Official Marvel Studios Production',
        'high',
        ['Shared Universe', item.mediaType === 'movie' ? 'Sequel' : 'Spin-off']
      );
    }
    if (/\bdc studios\b/i.test(studiosJoined)) {
      return buildMatch(
        'dc-universe',
        'Official DC Studios Production',
        'high',
        ['Shared Universe', item.mediaType === 'movie' ? 'Core Entry' : 'Spin-off']
      );
    }
  }

  return null;
}

