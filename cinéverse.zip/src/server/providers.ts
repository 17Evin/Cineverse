import type {
  CastMember,
  CatalogUpdatesResponse,
  CrewMember,
  DiscoverResponse,
  EpisodeItem,
  FranchiseDetail,
  HomeFeedResponse,
  MediaDetail,
  MediaSummary,
  MediaType,
  MetadataSource,
  NewReleaseItem,
  RelatedFranchiseLink,
  ReleaseBucket,
  ReleaseCategory,
  SearchResponse,
  SeasonGroup,
  StreamingAvailability,
  StreamingProviderOption,
  TrailerInfo,
} from '../types/media.ts';
import {
  CURATED_FRANCHISES,
  detectRelatedFranchise,
  getParentFranchisesForTitle,
  matchFranchisesForQuery,
} from './franchises.ts';
import {
  discoverAniList,
  getAniListDetail,
  getAniListPostersByMalIds,
  searchAniList,
} from './anilist.ts';

// ---------------------------------------------------------------------------
// In-Memory TTL Cache & Jikan Rate-Limit Pacing
// ---------------------------------------------------------------------------

interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

const cache = new Map<string, CacheEntry<unknown>>();

function getCached<T>(key: string): T | null {
  const entry = cache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    cache.delete(key);
    return null;
  }
  return entry.value as T;
}

function setCached<T>(key: string, value: T, ttlMs: number): T {
  // Keep cache bounded
  if (cache.size > 600) {
    const firstKey = cache.keys().next().value;
    if (firstKey) cache.delete(firstKey);
  }
  cache.set(key, { value, expiresAt: Date.now() + ttlMs });
  return value;
}

let jikanCircuitOpenUntil = 0;
let jikanConsecutiveFailures = 0;

function withTimeout<T>(promise: Promise<T>, ms: number, fallback: T): Promise<T> {
  return Promise.race([
    promise.catch(() => fallback),
    new Promise<T>((resolve) => setTimeout(() => resolve(fallback), ms)),
  ]);
}

async function fetchJikan<T>(path: string, ttlMs = 15 * 60 * 1000): Promise<T | null> {
  const cacheKey = `jikan:${path}`;
  const cached = getCached<T>(cacheKey);
  if (cached) return cached;

  if (Date.now() < jikanCircuitOpenUntil) {
    return null;
  }

  try {
    const res = await fetch(`https://api.jikan.moe/v4${path}`, {
      headers: { Accept: 'application/json', 'User-Agent': 'CineverseApp/1.0' },
      signal: AbortSignal.timeout(2500),
    });
    if (!res.ok) {
      jikanConsecutiveFailures += 1;
      if (jikanConsecutiveFailures >= 2) {
        jikanCircuitOpenUntil = Date.now() + 10 * 60 * 1000;
      }
      return null;
    }
    jikanConsecutiveFailures = 0;
    const json = (await res.json()) as T;
    return setCached(cacheKey, json, ttlMs);
  } catch {
    jikanConsecutiveFailures += 1;
    if (jikanConsecutiveFailures >= 2) {
      jikanCircuitOpenUntil = Date.now() + 10 * 60 * 1000;
    }
    return null;
  }
}

async function fetchTvMaze<T>(path: string, ttlMs = 15 * 60 * 1000): Promise<T | null> {
  const cacheKey = `tvmaze:${path}`;
  const cached = getCached<T>(cacheKey);
  if (cached) return cached;

  try {
    const res = await fetch(`https://api.tvmaze.com${path}`, {
      headers: { Accept: 'application/json', 'User-Agent': 'CineverseApp/1.0' },
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as T;
    return setCached(cacheKey, json, ttlMs);
  } catch {
    return null;
  }
}

export function isTmdbConfigured(): boolean {
  return Boolean(process.env.TMDB_API_KEY?.trim() || process.env.TMDB_READ_ACCESS_TOKEN?.trim());
}

async function fetchTmdb<T>(path: string, params: Record<string, string> = {}, ttlMs = 15 * 60 * 1000): Promise<T | null> {
  if (!isTmdbConfigured()) return null;
  const searchParams = new URLSearchParams(params);
  const apiKey = process.env.TMDB_API_KEY?.trim();
  const bearer = process.env.TMDB_READ_ACCESS_TOKEN?.trim();

  if (apiKey && !bearer) {
    searchParams.set('api_key', apiKey);
  }

  const queryStr = searchParams.toString();
  const url = `https://api.themoviedb.org/3${path}${queryStr ? `?${queryStr}` : ''}`;
  const cacheKey = `tmdb:${path}?${new URLSearchParams(params).toString()}`;
  const cached = getCached<T>(cacheKey);
  if (cached) return cached;

  try {
    const headers: Record<string, string> = { Accept: 'application/json' };
    if (bearer) {
      headers.Authorization = `Bearer ${bearer}`;
    }
    const res = await fetch(url, {
      headers,
      signal: AbortSignal.timeout(10000),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as T;
    return setCached(cacheKey, json, ttlMs);
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Normalization Helpers
// ---------------------------------------------------------------------------

const REGION_NAMES: Record<string, string> = {
  IN: 'India',
  US: 'United States',
  GB: 'United Kingdom',
  KR: 'South Korea',
  JP: 'Japan',
  CN: 'China',
  TH: 'Thailand',
  TR: 'Turkey',
  ES: 'Spain',
  FR: 'France',
  DE: 'Germany',
  IT: 'Italy',
  TW: 'Taiwan',
  PH: 'Philippines',
  CA: 'Canada',
  AU: 'Australia',
  SE: 'Sweden',
  MX: 'Mexico',
  BR: 'Brazil',
};

const LANGUAGE_NAMES: Record<string, string> = {
  en: 'English',
  hi: 'Hindi',
  ko: 'Korean',
  ja: 'Japanese',
  zh: 'Chinese',
  th: 'Thai',
  tr: 'Turkish',
  es: 'Spanish',
  fr: 'French',
  de: 'German',
  it: 'Italian',
  tl: 'Tagalog',
  ta: 'Tamil',
  te: 'Telugu',
  ml: 'Malayalam',
  sv: 'Swedish',
  pt: 'Portuguese',
};

const JIKAN_GENRE_IDS: Record<string, number> = {
  Action: 1,
  Adventure: 2,
  Comedy: 4,
  Drama: 8,
  Fantasy: 10,
  Horror: 14,
  Mystery: 7,
  Romance: 22,
  'Science Fiction': 24,
  'Slice of Life': 36,
  Supernatural: 37,
  Thriller: 41,
  Psychological: 40,
  Historical: 13,
};

const TMDB_MOVIE_GENRE_IDS: Record<string, number> = {
  Action: 28,
  Adventure: 12,
  Animation: 16,
  Comedy: 35,
  Crime: 80,
  Documentary: 99,
  Drama: 18,
  Family: 10751,
  Fantasy: 14,
  Historical: 36,
  Horror: 27,
  Mystery: 9648,
  Romance: 10749,
  'Science Fiction': 878,
  Thriller: 53,
};

const TMDB_TV_GENRE_IDS: Record<string, number> = {
  Action: 10759,
  Adventure: 10759,
  Animation: 16,
  Comedy: 35,
  Crime: 80,
  Documentary: 99,
  Drama: 18,
  Family: 10751,
  Fantasy: 10765,
  Mystery: 9648,
  'Science Fiction': 10765,
};

const TMDB_GENRE_BY_ID: Record<number, string> = {
  28: 'Action',
  12: 'Adventure',
  16: 'Animation',
  35: 'Comedy',
  80: 'Crime',
  99: 'Documentary',
  18: 'Drama',
  10751: 'Family',
  14: 'Fantasy',
  36: 'Historical',
  27: 'Horror',
  10402: 'Music',
  9648: 'Mystery',
  10749: 'Romance',
  878: 'Science Fiction',
  53: 'Thriller',
  10752: 'War',
  10759: 'Action & Adventure',
  10765: 'Sci-Fi & Fantasy',
};

function stripHtml(raw: string | null | undefined): string {
  if (!raw) return '';
  return raw
    .replace(/<[^>]+>/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&nbsp;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function parseYear(dateStr: string | null | undefined): number | null {
  if (!dateStr) return null;
  const match = String(dateStr).match(/\d{4}/);
  return match ? Number(match[0]) : null;
}

function parseJikanDurationMinutes(duration: string | null | undefined): number | null {
  if (!duration) return null;
  const hr = duration.match(/(\d+)\s*hr/i);
  const min = duration.match(/(\d+)\s*min/i);
  const total = (hr ? Number(hr[1]) * 60 : 0) + (min ? Number(min[1]) : 0);
  return total > 0 ? total : null;
}

function isAirDateReleased(airDate: string | null | undefined): boolean {
  if (!airDate) return false;
  const parsed = Date.parse(airDate);
  if (Number.isNaN(parsed)) return false;
  return parsed <= Date.now();
}

function normalizeJikanAnime(item: any): MediaSummary {
  const id = String(item.mal_id);
  const isMovie = String(item.type || '').toLowerCase() === 'movie';
  const mediaType: MediaType = isMovie ? 'movie' : 'anime';
  const releaseDate = item.aired?.from ? String(item.aired.from).slice(0, 10) : null;
  const releaseYear = item.year || parseYear(releaseDate);
  const genres = [
    ...(item.genres || []).map((g: any) => g.name),
    ...(item.themes || []).map((t: any) => t.name),
  ]
    .filter(Boolean)
    .slice(0, 6);

  return {
    titleKey: `jikan_${mediaType}_${id}`,
    source: 'jikan',
    mediaType,
    externalId: id,
    title: item.title_english || item.title || 'Untitled Anime',
    originalTitle: item.title_japanese || item.title || '',
    synopsis: (item.synopsis || '').replace(/\s*\[Written by MAL Rewrite\]\s*/g, '').trim(),
    posterUrl: item.images?.jpg?.large_image_url || item.images?.jpg?.image_url || null,
    backdropUrl: item.trailer?.images?.maximum_image_url || item.trailer?.images?.large_image_url || null,
    releaseDate,
    releaseYear,
    country: 'Japan',
    countryCode: 'JP',
    language: 'Japanese',
    genres: genres.length > 0 ? genres : ['Animation'],
    rating: typeof item.score === 'number' ? Number(item.score.toFixed(1)) : null,
    voteCount: typeof item.scored_by === 'number' ? item.scored_by : null,
    popularity: typeof item.members === 'number' ? item.members : null,
    status: item.status || null,
    runtimeMinutes: parseJikanDurationMinutes(item.duration),
    totalSeasons: isMovie ? null : 1,
    totalEpisodes: typeof item.episodes === 'number' ? item.episodes : null,
    sourceAttribution: 'Jikan / MyAnimeList',
    fetchedAt: new Date().toISOString(),
  };
}

function normalizeTvMazeShow(show: any): MediaSummary {
  const id = String(show.id);
  const countryObj = show.network?.country || show.webChannel?.country || null;
  const countryCode = countryObj?.code || inferCountryCodeFromLanguage(show.language) || 'US';
  const country = countryObj?.name || REGION_NAMES[countryCode] || 'International';
  const releaseDate = show.premiered || null;
  const genres: string[] = Array.isArray(show.genres) && show.genres.length > 0 ? show.genres : ['Drama'];
  const isAnime =
    genres.some((g) => g.toLowerCase() === 'anime') ||
    (countryCode === 'JP' && String(show.type || '').toLowerCase() === 'animation');

  return {
    titleKey: `tvmaze_${isAnime ? 'anime' : 'tv'}_${id}`,
    source: 'tvmaze',
    mediaType: isAnime ? 'anime' : 'tv',
    externalId: id,
    title: show.name || 'Untitled Series',
    originalTitle: show.name || '',
    synopsis: stripHtml(show.summary),
    posterUrl: show.image?.original || show.image?.medium || null,
    backdropUrl: show.image?.original || null,
    releaseDate,
    releaseYear: parseYear(releaseDate),
    country,
    countryCode,
    language: show.language || 'Unknown',
    genres,
    rating: typeof show.rating?.average === 'number' ? Number(show.rating.average.toFixed(1)) : null,
    voteCount: null,
    popularity: typeof show.weight === 'number' ? show.weight : null,
    status: show.status || null,
    runtimeMinutes: typeof show.averageRuntime === 'number' ? show.averageRuntime : typeof show.runtime === 'number' ? show.runtime : null,
    totalSeasons: null,
    totalEpisodes: null,
    sourceAttribution: 'TVMaze',
    fetchedAt: new Date().toISOString(),
  };
}

function inferCountryCodeFromLanguage(language: string | null | undefined): string | null {
  if (!language) return null;
  const map: Record<string, string> = {
    Korean: 'KR',
    Japanese: 'JP',
    Hindi: 'IN',
    Tamil: 'IN',
    Telugu: 'IN',
    Chinese: 'CN',
    Mandarin: 'CN',
    Thai: 'TH',
    Turkish: 'TR',
    Spanish: 'ES',
    French: 'FR',
    German: 'DE',
    Italian: 'IT',
    Tagalog: 'PH',
    Swedish: 'SE',
    Portuguese: 'BR',
  };
  return map[language] || null;
}

function normalizeTmdbItem(item: any, explicitType?: 'movie' | 'tv'): MediaSummary {
  const rawType = explicitType || (item.media_type === 'movie' ? 'movie' : 'tv');
  const genres: string[] = Array.isArray(item.genres)
    ? item.genres.map((g: any) => g.name).filter(Boolean)
    : Array.isArray(item.genre_ids)
      ? item.genre_ids.map((id: number) => TMDB_GENRE_BY_ID[id]).filter(Boolean)
      : [];

  const originCountryCode =
    (Array.isArray(item.origin_country) && item.origin_country[0]) ||
    (Array.isArray(item.production_countries) && item.production_countries[0]?.iso_3166_1) ||
    (item.original_language === 'ko'
      ? 'KR'
      : item.original_language === 'ja'
        ? 'JP'
        : item.original_language === 'hi'
          ? 'IN'
          : 'US');

  const isAnime =
    rawType === 'tv' &&
    item.original_language === 'ja' &&
    genres.some((g) => g.toLowerCase() === 'animation');

  const mediaType: MediaType = isAnime ? 'anime' : rawType;
  const id = String(item.id);
  const releaseDate = item.release_date || item.first_air_date || null;

  return {
    titleKey: `tmdb_${mediaType}_${id}`,
    source: 'tmdb',
    mediaType,
    externalId: id,
    title: item.title || item.name || 'Untitled',
    originalTitle: item.original_title || item.original_name || '',
    synopsis: item.overview || '',
    posterUrl: item.poster_path ? `https://image.tmdb.org/t/p/w500${item.poster_path}` : null,
    backdropUrl: item.backdrop_path ? `https://image.tmdb.org/t/p/w1280${item.backdrop_path}` : null,
    releaseDate,
    releaseYear: parseYear(releaseDate),
    country: REGION_NAMES[originCountryCode] || originCountryCode,
    countryCode: originCountryCode,
    language: LANGUAGE_NAMES[item.original_language] || item.original_language || 'Unknown',
    genres: genres.length > 0 ? genres : [rawType === 'movie' ? 'Film' : 'Series'],
    rating: typeof item.vote_average === 'number' && item.vote_average > 0 ? Number(item.vote_average.toFixed(1)) : null,
    voteCount: typeof item.vote_count === 'number' ? item.vote_count : null,
    popularity: typeof item.popularity === 'number' ? Math.round(item.popularity) : null,
    status: item.status || null,
    runtimeMinutes:
      typeof item.runtime === 'number'
        ? item.runtime
        : Array.isArray(item.episode_run_time) && item.episode_run_time[0]
          ? item.episode_run_time[0]
          : null,
    totalSeasons: typeof item.number_of_seasons === 'number' ? item.number_of_seasons : null,
    totalEpisodes: typeof item.number_of_episodes === 'number' ? item.number_of_episodes : null,
    sourceAttribution: 'TMDB',
    fetchedAt: new Date().toISOString(),
  };
}

// ---------------------------------------------------------------------------
// TVMaze Global Catalog Pool (cached index + real international drama queries)
// ---------------------------------------------------------------------------

const INTERNATIONAL_DRAMA_SEEDS: Record<string, string[]> = {
  KR: ['Crash Landing on You', 'Squid Game', 'Goblin', 'Kingdom', 'Reply 1988', 'Vincenzo', 'Mr. Sunshine', 'Signal'],
  IN: ['Sacred Games', 'Mirzapur', 'Panchayat', 'Scam 1992', 'The Family Man', 'Delhi Crime', 'Paatal Lok'],
  JP: ['Alice in Borderland', 'Midnight Diner', 'First Love', 'Hana Yori Dango', 'Gannibal'],
  TR: ['Ezel', 'Dirilis', 'Kara Para Ask', 'Ethos', 'The Protector'],
  ES: ['La Casa de Papel', 'Elite', 'Vis a Vis', 'Cable Girls'],
  DE: ['Dark', 'Babylon Berlin', '1899', 'How to Sell Drugs Online'],
  FR: ['Lupin', 'Call My Agent', 'Les Revenants', 'The Bureau'],
  IT: ['Gomorrah', 'Suburra', 'My Brilliant Friend', 'Lidia Poet'],
  TH: ['Girl from Nowhere', '2gether', 'Bad Genius', 'F4 Thailand'],
  CN: ['The Untamed', 'Three-Body', 'Story of Yanxi Palace', 'Nirvana in Fire'],
  TW: ['Someday or One Day', 'Light the Night', 'The Victims Game'],
  PH: ['Trese', 'Replacing Chef Chico', 'Maria Clara'],
  GB: ['Sherlock', 'Peaky Blinders', 'Fleabag', 'Broadchurch', 'Line of Duty', 'The Crown'],
};

async function getTvMazeIndexPool(): Promise<MediaSummary[]> {
  const cacheKey = 'tvmaze:index_pool_v1';
  const cached = getCached<MediaSummary[]>(cacheKey);
  if (cached) return cached;

  const [p0, p1] = await Promise.all([
    fetchTvMaze<any[]>('/shows?page=0', 60 * 60 * 1000),
    fetchTvMaze<any[]>('/shows?page=1', 60 * 60 * 1000),
  ]);

  const rawShows = [...(p0 || []), ...(p1 || [])];
  const seen = new Set<string>();
  const normalized: MediaSummary[] = [];

  for (const show of rawShows) {
    if (!show?.id || !show?.image?.medium) continue;
    const item = normalizeTvMazeShow(show);
    if (!seen.has(item.titleKey)) {
      seen.add(item.titleKey);
      normalized.push(item);
    }
  }

  return setCached(cacheKey, normalized, 60 * 60 * 1000);
}

async function getTvMazeByCountry(countryCode: string): Promise<MediaSummary[]> {
  const code = countryCode.toUpperCase();
  const cacheKey = `tvmaze:country:${code}`;
  const cached = getCached<MediaSummary[]>(cacheKey);
  if (cached) return cached;

  const pool = await getTvMazeIndexPool();
  const matched = pool.filter((s) => s.countryCode === code);

  const seeds = INTERNATIONAL_DRAMA_SEEDS[code];
  if (seeds && matched.length < 10) {
    const seedResults = await Promise.all(
      seeds.map((q) => fetchTvMaze<any[]>(`/search/shows?q=${encodeURIComponent(q)}`, 60 * 60 * 1000))
    );
    const seen = new Set(matched.map((m) => m.titleKey));
    for (const group of seedResults) {
      if (!Array.isArray(group)) continue;
      for (const entry of group.slice(0, 3)) {
        if (!entry?.show) continue;
        const normalized = normalizeTvMazeShow(entry.show);
        if (normalized.countryCode === code && !seen.has(normalized.titleKey)) {
          seen.add(normalized.titleKey);
          matched.push(normalized);
        }
      }
    }
  }

  matched.sort((a, b) => (b.rating || 0) - (a.rating || 0) || (b.popularity || 0) - (a.popularity || 0));
  return setCached(cacheKey, matched, 30 * 60 * 1000);
}

// ---------------------------------------------------------------------------
// Home Feed Aggregator
// ---------------------------------------------------------------------------

export async function getHomeFeed(): Promise<HomeFeedResponse> {
  const cacheKey = 'home_feed_v1';
  const cached = getCached<HomeFeedResponse>(cacheKey);
  if (cached) return cached;

  const tmdbOn = isTmdbConfigured();

  if (tmdbOn) {
    const [
      trendingRes,
      popMoviesRes,
      popTvRes,
      topDramasRes,
      upcomingRes,
      topAnimeRes,
      hiddenRes,
    ] = await Promise.all([
      fetchTmdb<any>('/trending/all/week'),
      fetchTmdb<any>('/movie/popular'),
      fetchTmdb<any>('/tv/popular'),
      fetchTmdb<any>('/discover/tv', { with_genres: '18', sort_by: 'vote_average.desc', 'vote_count.gte': '400' }),
      fetchTmdb<any>('/movie/upcoming'),
      discoverAniList({ limit: 14, sortBy: 'popularity' }),
      fetchTmdb<any>('/discover/movie', {
        sort_by: 'vote_average.desc',
        'vote_count.gte': '150',
        'vote_count.lte': '1500',
        'vote_average.gte': '7.6',
      }),
    ]);

    const trendingWorldwide = (trendingRes?.results || [])
      .filter((x: any) => x.media_type === 'movie' || x.media_type === 'tv')
      .slice(0, 14)
      .map((x: any) => normalizeTmdbItem(x));
    const popularMovies = (popMoviesRes?.results || []).slice(0, 14).map((x: any) => normalizeTmdbItem(x, 'movie'));
    const popularSeries = (popTvRes?.results || []).slice(0, 14).map((x: any) => normalizeTmdbItem(x, 'tv'));
    const popularAnime = topAnimeRes.items;
    const topRatedDramas = (topDramasRes?.results || []).slice(0, 14).map((x: any) => normalizeTmdbItem(x, 'tv'));
    const hiddenGems = (hiddenRes?.results || []).slice(0, 14).map((x: any) => normalizeTmdbItem(x, 'movie'));
    const upcomingReleases = (upcomingRes?.results || []).slice(0, 14).map((x: any) => normalizeTmdbItem(x, 'movie'));
    const recentlyReleased = [...trendingWorldwide]
      .sort((a, b) => (b.releaseYear || 0) - (a.releaseYear || 0))
      .slice(0, 14);

    const payload: HomeFeedResponse = {
      tmdbConfigured: true,
      featured: trendingWorldwide[0] || popularAnime[0] || null,
      trendingWorldwide,
      popularMovies,
      popularSeries,
      popularAnime,
      topRatedDramas,
      hiddenGems,
      recentlyReleased,
      upcomingReleases,
      fetchedAt: new Date().toISOString(),
    };
    return setCached(cacheKey, payload, 15 * 60 * 1000);
  }

  // Live public API mode (AniList + TVMaze) when TMDB_API_KEY is not configured
  const [
    topAnimeRes,
    animeMoviesRes,
    seasonNowRes,
    upcomingAnimeRes,
    tvPool,
    krDramas,
    inDramas,
  ] = await Promise.all([
    discoverAniList({ limit: 14, sortBy: 'popularity' }),
    discoverAniList({ limit: 14, isMovie: true, sortBy: 'rating' }),
    discoverAniList({ limit: 14, status: 'airing', sortBy: 'popularity' }),
    discoverAniList({ limit: 14, status: 'upcoming', sortBy: 'popularity' }),
    getTvMazeIndexPool(),
    getTvMazeByCountry('KR'),
    getTvMazeByCountry('IN'),
  ]);

  const popularAnime = topAnimeRes.items;
  const popularMovies = animeMoviesRes.items;
  const recentlyReleased = seasonNowRes.items;
  const upcomingReleases = upcomingAnimeRes.items;

  const popularSeries = [...tvPool]
    .sort((a, b) => (b.popularity || 0) - (a.popularity || 0))
    .slice(0, 14);

  const combinedDramas = [...krDramas, ...inDramas, ...tvPool.filter((s) => s.genres.includes('Drama'))];
  const dramaSeen = new Set<string>();
  const topRatedDramas = combinedDramas
    .filter((item) => {
      if (dramaSeen.has(item.titleKey)) return false;
      dramaSeen.add(item.titleKey);
      return (item.rating || 0) >= 7.5;
    })
    .sort((a, b) => (b.rating || 0) - (a.rating || 0))
    .slice(0, 14);

  const hiddenGems = [...tvPool]
    .filter((s) => (s.rating || 0) >= 8.0 && (s.popularity || 100) < 92)
    .sort((a, b) => (b.rating || 0) - (a.rating || 0))
    .slice(0, 14);

  const trendingWorldwide: MediaSummary[] = [];
  const maxLen = Math.max(krDramas.length, popularAnime.length, popularSeries.length);
  for (let i = 0; i < Math.min(maxLen, 6); i++) {
    if (krDramas[i]) trendingWorldwide.push(krDramas[i]);
    if (popularAnime[i]) trendingWorldwide.push(popularAnime[i]);
    if (popularSeries[i]) trendingWorldwide.push(popularSeries[i]);
  }

  const featured =
    popularAnime.find((a: MediaSummary) => Boolean(a.backdropUrl && a.synopsis.length > 80)) ||
    krDramas[0] ||
    popularSeries[0] ||
    popularAnime[0] ||
    null;

  const payload: HomeFeedResponse = {
    tmdbConfigured: false,
    featured,
    trendingWorldwide: trendingWorldwide.slice(0, 14),
    popularMovies,
    popularSeries,
    popularAnime,
    topRatedDramas,
    hiddenGems,
    recentlyReleased,
    upcomingReleases,
    fetchedAt: new Date().toISOString(),
  };

  return setCached(cacheKey, payload, 15 * 60 * 1000);
}

// ---------------------------------------------------------------------------
// Global Discovery & Filtering
// ---------------------------------------------------------------------------

export interface DiscoverParams {
  mediaType?: 'all' | 'movie' | 'tv' | 'anime';
  country?: string;
  language?: string;
  genre?: string;
  year?: string;
  minRating?: number;
  status?: string;
  provider?: string;
  region?: string;
  sortBy?: 'popularity' | 'rating' | 'release_date' | 'title';
  page?: number;
}

export async function discoverTitles(params: DiscoverParams): Promise<DiscoverResponse> {
  const mediaType = params.mediaType || 'all';
  const page = Math.max(1, Number(params.page) || 1);
  const sortBy = params.sortBy || 'popularity';
  const region = (params.region || 'IN').toUpperCase();
  const tmdbOn = isTmdbConfigured();

  // Route 1: Pure Anime Discovery -> Fast AniList GraphQL (always live!)
  if (mediaType === 'anime' && (!params.country || params.country === 'JP')) {
    const res = await discoverAniList({
      page,
      limit: 24,
      genre: params.genre,
      year: params.year,
      minRating: params.minRating,
      status: params.status,
      sortBy,
    });
    return {
      tmdbConfigured: tmdbOn,
      items: res.items,
      page,
      hasMore: res.hasMore,
      totalResults: res.total,
      sourceNotice: null,
    };
  }

  // Route 2: TMDB Discovery when configured
  if (tmdbOn) {
    const endpoint = mediaType === 'movie' ? '/discover/movie' : '/discover/tv';
    const q: Record<string, string> = { page: String(page) };

    if (params.country) q.with_origin_country = params.country.toUpperCase();
    if (params.language) q.with_original_language = params.language.toLowerCase();
    if (params.genre) {
      const gMap = mediaType === 'movie' ? TMDB_MOVIE_GENRE_IDS : TMDB_TV_GENRE_IDS;
      if (gMap[params.genre]) q.with_genres = String(gMap[params.genre]);
    }
    if (params.year && /^\d{4}$/.test(params.year)) {
      if (mediaType === 'movie') q.primary_release_year = params.year;
      else q.first_air_date_year = params.year;
    }
    if (params.minRating && params.minRating > 0) {
      q['vote_average.gte'] = String(params.minRating);
      q['vote_count.gte'] = '30';
    }
    if (params.provider) {
      q.with_watch_providers = params.provider;
      q.watch_region = region;
    }

    const sortMap: Record<string, string> = {
      popularity: 'popularity.desc',
      rating: 'vote_average.desc',
      release_date: mediaType === 'movie' ? 'primary_release_date.desc' : 'first_air_date.desc',
      title: mediaType === 'movie' ? 'original_title.asc' : 'name.asc',
    };
    q.sort_by = sortMap[sortBy] || 'popularity.desc';

    const res = await fetchTmdb<any>(endpoint, q);
    const items = (res?.results || []).map((x: any) =>
      normalizeTmdbItem(x, mediaType === 'movie' ? 'movie' : 'tv')
    );

    return {
      tmdbConfigured: true,
      items,
      page,
      hasMore: page < (res?.total_pages || 1),
      totalResults: res?.total_results || items.length,
      sourceNotice: null,
    };
  }

  // Route 3: Public API Discovery (Jikan Anime Movies + TVMaze Global Series/Dramas)
  let sourceNotice: string | null = null;
  let pool: MediaSummary[] = [];

  if (mediaType === 'movie') {
    const res = await discoverAniList({
      page,
      limit: 24,
      isMovie: true,
      genre: params.genre,
      year: params.year,
      minRating: params.minRating,
      status: params.status,
      sortBy,
    });
    pool = params.country && params.country !== 'JP' ? [] : res.items;
    sourceNotice =
      'Showing verified theatrical anime films from AniList / MyAnimeList. Configure TMDB_API_KEY in server environment variables to unlock global live-action movies and regional streaming filters.';
    return {
      tmdbConfigured: false,
      items: pool,
      page,
      hasMore: !params.country || params.country === 'JP' ? res.hasMore : false,
      totalResults: params.country && params.country !== 'JP' ? 0 : res.total,
      sourceNotice,
    };
  }

  if (params.country) {
    pool = await getTvMazeByCountry(params.country);
    if (params.country.toUpperCase() === 'JP' && mediaType !== 'tv') {
      const animeTop = await discoverAniList({ limit: 20, sortBy: 'popularity' });
      pool = [...pool, ...animeTop.items];
    }
  } else {
    const [tvIndex, kr, inDramas, animeTop] = await Promise.all([
      getTvMazeIndexPool(),
      getTvMazeByCountry('KR'),
      getTvMazeByCountry('IN'),
      mediaType === 'all' ? discoverAniList({ limit: 24, sortBy: 'popularity' }) : Promise.resolve({ items: [] as MediaSummary[] }),
    ]);
    const seen = new Set<string>();
    const combined = [...kr, ...inDramas, ...animeTop.items, ...tvIndex];
    for (const item of combined) {
      if (!seen.has(item.titleKey)) {
        seen.add(item.titleKey);
        pool.push(item);
      }
    }
  }

  // Apply strict client-equivalent filters on verified fields
  if (params.language) {
    const targetLang = (LANGUAGE_NAMES[params.language] || params.language).toLowerCase();
    pool = pool.filter((item) => item.language.toLowerCase().includes(targetLang));
  }
  if (params.genre) {
    const targetGenre = params.genre.toLowerCase();
    pool = pool.filter((item) => item.genres.some((g) => g.toLowerCase().includes(targetGenre)));
  }
  if (params.year && /^\d{4}$/.test(params.year)) {
    const y = Number(params.year);
    pool = pool.filter((item) => item.releaseYear === y);
  }
  if (params.minRating && params.minRating > 0) {
    pool = pool.filter((item) => (item.rating || 0) >= params.minRating!);
  }
  if (params.status) {
    const st = params.status.toLowerCase();
    pool = pool.filter((item) => {
      const s = (item.status || '').toLowerCase();
      if (st === 'airing') return s.includes('running') || s.includes('airing');
      if (st === 'completed') return s.includes('ended') || s.includes('finished');
      if (st === 'upcoming') return s.includes('development') || s.includes('not yet') || s.includes('upcoming');
      return true;
    });
  }
  if (params.provider) {
    sourceNotice =
      'Regional streaming-provider filtering requires TMDB_API_KEY in server environment variables. Showing unfiltered global results.';
  }

  // Sort
  pool.sort((a, b) => {
    if (sortBy === 'rating') return (b.rating || 0) - (a.rating || 0);
    if (sortBy === 'release_date') return (b.releaseYear || 0) - (a.releaseYear || 0);
    if (sortBy === 'title') return a.title.localeCompare(b.title);
    return (b.popularity || 0) - (a.popularity || 0);
  });

  const pageSize = 24;
  const start = (page - 1) * pageSize;
  const items = pool.slice(start, start + pageSize);

  return {
    tmdbConfigured: false,
    items,
    page,
    hasMore: start + pageSize < pool.length,
    totalResults: pool.length,
    sourceNotice,
  };
}

// ---------------------------------------------------------------------------
// Universal Search (Title, Original Title, Actor, Director, Country, Language, Franchise)
// ---------------------------------------------------------------------------

export async function searchAll(query: string): Promise<SearchResponse> {
  const q = query.trim();
  const tmdbOn = isTmdbConfigured();
  if (!q) {
    return { tmdbConfigured: tmdbOn, query: q, results: [], peopleMatches: [], franchiseMatches: [] };
  }

  const lowerQ = q.toLowerCase();
  const searchCacheKey = `search_all:${lowerQ}`;
  const cachedSearch = getCached<SearchResponse>(searchCacheKey);
  if (cachedSearch) return cachedSearch;

  // Intelligent Franchise & Universe Matching (character, alias, universe, entry title, companion guides)
  const rawFranchiseMatches = matchFranchisesForQuery(q);
  const franchiseMatches = await Promise.all(
    rawFranchiseMatches.map(async (fm) => {
      if (fm.posterUrl) return fm;
      const fr = CURATED_FRANCHISES.find((c) => c.id === fm.id);
      const lead = fr?.orders.recommended[0] || fr?.orders.complete[0];
      if (!lead) return fm;
      const poster = await withTimeout(fetchEntryLeadPoster(lead), 1400, null);
      return { ...fm, posterUrl: poster };
    })
  );

  // Check if query matches a country name
  const matchedCountryEntry = Object.entries(REGION_NAMES).find(
    ([code, name]) => name.toLowerCase() === lowerQ || code.toLowerCase() === lowerQ
  );

  // Strictly bounded per-provider timeouts so search ALWAYS responds rapidly
  const [tmdbRes, tvMazeRes, tvMazePeople, aniListItems, countryShows] = await Promise.all([
    tmdbOn
      ? withTimeout(fetchTmdb<any>('/search/multi', { query: q }, 5 * 60 * 1000), 3500, null)
      : Promise.resolve(null),
    withTimeout(fetchTvMaze<any[]>(`/search/shows?q=${encodeURIComponent(q)}`, 5 * 60 * 1000), 3500, null),
    withTimeout(fetchTvMaze<any[]>(`/search/people?q=${encodeURIComponent(q)}`, 5 * 60 * 1000), 3500, null),
    withTimeout(searchAniList(q, 12), 3500, [] as MediaSummary[]),
    matchedCountryEntry
      ? withTimeout(getTvMazeByCountry(matchedCountryEntry[0]), 3500, [] as MediaSummary[])
      : Promise.resolve([] as MediaSummary[]),
  ]);

  const results: MediaSummary[] = [];
  const seen = new Set<string>();
  const pushUnique = (item: MediaSummary) => {
    if (!seen.has(item.titleKey)) {
      seen.add(item.titleKey);
      results.push(item);
    }
  };

  const peopleMatches: SearchResponse['peopleMatches'] = [];

  if (tmdbRes?.results) {
    for (const r of tmdbRes.results) {
      if (r.media_type === 'movie' || r.media_type === 'tv') {
        pushUnique(normalizeTmdbItem(r));
      } else if (r.media_type === 'person') {
        const known = Array.isArray(r.known_for) && r.known_for[0] ? normalizeTmdbItem(r.known_for[0]) : null;
        if (known) pushUnique(known);
        peopleMatches.push({
          id: `tmdb_person_${r.id}`,
          name: r.name,
          role: r.known_for_department || 'Cast & Crew',
          country: null,
          imageUrl: r.profile_path ? `https://image.tmdb.org/t/p/w185${r.profile_path}` : null,
          knownForTitleKey: known?.titleKey || null,
        });
      }
    }
  }

  for (const item of countryShows.slice(0, 10)) {
    pushUnique(item);
  }

  // Interleave TVMaze & AniList results so both dramas/series and anime appear near the top
  const tvNormalized = Array.isArray(tvMazeRes)
    ? tvMazeRes
        .slice(0, 12)
        .filter((e) => Boolean(e?.show))
        .map((e) => normalizeTvMazeShow(e.show))
    : [];

  const maxMix = Math.max(tvNormalized.length, aniListItems.length);
  for (let i = 0; i < maxMix; i++) {
    if (tvNormalized[i]) pushUnique(tvNormalized[i]);
    if (aniListItems[i]) pushUnique(aniListItems[i]);
  }

  if (Array.isArray(tvMazePeople)) {
    for (const entry of tvMazePeople.slice(0, 6)) {
      const p = entry?.person;
      if (!p) continue;
      peopleMatches.push({
        id: `tvmaze_person_${p.id}`,
        name: p.name,
        role: 'Actor / Television Crew',
        country: p.country?.name || null,
        imageUrl: p.image?.medium || null,
        knownForTitleKey: null,
      });
    }
  }

  const response: SearchResponse = {
    tmdbConfigured: tmdbOn,
    query: q,
    results: results.slice(0, 30),
    peopleMatches: peopleMatches.slice(0, 8),
    franchiseMatches,
  };

  return setCached(searchCacheKey, response, 5 * 60 * 1000);
}

// ---------------------------------------------------------------------------
// Title Detail + Seasons + Episodes + Streaming Availability
// ---------------------------------------------------------------------------

function unavailableStreaming(region: string, source: string, note?: string): StreamingAvailability {
  const code = region.toUpperCase();
  return {
    region: code,
    regionName: REGION_NAMES[code] || code,
    source,
    updatedAt: new Date().toISOString(),
    available: false,
    link: null,
    providers: [],
    note: note || null,
  };
}

export async function getTitleDetail(
  source: MetadataSource,
  mediaType: MediaType,
  externalId: string,
  region = 'IN'
): Promise<MediaDetail | null> {
  const cleanRegion = (region || 'IN').toUpperCase();
  let detail: MediaDetail | null = null;

  if (source === 'jikan') {
    detail = await getJikanDetail(externalId, cleanRegion);
  } else if (source === 'tvmaze') {
    detail = await getTvMazeDetail(externalId, cleanRegion);
  } else if (source === 'tmdb') {
    detail = await getTmdbDetail(mediaType, externalId, cleanRegion);
  }

  if (!detail) return null;

  // Attach verified parent franchises and merge verified franchise siblings without duplicates
  const parentFranchises = getParentFranchisesForTitle(detail.titleKey);
  if (parentFranchises.length > 0) {
    const existingKeys = new Set(detail.relatedFranchise.map((r) => r.titleKey));
    const mergedRelated = [...detail.relatedFranchise];
    const primaryFranchise = CURATED_FRANCHISES.find((f) => f.id === parentFranchises[0].id);
    if (primaryFranchise) {
      for (const entry of primaryFranchise.orders.recommended) {
        if (entry.titleKey === detail.titleKey || existingKeys.has(entry.titleKey)) continue;
        existingKeys.add(entry.titleKey);
        mergedRelated.push({
          relationType: entry.relationships[0] || entry.entryType,
          titleKey: entry.titleKey,
          source: entry.source,
          mediaType: entry.mediaType,
          externalId: entry.externalId,
          title: entry.title,
          releaseYear: entry.releaseYear,
          posterUrl: entry.posterUrl,
        });
        if (mergedRelated.length >= 16) break;
      }
    }
    detail = {
      ...detail,
      parentFranchises,
      relatedFranchise: mergedRelated,
    };
  } else {
    detail = {
      ...detail,
      parentFranchises: [],
    };
  }

  return detail;
}

async function getJikanDetail(malId: string, region: string): Promise<MediaDetail | null> {
  // Prefer fast AniList GraphQL (250ms, supports idMal + al_ IDs); fall back to Jikan if needed
  const aniDetail = await getAniListDetail(malId, region);
  if (aniDetail) return aniDetail;

  if (malId.startsWith('al_')) return null;

  const [fullRes, charsRes, staffRes, epRes1, recRes] = await Promise.all([
    fetchJikan<any>(`/anime/${encodeURIComponent(malId)}/full`),
    fetchJikan<any>(`/anime/${encodeURIComponent(malId)}/characters`),
    fetchJikan<any>(`/anime/${encodeURIComponent(malId)}/staff`),
    fetchJikan<any>(`/anime/${encodeURIComponent(malId)}/episodes?page=1`),
    fetchJikan<any>(`/anime/${encodeURIComponent(malId)}/recommendations`),
  ]);

  const item = fullRes?.data;
  if (!item) return null;

  const summary = normalizeJikanAnime(item);
  const episodesRaw: any[] = [...(epRes1?.data || [])];

  // Fetch page 2 if more than 100 episodes exist
  if (epRes1?.pagination?.has_next_page) {
    const epRes2 = await fetchJikan<any>(`/anime/${encodeURIComponent(malId)}/episodes?page=2`);
    if (Array.isArray(epRes2?.data)) {
      episodesRaw.push(...epRes2.data);
    }
  }

  const defaultRuntime = summary.runtimeMinutes || 24;
  const episodeItems: EpisodeItem[] = episodesRaw.map((ep: any) => {
    const epNum = Number(ep.mal_id) || 0;
    const airDate = ep.aired ? String(ep.aired).slice(0, 10) : null;
    const isReleased = airDate ? isAirDateReleased(airDate) : summary.status === 'Finished Airing';
    return {
      episodeKey: `${summary.titleKey}_s1_e${epNum}`,
      seasonNumber: 1,
      episodeNumber: epNum,
      isSpecial: false,
      name: ep.title || `Episode ${epNum}`,
      overview: ep.title_romanji && ep.title_romanji !== ep.title ? `Original: ${ep.title_romanji}` : null,
      airDate,
      isReleased,
      runtimeMinutes: defaultRuntime,
      thumbnailUrl: null,
      rating: typeof ep.score === 'number' ? Number(ep.score.toFixed(1)) : null,
      isFiller: Boolean(ep.filler),
      isRecap: Boolean(ep.recap),
    };
  });

  // If Jikan /episodes returned empty for a short/finished TV series where totalEpisodes is verified, keep honest empty notice rather than fabricating episode names!
  const seasons: SeasonGroup[] =
    summary.mediaType === 'movie'
      ? []
      : episodeItems.length > 0
        ? [
            {
              seasonNumber: 1,
              name: 'Season 1',
              isSpecials: false,
              episodeCount: episodeItems.length,
              releasedEpisodeCount: episodeItems.filter((e) => e.isReleased).length,
              airDate: summary.releaseDate,
              posterUrl: summary.posterUrl,
              episodes: episodeItems,
            },
          ]
        : [];

  const cast: CastMember[] = (charsRes?.data || []).slice(0, 14).map((c: any) => {
    const jpVa = (c.voice_actors || []).find((v: any) => v.language === 'Japanese') || c.voice_actors?.[0];
    return {
      id: String(c.character?.mal_id || Math.random()),
      name: jpVa?.person?.name || c.character?.name || 'Unknown',
      character: c.character?.name ? `${c.character.name} (${c.role || 'Cast'})` : 'Cast',
      profileUrl: jpVa?.person?.images?.jpg?.image_url || c.character?.images?.jpg?.image_url || null,
    };
  });

  const crew: CrewMember[] = (staffRes?.data || []).slice(0, 12).map((s: any) => ({
    id: String(s.person?.mal_id || Math.random()),
    name: s.person?.name || 'Unknown',
    role: Array.isArray(s.positions) ? s.positions.join(', ') : 'Staff',
    department: 'Production',
  }));

  const trailer: TrailerInfo | null = item.trailer?.youtube_id
    ? {
        name: 'Official Trailer',
        site: 'YouTube',
        url: item.trailer.url || `https://www.youtube.com/watch?v=${item.trailer.youtube_id}`,
        embedUrl: `https://www.youtube.com/embed/${item.trailer.youtube_id}`,
      }
    : null;

  const relatedFranchise: RelatedFranchiseLink[] = [];
  if (Array.isArray(item.relations)) {
    for (const rel of item.relations) {
      for (const entry of rel.entry || []) {
        if (entry.type === 'anime' && entry.mal_id) {
          relatedFranchise.push({
            relationType: rel.relation || 'Related',
            titleKey: `jikan_anime_${entry.mal_id}`,
            source: 'jikan',
            mediaType: 'anime',
            externalId: String(entry.mal_id),
            title: entry.name || `MAL #${entry.mal_id}`,
            releaseYear: null,
            posterUrl: null,
          });
        }
      }
    }
  }

  const similarTitles: MediaSummary[] = (recRes?.data || []).slice(0, 10).map((r: any) => {
    const e = r.entry;
    return {
      titleKey: `jikan_anime_${e.mal_id}`,
      source: 'jikan',
      mediaType: 'anime',
      externalId: String(e.mal_id),
      title: e.title || 'Recommended Anime',
      originalTitle: e.title || '',
      synopsis: '',
      posterUrl: e.images?.jpg?.large_image_url || e.images?.jpg?.image_url || null,
      backdropUrl: null,
      releaseDate: null,
      releaseYear: null,
      country: 'Japan',
      countryCode: 'JP',
      language: 'Japanese',
      genres: ['Anime'],
      rating: null,
      voteCount: r.votes || null,
      popularity: null,
      status: null,
      runtimeMinutes: null,
      totalSeasons: null,
      totalEpisodes: null,
      sourceAttribution: 'Jikan / MyAnimeList',
      fetchedAt: new Date().toISOString(),
    };
  });

  // Verified official streaming links from MyAnimeList/Jikan
  const streamingProviders: StreamingProviderOption[] = (item.streaming || [])
    .filter((s: any) => s?.name && s?.url)
    .map((s: any, idx: number) => ({
      providerId: `jikan_stream_${idx}`,
      providerName: s.name,
      logoUrl: null,
      type: 'subscription' as const,
      link: s.url,
    }));

  const availability: StreamingAvailability =
    streamingProviders.length > 0
      ? {
          region,
          regionName: REGION_NAMES[region] || region,
          source: 'MyAnimeList Official Streaming Registry',
          updatedAt: new Date().toISOString(),
          available: true,
          link: streamingProviders[0].link,
          providers: streamingProviders,
          note: `Global official streaming partners listed by MyAnimeList. Regional catalog availability in ${REGION_NAMES[region] || region} may vary by license.`,
        }
      : unavailableStreaming(region, 'Jikan / MyAnimeList');

  return {
    ...summary,
    tagline: item.season && item.year ? `${item.season[0].toUpperCase()}${item.season.slice(1)} ${item.year} Broadcast` : null,
    productionCompanies: [
      ...(item.studios || []).map((s: any) => s.name),
      ...(item.producers || []).map((p: any) => p.name),
    ].filter(Boolean),
    networkOrStudio: (item.studios || []).map((s: any) => s.name).join(', ') || null,
    cast,
    crew,
    trailer,
    seasons,
    relatedFranchise: relatedFranchise.slice(0, 16),
    similarTitles,
    availability,
  };
}

async function getTvMazeDetail(showId: string, region: string): Promise<MediaDetail | null> {
  const show = await fetchTvMaze<any>(
    `/shows/${encodeURIComponent(showId)}?embed[]=cast&embed[]=crew&embed[]=seasons&embed[]=episodes`
  );
  if (!show?.id) return null;

  const summary = normalizeTvMazeShow(show);
  const rawSeasons: any[] = show._embedded?.seasons || [];
  const rawEpisodes: any[] = show._embedded?.episodes || [];

  const seasonPosterMap = new Map<number, { poster: string | null; premiereDate: string | null; name: string | null }>();
  for (const s of rawSeasons) {
    if (typeof s.number === 'number') {
      seasonPosterMap.set(s.number, {
        poster: s.image?.medium || s.image?.original || null,
        premiereDate: s.premiereDate || null,
        name: s.name || null,
      });
    }
  }

  const grouped = new Map<number, EpisodeItem[]>();
  const specials: EpisodeItem[] = [];

  for (const ep of rawEpisodes) {
    const isSpecial = ep.type === 'significant_special' || ep.type === 'insignificant_special' || ep.number === null;
    const seasonNum = isSpecial ? 0 : Number(ep.season) || 1;
    const epNum = isSpecial ? specials.length + 1 : Number(ep.number) || 0;
    const airDate = ep.airdate || null;
    const isReleased = isAirDateReleased(airDate);

    const item: EpisodeItem = {
      episodeKey: `${summary.titleKey}_s${seasonNum}_e${epNum}`,
      seasonNumber: seasonNum,
      episodeNumber: epNum,
      isSpecial,
      name: ep.name || `Episode ${epNum}`,
      overview: stripHtml(ep.summary) || null,
      airDate,
      isReleased,
      runtimeMinutes: typeof ep.runtime === 'number' ? ep.runtime : summary.runtimeMinutes,
      thumbnailUrl: ep.image?.medium || ep.image?.original || null,
      rating: typeof ep.rating?.average === 'number' ? Number(ep.rating.average.toFixed(1)) : null,
    };

    if (isSpecial) {
      specials.push(item);
    } else {
      const list = grouped.get(seasonNum) || [];
      list.push(item);
      grouped.set(seasonNum, list);
    }
  }

  const seasons: SeasonGroup[] = Array.from(grouped.entries())
    .sort((a, b) => a[0] - b[0])
    .map(([seasonNum, eps]) => {
      const meta = seasonPosterMap.get(seasonNum);
      return {
        seasonNumber: seasonNum,
        name: meta?.name ? `Season ${seasonNum}: ${meta.name}` : `Season ${seasonNum}`,
        isSpecials: false,
        episodeCount: eps.length,
        releasedEpisodeCount: eps.filter((e) => e.isReleased).length,
        airDate: meta?.premiereDate || eps[0]?.airDate || null,
        posterUrl: meta?.poster || summary.posterUrl,
        episodes: eps.sort((a, b) => a.episodeNumber - b.episodeNumber),
      };
    });

  if (specials.length > 0) {
    seasons.push({
      seasonNumber: 0,
      name: 'Specials',
      isSpecials: true,
      episodeCount: specials.length,
      releasedEpisodeCount: specials.filter((e) => e.isReleased).length,
      airDate: specials[0]?.airDate || null,
      posterUrl: summary.posterUrl,
      episodes: specials,
    });
  }

  const cast: CastMember[] = (show._embedded?.cast || []).slice(0, 16).map((c: any) => ({
    id: String(c.person?.id || Math.random()),
    name: c.person?.name || 'Unknown',
    character: c.character?.name || 'Cast',
    profileUrl: c.person?.image?.medium || c.character?.image?.medium || null,
  }));

  const crew: CrewMember[] = (show._embedded?.crew || []).slice(0, 12).map((c: any) => ({
    id: String(c.person?.id || Math.random()),
    name: c.person?.name || 'Unknown',
    role: c.type || 'Crew',
    department: 'Production',
  }));

  // Official verified network / webChannel from TVMaze
  const providers: StreamingProviderOption[] = [];
  if (show.webChannel?.name) {
    providers.push({
      providerId: `tvmaze_web_${show.webChannel.id}`,
      providerName: show.webChannel.name,
      logoUrl: null,
      type: 'subscription',
      link: show.officialSite || show.webChannel.officialSite || null,
    });
  } else if (show.network?.name) {
    providers.push({
      providerId: `tvmaze_net_${show.network.id}`,
      providerName: show.network.name,
      logoUrl: null,
      type: 'subscription',
      link: show.officialSite || show.network.officialSite || null,
    });
  }

  const availability: StreamingAvailability =
    providers.length > 0
      ? {
          region,
          regionName: REGION_NAMES[region] || region,
          source: 'TVMaze Network & Web Channel Registry',
          updatedAt: new Date().toISOString(),
          available: true,
          link: providers[0].link,
          providers,
          note: `Original broadcast / streaming platform listed by TVMaze. Configure TMDB_API_KEY for region-specific ${REGION_NAMES[region] || region} JustWatch availability.`,
        }
      : unavailableStreaming(region, 'TVMaze');

  // Check if this title belongs to any curated franchise to populate verified franchise connections
  const relatedFranchise: RelatedFranchiseLink[] = [];
  for (const fr of CURATED_FRANCHISES) {
    if (fr.orders.complete.some((e) => e.titleKey === summary.titleKey)) {
      for (const e of fr.orders.complete) {
        if (e.titleKey !== summary.titleKey) {
          relatedFranchise.push({
            relationType: e.entryType,
            titleKey: e.titleKey,
            source: e.source,
            mediaType: e.mediaType,
            externalId: e.externalId,
            title: e.title,
            releaseYear: e.releaseYear,
            posterUrl: e.posterUrl,
          });
        }
      }
    }
  }

  // Similar titles from same country/genre in TVMaze pool
  const pool = await getTvMazeIndexPool();
  const similarTitles = pool
    .filter(
      (s) =>
        s.titleKey !== summary.titleKey &&
        (s.countryCode === summary.countryCode ||
          s.genres.some((g) => summary.genres.includes(g)))
    )
    .slice(0, 10);

  return {
    ...summary,
    totalSeasons: seasons.filter((s) => !s.isSpecials).length || rawSeasons.length || null,
    totalEpisodes: rawEpisodes.length || null,
    tagline: null,
    productionCompanies: [show.network?.name, show.webChannel?.name].filter(Boolean) as string[],
    networkOrStudio: show.webChannel?.name || show.network?.name || null,
    cast,
    crew,
    trailer: null,
    seasons,
    relatedFranchise,
    similarTitles,
    availability,
  };
}

async function getTmdbDetail(mediaType: MediaType, tmdbId: string, region: string): Promise<MediaDetail | null> {
  const tmdbKind = mediaType === 'movie' ? 'movie' : 'tv';
  const data = await fetchTmdb<any>(`/${tmdbKind}/${encodeURIComponent(tmdbId)}`, {
    append_to_response: 'credits,videos,similar,recommendations,watch/providers',
  });
  if (!data?.id) return null;

  const summary = normalizeTmdbItem(data, tmdbKind);

  const cast: CastMember[] = (data.credits?.cast || []).slice(0, 16).map((c: any) => ({
    id: String(c.id),
    name: c.name,
    character: c.character || 'Cast',
    profileUrl: c.profile_path ? `https://image.tmdb.org/t/p/w185${c.profile_path}` : null,
  }));

  const crew: CrewMember[] = (data.credits?.crew || [])
    .filter((c: any) => ['Director', 'Creator', 'Executive Producer', 'Writer', 'Screenplay'].includes(c.job))
    .slice(0, 12)
    .map((c: any) => ({
      id: `${c.id}_${c.job}`,
      name: c.name,
      role: c.job,
      department: c.department || 'Production',
    }));

  const ytTrailer = (data.videos?.results || []).find(
    (v: any) => v.site === 'YouTube' && (v.type === 'Trailer' || v.type === 'Teaser')
  );
  const trailer: TrailerInfo | null = ytTrailer
    ? {
        name: ytTrailer.name || 'Official Trailer',
        site: 'YouTube',
        url: `https://www.youtube.com/watch?v=${ytTrailer.key}`,
        embedUrl: `https://www.youtube.com/embed/${ytTrailer.key}`,
      }
    : null;

  // Seasons & episodes for TV/Anime
  const seasons: SeasonGroup[] = [];
  if (tmdbKind === 'tv' && Array.isArray(data.seasons)) {
    const seasonFetches = data.seasons.slice(0, 20).map((s: any) =>
      fetchTmdb<any>(`/tv/${encodeURIComponent(tmdbId)}/season/${s.season_number}`)
    );
    const seasonResults = await Promise.all(seasonFetches);
    for (const sData of seasonResults) {
      if (!sData) continue;
      const isSpecials = sData.season_number === 0;
      const eps: EpisodeItem[] = (sData.episodes || []).map((ep: any) => ({
        episodeKey: `${summary.titleKey}_s${sData.season_number}_e${ep.episode_number}`,
        seasonNumber: sData.season_number,
        episodeNumber: ep.episode_number,
        isSpecial: isSpecials,
        name: ep.name || `Episode ${ep.episode_number}`,
        overview: ep.overview || null,
        airDate: ep.air_date || null,
        isReleased: isAirDateReleased(ep.air_date),
        runtimeMinutes: typeof ep.runtime === 'number' ? ep.runtime : summary.runtimeMinutes,
        thumbnailUrl: ep.still_path ? `https://image.tmdb.org/t/p/w300${ep.still_path}` : null,
        rating: typeof ep.vote_average === 'number' && ep.vote_average > 0 ? Number(ep.vote_average.toFixed(1)) : null,
      }));
      seasons.push({
        seasonNumber: sData.season_number,
        name: sData.name || (isSpecials ? 'Specials' : `Season ${sData.season_number}`),
        isSpecials,
        episodeCount: eps.length,
        releasedEpisodeCount: eps.filter((e) => e.isReleased).length,
        airDate: sData.air_date || null,
        posterUrl: sData.poster_path ? `https://image.tmdb.org/t/p/w300${sData.poster_path}` : summary.posterUrl,
        episodes: eps,
      });
    }
    seasons.sort((a, b) => (a.isSpecials ? 1 : b.isSpecials ? -1 : a.seasonNumber - b.seasonNumber));
  }

  // Regional Watch Providers (TMDB / JustWatch)
  const regionProviders = data['watch/providers']?.results?.[region];
  const providers: StreamingProviderOption[] = [];
  if (regionProviders) {
    const pushProviders = (arr: any[] | undefined, type: StreamingProviderOption['type']) => {
      for (const p of arr || []) {
        providers.push({
          providerId: String(p.provider_id),
          providerName: p.provider_name,
          logoUrl: p.logo_path ? `https://image.tmdb.org/t/p/w92${p.logo_path}` : null,
          type,
          link: regionProviders.link || null,
        });
      }
    };
    pushProviders(regionProviders.flatrate, 'subscription');
    pushProviders(regionProviders.free, 'free');
    pushProviders(regionProviders.ads, 'free');
    pushProviders(regionProviders.rent, 'rent');
    pushProviders(regionProviders.buy, 'buy');
  }

  const availability: StreamingAvailability =
    providers.length > 0
      ? {
          region,
          regionName: REGION_NAMES[region] || region,
          source: 'TMDB / JustWatch',
          updatedAt: new Date().toISOString(),
          available: true,
          link: regionProviders?.link || null,
          providers,
          note: `Verified streaming availability for ${REGION_NAMES[region] || region} via TMDB / JustWatch.`,
        }
      : unavailableStreaming(region, 'TMDB / JustWatch');

  // Franchise / Collection links
  const relatedFranchise: RelatedFranchiseLink[] = [];
  if (data.belongs_to_collection?.id) {
    const col = await fetchTmdb<any>(`/collection/${data.belongs_to_collection.id}`);
    for (const part of col?.parts || []) {
      if (String(part.id) === tmdbId) continue;
      relatedFranchise.push({
        relationType: data.belongs_to_collection.name || 'Collection',
        titleKey: `tmdb_movie_${part.id}`,
        source: 'tmdb',
        mediaType: 'movie',
        externalId: String(part.id),
        title: part.title,
        releaseYear: parseYear(part.release_date),
        posterUrl: part.poster_path ? `https://image.tmdb.org/t/p/w300${part.poster_path}` : null,
      });
    }
  }

  const similarTitles: MediaSummary[] = (data.recommendations?.results || data.similar?.results || [])
    .slice(0, 10)
    .map((x: any) => normalizeTmdbItem(x, tmdbKind));

  return {
    ...summary,
    tagline: data.tagline || null,
    productionCompanies: (data.production_companies || []).map((p: any) => p.name).filter(Boolean),
    networkOrStudio: (data.networks || data.production_companies || []).map((n: any) => n.name).slice(0, 2).join(', ') || null,
    cast,
    crew,
    trailer,
    seasons,
    relatedFranchise,
    similarTitles,
    availability,
  };
}

// ---------------------------------------------------------------------------
// Franchise List & Live Metadata / Streaming Enrichment
// ---------------------------------------------------------------------------

interface EnrichedEntryData {
  posterUrl: string | null;
  backdropUrl: string | null;
  runtimeMinutes: number | null;
  totalSeasons: number | null;
  totalEpisodes: number | null;
  streamingProviders: StreamingProviderOption[];
  availabilityRegion: string;
}

function extractTmdbWatchProviders(regionBlock: any): StreamingProviderOption[] {
  if (!regionBlock) return [];
  const providers: StreamingProviderOption[] = [];
  const seen = new Set<string>();
  const pushProviders = (arr: any[] | undefined, type: StreamingProviderOption['type']) => {
    for (const p of arr || []) {
      const dedupeKey = `${p.provider_id}_${type}`;
      if (seen.has(dedupeKey)) continue;
      seen.add(dedupeKey);
      providers.push({
        providerId: String(p.provider_id),
        providerName: p.provider_name,
        logoUrl: p.logo_path ? `https://image.tmdb.org/t/p/w92${p.logo_path}` : null,
        type,
        link: regionBlock.link || null,
      });
    }
  };
  pushProviders(regionBlock.flatrate, 'subscription');
  pushProviders(regionBlock.free, 'free');
  pushProviders(regionBlock.ads, 'free');
  pushProviders(regionBlock.rent, 'rent');
  pushProviders(regionBlock.buy, 'buy');
  return providers;
}

async function fetchEntryLeadPoster(entry: {
  titleKey: string;
  source: MetadataSource;
  mediaType: MediaType;
  externalId: string;
  posterUrl?: string | null;
}): Promise<string | null> {
  if (entry.posterUrl) return entry.posterUrl;
  const cacheKey = `lead_poster_v1:${entry.titleKey}`;
  const cached = getCached<string | null>(cacheKey);
  if (cached !== null) return cached;

  let poster: string | null = null;
  if (entry.source === 'tmdb' && isTmdbConfigured()) {
    const tmdbKind = entry.mediaType === 'movie' ? 'movie' : 'tv';
    const data = await fetchTmdb<any>(`/${tmdbKind}/${encodeURIComponent(entry.externalId)}`, {}, 60 * 60 * 1000);
    poster = data?.poster_path ? `https://image.tmdb.org/t/p/w500${data.poster_path}` : null;
  } else if (entry.source === 'tvmaze') {
    const show = await fetchTvMaze<any>(`/shows/${encodeURIComponent(entry.externalId)}`, 60 * 60 * 1000);
    poster = show?.image?.medium || show?.image?.original || null;
  } else if (entry.source === 'jikan') {
    const malNum = Number(entry.externalId);
    if (Number.isFinite(malNum) && malNum > 0) {
      const map = await getAniListPostersByMalIds([malNum]);
      poster = map.get(String(malNum)) || null;
    }
  }

  return setCached(cacheKey, poster, 60 * 60 * 1000);
}

async function runInChunks<T, R>(items: T[], chunkSize: number, worker: (item: T) => Promise<R>): Promise<R[]> {
  const results: R[] = [];
  for (let i = 0; i < items.length; i += chunkSize) {
    const slice = items.slice(i, i + chunkSize);
    const chunkRes = await Promise.all(slice.map(worker));
    results.push(...chunkRes);
  }
  return results;
}

export async function getFranchises(franchiseId?: string, region = 'IN'): Promise<FranchiseDetail[]> {
  const cleanRegion = (region || 'IN').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 4) || 'IN';

  // Directory mode (fast): enrich only each franchise's lead poster
  if (!franchiseId) {
    const dirCacheKey = 'franchise_directory_v3';
    const cachedDir = getCached<FranchiseDetail[]>(dirCacheKey);
    if (cachedDir) return cachedDir;

    // Batch-fetch AniList posters for anime franchise leads in a single GraphQL call
    const malLeadIds: number[] = [];
    for (const fr of CURATED_FRANCHISES) {
      const lead = fr.orders.recommended[0] || fr.orders.complete[0];
      if (lead?.source === 'jikan') {
        const n = Number(lead.externalId);
        if (Number.isFinite(n) && n > 0) malLeadIds.push(n);
      }
    }
    const malPosterMap =
      malLeadIds.length > 0
        ? await withTimeout(getAniListPostersByMalIds(malLeadIds), 2500, new Map<string, string | null>())
        : new Map<string, string | null>();

    const directory = await runInChunks(CURATED_FRANCHISES, 8, async (franchise) => {
      const lead = franchise.orders.recommended[0] || franchise.orders.complete[0];
      let posterUrl = franchise.posterUrl || null;
      if (!posterUrl && lead) {
        if (lead.source === 'jikan') {
          posterUrl = malPosterMap.get(String(lead.externalId)) || null;
        } else {
          posterUrl = await withTimeout(fetchEntryLeadPoster(lead), 2200, null);
        }
      }
      return {
        ...franchise,
        posterUrl,
      };
    });

    return setCached(dirCacheKey, directory, 60 * 60 * 1000);
  }

  // Detail mode: enrich every unique entry in this specific franchise with artwork, runtime, seasons/episodes & regional streaming providers
  const target = CURATED_FRANCHISES.find((f) => f.id === franchiseId);
  if (!target) return [];

  const detailCacheKey = `franchise_detail_v3:${target.id}:${cleanRegion}`;
  const cachedDetail = getCached<FranchiseDetail>(detailCacheKey);
  if (cachedDetail) return [cachedDetail];

  const uniqueEntries = new Map<string, FranchiseDetail['orders']['complete'][number]>();
  for (const orderArr of Object.values(target.orders)) {
    for (const entry of orderArr) {
      if (!uniqueEntries.has(entry.titleKey)) {
        uniqueEntries.set(entry.titleKey, entry);
      }
    }
  }

  const enrichedMap = new Map<string, EnrichedEntryData>();
  const tmdbEntries: Array<FranchiseDetail['orders']['complete'][number]> = [];
  const tvMazeEntries: Array<FranchiseDetail['orders']['complete'][number]> = [];
  const malEntries: Array<{ key: string; malId: number }> = [];

  for (const entry of uniqueEntries.values()) {
    if (entry.source === 'tmdb') {
      tmdbEntries.push(entry);
    } else if (entry.source === 'tvmaze') {
      tvMazeEntries.push(entry);
    } else if (entry.source === 'jikan') {
      const num = Number(entry.externalId);
      if (Number.isFinite(num) && num > 0) {
        malEntries.push({ key: entry.titleKey, malId: num });
      }
    }
  }

  const tmdbOn = isTmdbConfigured();

  await Promise.all([
    // 1. TMDB entries (chunked concurrency of 10 with watch/providers)
    tmdbOn && tmdbEntries.length > 0
      ? runInChunks(tmdbEntries, 10, async (entry) => {
          const tmdbKind = entry.mediaType === 'movie' ? 'movie' : 'tv';
          const data = await withTimeout(
            fetchTmdb<any>(
              `/${tmdbKind}/${encodeURIComponent(entry.externalId)}`,
              { append_to_response: 'watch/providers' },
              60 * 60 * 1000
            ),
            4000,
            null
          );
          if (!data?.id) return;
          const regionBlock = data['watch/providers']?.results?.[cleanRegion];
          const runtime =
            typeof data.runtime === 'number'
              ? data.runtime
              : Array.isArray(data.episode_run_time) && data.episode_run_time.length > 0
                ? data.episode_run_time[0]
                : null;
          enrichedMap.set(entry.titleKey, {
            posterUrl: data.poster_path ? `https://image.tmdb.org/t/p/w500${data.poster_path}` : null,
            backdropUrl: data.backdrop_path ? `https://image.tmdb.org/t/p/w1280${data.backdrop_path}` : null,
            runtimeMinutes: runtime,
            totalSeasons:
              tmdbKind === 'tv' && typeof data.number_of_seasons === 'number'
                ? data.number_of_seasons
                : entry.totalSeasons ?? null,
            totalEpisodes:
              tmdbKind === 'tv' && typeof data.number_of_episodes === 'number'
                ? data.number_of_episodes
                : entry.totalEpisodes ?? null,
            streamingProviders: extractTmdbWatchProviders(regionBlock),
            availabilityRegion: cleanRegion,
          });
        })
      : Promise.resolve(),

    // 2. AniList batch posters + details for anime entries
    malEntries.length > 0
      ? (async () => {
          const alPosters = await withTimeout(
            getAniListPostersByMalIds(malEntries.map((m) => m.malId)),
            3000,
            new Map<string, string | null>()
          );
          for (const item of malEntries) {
            const poster = alPosters.get(String(item.malId)) || null;
            enrichedMap.set(item.key, {
              posterUrl: poster,
              backdropUrl: null,
              runtimeMinutes: null,
              totalSeasons: null,
              totalEpisodes: null,
              streamingProviders: [],
              availabilityRegion: cleanRegion,
            });
          }
        })()
      : Promise.resolve(),

    // 3. TVMaze entries
    tvMazeEntries.length > 0
      ? runInChunks(tvMazeEntries, 6, async (entry) => {
          const show = await withTimeout(
            fetchTvMaze<any>(`/shows/${encodeURIComponent(entry.externalId)}`, 60 * 60 * 1000),
            3500,
            null
          );
          if (!show?.id) return;
          const providers: StreamingProviderOption[] = [];
          if (show.webChannel?.name) {
            providers.push({
              providerId: `tvmaze_web_${show.webChannel.id}`,
              providerName: show.webChannel.name,
              logoUrl: null,
              type: 'subscription',
              link: show.officialSite || show.webChannel.officialSite || null,
            });
          } else if (show.network?.name) {
            providers.push({
              providerId: `tvmaze_net_${show.network.id}`,
              providerName: show.network.name,
              logoUrl: null,
              type: 'subscription',
              link: show.officialSite || show.network.officialSite || null,
            });
          }
          enrichedMap.set(entry.titleKey, {
            posterUrl: show.image?.medium || show.image?.original || null,
            backdropUrl: show.image?.original || null,
            runtimeMinutes: typeof show.averageRuntime === 'number' ? show.averageRuntime : null,
            totalSeasons: entry.totalSeasons ?? null,
            totalEpisodes: entry.totalEpisodes ?? null,
            streamingProviders: providers,
            availabilityRegion: cleanRegion,
          });
        })
      : Promise.resolve(),
  ]);

  const enrichList = (list: FranchiseDetail['orders']['release']) =>
    list.map((e) => {
      const meta = enrichedMap.get(e.titleKey);
      if (!meta) return e;
      return {
        ...e,
        posterUrl: meta.posterUrl || e.posterUrl,
        runtimeMinutes: meta.runtimeMinutes ?? e.runtimeMinutes ?? null,
        totalSeasons: meta.totalSeasons ?? e.totalSeasons ?? null,
        totalEpisodes: meta.totalEpisodes ?? e.totalEpisodes ?? null,
        streamingProviders: meta.streamingProviders,
        availabilityRegion: meta.availabilityRegion,
      };
    });

  const leadKey = target.orders.recommended[0]?.titleKey || target.orders.complete[0]?.titleKey;
  const leadMeta = leadKey ? enrichedMap.get(leadKey) : undefined;
  const fallbackBackdrop = Array.from(enrichedMap.values()).find((m) => m.backdropUrl)?.backdropUrl || null;
  const fallbackPoster = Array.from(enrichedMap.values()).find((m) => m.posterUrl)?.posterUrl || null;

  const result: FranchiseDetail = {
    ...target,
    posterUrl: leadMeta?.posterUrl || target.posterUrl || fallbackPoster,
    backdropUrl: leadMeta?.backdropUrl || target.backdropUrl || fallbackBackdrop,
    orders: {
      release: enrichList(target.orders.release),
      chronological: enrichList(target.orders.chronological),
      recommended: enrichList(target.orders.recommended),
      complete: enrichList(target.orders.complete),
    },
  };

  setCached(detailCacheKey, result, 60 * 60 * 1000);
  return [result];
}

// ---------------------------------------------------------------------------
// Random Title Discovery
// ---------------------------------------------------------------------------

export async function getRandomTitle(excludeKeys: string[] = []): Promise<MediaSummary | null> {
  const feed = await getHomeFeed();
  const candidates = [
    ...feed.trendingWorldwide,
    ...feed.popularAnime,
    ...feed.popularSeries,
    ...feed.topRatedDramas,
    ...feed.hiddenGems,
    ...feed.popularMovies,
  ];
  const exclude = new Set(excludeKeys);
  const filtered = candidates.filter((c) => !exclude.has(c.titleKey));
  const pool = filtered.length > 0 ? filtered : candidates;
  if (pool.length === 0) return null;
  return pool[Math.floor(Math.random() * pool.length)];
}

// ---------------------------------------------------------------------------
// Live Catalog Updates (New Movies, Series, Dramas, Anime) & Franchise Sync
// ---------------------------------------------------------------------------

function formatIsoDateOffset(daysOffset: number): string {
  const d = new Date(Date.now() + daysOffset * 24 * 60 * 60 * 1000);
  return d.toISOString().slice(0, 10);
}

function classifyReleaseBucket(releaseDate: string | null, fallback: ReleaseBucket): ReleaseBucket {
  if (!releaseDate) return fallback;
  const ts = Date.parse(releaseDate);
  if (Number.isNaN(ts)) return fallback;
  return ts > Date.now() ? 'upcoming' : fallback;
}

function classifyReleaseCategory(item: MediaSummary, hintedDrama = false): ReleaseCategory {
  if (item.mediaType === 'anime') return 'anime';
  if (item.mediaType === 'movie') return 'movie';
  if (hintedDrama) return 'drama';
  const hasDramaGenre = item.genres.some((g) => g.toLowerCase() === 'drama');
  const dramaRegions = new Set(['KR', 'JP', 'CN', 'TW', 'TH', 'TR', 'IN', 'ES', 'PH']);
  if (hasDramaGenre && dramaRegions.has((item.countryCode || '').toUpperCase())) {
    return 'drama';
  }
  return 'series';
}

export async function getCatalogUpdates(
  options: { forceRefresh?: boolean; region?: string } = {}
): Promise<CatalogUpdatesResponse> {
  const cleanRegion = (options.region || 'IN').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 4) || 'IN';
  const cacheKey = `catalog_updates_v1:${cleanRegion}`;

  if (options.forceRefresh) {
    // Evict cached catalog update & home feed snapshots so upstream providers return fresh titles
    for (const k of Array.from(cache.keys())) {
      if (
        k.startsWith('catalog_updates_') ||
        k.startsWith('home_feed') ||
        k.startsWith('tmdb:/movie/now_playing') ||
        k.startsWith('tmdb:/movie/upcoming') ||
        k.startsWith('tmdb:/tv/on_the_air') ||
        k.startsWith('tmdb:/tv/airing_today') ||
        k.startsWith('tmdb:/discover/')
      ) {
        cache.delete(k);
      }
    }
  } else {
    const cached = getCached<CatalogUpdatesResponse>(cacheKey);
    if (cached) return cached;
  }

  const tmdbOn = isTmdbConfigured();
  const recentStart = formatIsoDateOffset(-540); // last 18 months
  const todayIso = formatIsoDateOffset(0);
  const futureEnd = formatIsoDateOffset(450); // next 15 months

  const [
    nowPlaying,
    upcomingMovies,
    onTheAir,
    airingToday,
    freshDramas,
    franchiseMoviesRadar,
    franchiseTvRadar,
    aniAiring,
    aniUpcoming,
    tvMazePool,
  ] = await Promise.all([
    tmdbOn
      ? withTimeout(fetchTmdb<any>('/movie/now_playing', { page: '1', region: cleanRegion }, 15 * 60 * 1000), 4000, null)
      : Promise.resolve(null),
    tmdbOn
      ? withTimeout(fetchTmdb<any>('/movie/upcoming', { page: '1', region: cleanRegion }, 15 * 60 * 1000), 4000, null)
      : Promise.resolve(null),
    tmdbOn
      ? withTimeout(fetchTmdb<any>('/tv/on_the_air', { page: '1' }, 15 * 60 * 1000), 4000, null)
      : Promise.resolve(null),
    tmdbOn
      ? withTimeout(fetchTmdb<any>('/tv/airing_today', { page: '1' }, 15 * 60 * 1000), 4000, null)
      : Promise.resolve(null),
    // Fresh global dramas (K-Drama, C-Drama, J-Drama, Indian, Turkish, Spanish, etc.)
    tmdbOn
      ? withTimeout(
          fetchTmdb<any>(
            '/discover/tv',
            {
              with_genres: '18',
              sort_by: 'popularity.desc',
              'first_air_date.gte': formatIsoDateOffset(-240),
              'first_air_date.lte': todayIso,
              'vote_count.gte': '5',
              page: '1',
            },
            15 * 60 * 1000
          ),
          4000,
          null
        )
      : Promise.resolve(null),
    // Major franchise studio radar for recent & upcoming movies (Marvel Studios 420, Lucasfilm 1, DC 128064|184898, Universal Jurassic/Fast via keywords/studios, Lionsgate 1632, New Line 12)
    tmdbOn
      ? withTimeout(
          fetchTmdb<any>(
            '/discover/movie',
            {
              with_companies: '420|1|128064|184898|76907|3528|12',
              'primary_release_date.gte': recentStart,
              'primary_release_date.lte': futureEnd,
              sort_by: 'popularity.desc',
              page: '1',
            },
            15 * 60 * 1000
          ),
          4000,
          null
        )
      : Promise.resolve(null),
    // Major franchise studio radar for recent & upcoming series (Marvel Studios, Lucasfilm, DC Studios, HBO Westeros)
    tmdbOn
      ? withTimeout(
          fetchTmdb<any>(
            '/discover/tv',
            {
              with_companies: '420|1|128064|184898|3268',
              'first_air_date.gte': recentStart,
              'first_air_date.lte': futureEnd,
              sort_by: 'popularity.desc',
              page: '1',
            },
            15 * 60 * 1000
          ),
          4000,
          null
        )
      : Promise.resolve(null),
    withTimeout(discoverAniList({ status: 'airing', sortBy: 'popularity', page: 1 }), 3500, {
      items: [] as MediaSummary[],
      hasMore: false,
      total: 0,
    }),
    withTimeout(discoverAniList({ status: 'upcoming', sortBy: 'popularity', page: 1 }), 3500, {
      items: [] as MediaSummary[],
      hasMore: false,
      total: 0,
    }),
    !tmdbOn ? withTimeout(getTvMazeIndexPool(), 4000, [] as MediaSummary[]) : Promise.resolve([] as MediaSummary[]),
  ]);

  interface StagedRelease {
    summary: MediaSummary;
    category: ReleaseCategory;
    releaseBucket: ReleaseBucket;
    checkCollection: boolean;
  }

  const stagedMap = new Map<string, StagedRelease>();
  const addStaged = (
    summary: MediaSummary,
    fallbackBucket: ReleaseBucket,
    hintedDrama = false,
    checkCollection = false
  ) => {
    if (!summary.titleKey || !summary.title) return;
    const existing = stagedMap.get(summary.titleKey);
    if (existing) {
      if (hintedDrama && existing.category === 'series') existing.category = 'drama';
      if (checkCollection) existing.checkCollection = true;
      return;
    }
    stagedMap.set(summary.titleKey, {
      summary,
      category: classifyReleaseCategory(summary, hintedDrama),
      releaseBucket: classifyReleaseBucket(summary.releaseDate, fallbackBucket),
      checkCollection,
    });
  };

  for (const r of (franchiseMoviesRadar?.results || []).slice(0, 18)) {
    addStaged(normalizeTmdbItem(r, 'movie'), 'new_release', false, true);
  }
  for (const r of (franchiseTvRadar?.results || []).slice(0, 12)) {
    addStaged(normalizeTmdbItem(r, 'tv'), 'airing_now', false, false);
  }
  for (const r of (nowPlaying?.results || []).slice(0, 14)) {
    addStaged(normalizeTmdbItem(r, 'movie'), 'new_release', false, true);
  }
  for (const r of (upcomingMovies?.results || []).slice(0, 14)) {
    addStaged(normalizeTmdbItem(r, 'movie'), 'upcoming', false, true);
  }
  for (const r of (freshDramas?.results || []).slice(0, 16)) {
    addStaged(normalizeTmdbItem(r, 'tv'), 'airing_now', true, false);
  }
  for (const r of (onTheAir?.results || []).slice(0, 12)) {
    addStaged(normalizeTmdbItem(r, 'tv'), 'airing_now', false, false);
  }
  for (const r of (airingToday?.results || []).slice(0, 10)) {
    addStaged(normalizeTmdbItem(r, 'tv'), 'airing_now', false, false);
  }
  for (const item of (aniAiring?.items || []).slice(0, 10)) {
    addStaged(item, 'airing_now', false, false);
  }
  for (const item of (aniUpcoming?.items || []).slice(0, 6)) {
    addStaged(item, 'upcoming', false, false);
  }
  if (!tmdbOn) {
    for (const show of tvMazePool.slice(0, 20)) {
      addStaged(show, 'airing_now', show.genres.includes('Drama'), false);
    }
  }

  // Enrich TMDB movie candidates with verified belongs_to_collection + production_companies (cached 1h)
  const stagedList = Array.from(stagedMap.values());
  const movieLookupCandidates = tmdbOn
    ? stagedList
        .filter((s) => s.summary.source === 'tmdb' && s.summary.mediaType === 'movie' && s.checkCollection)
        .slice(0, 28)
    : [];

  const tmdbMetaMap = new Map<
    string,
    { tmdbCollectionId: number | null; tmdbCollectionName: string | null; productionCompanies: string[] }
  >();

  await runInChunks(movieLookupCandidates, 10, async (s) => {
    const details = await withTimeout(
      fetchTmdb<any>(`/movie/${encodeURIComponent(s.summary.externalId)}`, {}, 60 * 60 * 1000),
      2500,
      null
    );
    if (!details?.id) return;
    tmdbMetaMap.set(s.summary.titleKey, {
      tmdbCollectionId: details.belongs_to_collection?.id ?? null,
      tmdbCollectionName: details.belongs_to_collection?.name ?? null,
      productionCompanies: (details.production_companies || []).map((p: any) => p.name).filter(Boolean),
    });
  });

  // Also check studios for franchise-radar TV items so Marvel Studios / DC Studios / HBO series match accurately
  const tvLookupCandidates = tmdbOn
    ? stagedList
        .filter(
          (s) =>
            s.summary.source === 'tmdb' &&
            s.summary.mediaType === 'tv' &&
            !detectRelatedFranchise(s.summary)
        )
        .slice(0, 10)
    : [];

  await runInChunks(tvLookupCandidates, 10, async (s) => {
    const details = await withTimeout(
      fetchTmdb<any>(`/tv/${encodeURIComponent(s.summary.externalId)}`, {}, 60 * 60 * 1000),
      2000,
      null
    );
    if (!details?.id) return;
    tmdbMetaMap.set(s.summary.titleKey, {
      tmdbCollectionId: null,
      tmdbCollectionName: null,
      productionCompanies: (details.production_companies || []).map((p: any) => p.name).filter(Boolean),
    });
  });

  const items: NewReleaseItem[] = stagedList.map((s) => {
    const ctx = tmdbMetaMap.get(s.summary.titleKey) || {};
    const detectedFranchise = detectRelatedFranchise(s.summary, ctx);
    return {
      ...s.summary,
      category: s.category,
      releaseBucket: s.releaseBucket,
      detectedFranchise,
    };
  });

  // Sort: pending franchise additions first, then newest release dates & popularity
  items.sort((a, b) => {
    const aPending = a.detectedFranchise && !a.detectedFranchise.alreadyInFranchise ? 2 : a.detectedFranchise ? 1 : 0;
    const bPending = b.detectedFranchise && !b.detectedFranchise.alreadyInFranchise ? 2 : b.detectedFranchise ? 1 : 0;
    if (bPending !== aPending) return bPending - aPending;
    const aDate = a.releaseDate ? Date.parse(a.releaseDate) : 0;
    const bDate = b.releaseDate ? Date.parse(b.releaseDate) : 0;
    if (bDate !== aDate) return bDate - aDate;
    return (b.popularity || 0) - (a.popularity || 0);
  });

  const response: CatalogUpdatesResponse = {
    tmdbConfigured: tmdbOn,
    syncedAt: new Date().toISOString(),
    counts: {
      total: items.length,
      movies: items.filter((i) => i.category === 'movie').length,
      series: items.filter((i) => i.category === 'series').length,
      dramas: items.filter((i) => i.category === 'drama').length,
      anime: items.filter((i) => i.category === 'anime').length,
      franchiseRelated: items.filter((i) => Boolean(i.detectedFranchise)).length,
      pendingFranchiseAdditions: items.filter(
        (i) => Boolean(i.detectedFranchise && !i.detectedFranchise.alreadyInFranchise)
      ).length,
    },
    items,
  };

  return setCached(cacheKey, response, 15 * 60 * 1000);
}

