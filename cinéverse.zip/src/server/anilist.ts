import type {
  CastMember,
  CrewMember,
  EpisodeItem,
  MediaDetail,
  MediaSummary,
  MediaType,
  RelatedFranchiseLink,
  SeasonGroup,
  StreamingAvailability,
  StreamingProviderOption,
  TrailerInfo,
} from '../types/media.ts';

interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

const aniCache = new Map<string, CacheEntry<unknown>>();

function getCached<T>(key: string): T | null {
  const entry = aniCache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    aniCache.delete(key);
    return null;
  }
  return entry.value as T;
}

function setCached<T>(key: string, value: T, ttlMs: number): T {
  if (aniCache.size > 400) {
    const first = aniCache.keys().next().value;
    if (first) aniCache.delete(first);
  }
  aniCache.set(key, { value, expiresAt: Date.now() + ttlMs });
  return value;
}

async function queryAniList<T>(
  query: string,
  variables: Record<string, unknown>,
  cacheKey: string,
  ttlMs = 15 * 60 * 1000
): Promise<T | null> {
  const cached = getCached<T>(cacheKey);
  if (cached) return cached;

  try {
    const res = await fetch('https://graphql.anilist.co', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'User-Agent': 'CineverseApp/1.0',
      },
      body: JSON.stringify({ query, variables }),
      signal: AbortSignal.timeout(4500),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as { data?: T };
    if (!json?.data) return null;
    return setCached(cacheKey, json.data, ttlMs);
  } catch {
    return null;
  }
}

function stripHtml(raw: string | null | undefined): string {
  if (!raw) return '';
  return raw
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function formatFuzzyDate(d: { year?: number | null; month?: number | null; day?: number | null } | null): string | null {
  if (!d?.year) return null;
  const m = d.month ? String(d.month).padStart(2, '0') : '01';
  const day = d.day ? String(d.day).padStart(2, '0') : '01';
  return `${d.year}-${m}-${day}`;
}

function mapAniStatus(status: string | null | undefined): string | null {
  if (!status) return null;
  const map: Record<string, string> = {
    FINISHED: 'Finished Airing',
    RELEASING: 'Currently Airing',
    NOT_YET_RELEASED: 'Not yet aired',
    CANCELLED: 'Cancelled',
    HIATUS: 'On Hiatus',
  };
  return map[status] || status;
}

export function normalizeAniListMedia(item: any): MediaSummary {
  const externalId = item.idMal ? String(item.idMal) : `al_${item.id}`;
  const isMovie = item.format === 'MOVIE';
  const mediaType: MediaType = isMovie ? 'movie' : 'anime';
  const releaseDate = formatFuzzyDate(item.startDate);
  const releaseYear = item.seasonYear || item.startDate?.year || null;
  const score = typeof item.averageScore === 'number' ? Number((item.averageScore / 10).toFixed(1)) : null;

  return {
    titleKey: `jikan_${mediaType}_${externalId}`,
    source: 'jikan',
    mediaType,
    externalId,
    title: item.title?.english || item.title?.romaji || item.title?.native || 'Untitled Anime',
    originalTitle: item.title?.native || item.title?.romaji || '',
    synopsis: stripHtml(item.description),
    posterUrl: item.coverImage?.extraLarge || item.coverImage?.large || null,
    backdropUrl: item.bannerImage || item.coverImage?.extraLarge || null,
    releaseDate,
    releaseYear,
    country: 'Japan',
    countryCode: 'JP',
    language: 'Japanese',
    genres: Array.isArray(item.genres) && item.genres.length > 0 ? item.genres.slice(0, 6) : ['Animation'],
    rating: score,
    voteCount: typeof item.popularity === 'number' ? item.popularity : null,
    popularity: typeof item.popularity === 'number' ? item.popularity : null,
    status: mapAniStatus(item.status),
    runtimeMinutes: typeof item.duration === 'number' ? item.duration : null,
    totalSeasons: isMovie ? null : 1,
    totalEpisodes: typeof item.episodes === 'number' ? item.episodes : null,
    sourceAttribution: 'AniList / MyAnimeList',
    fetchedAt: new Date().toISOString(),
  };
}

const SUMMARY_FIELDS = `
  id
  idMal
  format
  status
  seasonYear
  episodes
  duration
  averageScore
  popularity
  genres
  description(asHtml: false)
  startDate { year month day }
  title { romaji english native }
  coverImage { extraLarge large }
  bannerImage
`;

export async function searchAniList(q: string, limit = 12): Promise<MediaSummary[]> {
  const query = `
    query ($search: String, $perPage: Int) {
      Page(page: 1, perPage: $perPage) {
        media(search: $search, type: ANIME, isAdult: false, sort: SEARCH_MATCH) {
          ${SUMMARY_FIELDS}
        }
      }
    }
  `;
  const data = await queryAniList<{ Page?: { media?: any[] } }>(
    query,
    { search: q, perPage: limit },
    `al:search:${q.toLowerCase()}:${limit}`,
    5 * 60 * 1000
  );
  return (data?.Page?.media || []).map(normalizeAniListMedia);
}

export async function discoverAniList(opts: {
  page?: number;
  limit?: number;
  isMovie?: boolean;
  genre?: string;
  year?: string;
  minRating?: number;
  status?: string;
  sortBy?: 'popularity' | 'rating' | 'release_date' | 'title';
}): Promise<{ items: MediaSummary[]; hasMore: boolean; total: number }> {
  const page = Math.max(1, opts.page || 1);
  const perPage = Math.min(25, opts.limit || 20);

  const sortMap: Record<string, string> = {
    popularity: 'POPULARITY_DESC',
    rating: 'SCORE_DESC',
    release_date: 'START_DATE_DESC',
    title: 'TITLE_ENGLISH',
  };
  const sort = [sortMap[opts.sortBy || 'popularity'] || 'POPULARITY_DESC'];

  const variables: Record<string, unknown> = {
    page,
    perPage,
    sort,
  };

  const extraFilters: string[] = [];
  if (opts.isMovie) {
    variables.format = 'MOVIE';
    extraFilters.push('$format: MediaFormat');
  }
  if (opts.genre) {
    const genreMap: Record<string, string> = {
      'Science Fiction': 'Sci-Fi',
    };
    variables.genre = genreMap[opts.genre] || opts.genre;
    extraFilters.push('$genre: String');
  }
  if (opts.year && /^\d{4}$/.test(opts.year)) {
    variables.seasonYear = Number(opts.year);
    extraFilters.push('$seasonYear: Int');
  }
  if (opts.minRating && opts.minRating > 0) {
    variables.minScore = Math.round(opts.minRating * 10);
    extraFilters.push('$minScore: Int');
  }
  if (opts.status) {
    const statusMap: Record<string, string> = {
      airing: 'RELEASING',
      completed: 'FINISHED',
      upcoming: 'NOT_YET_RELEASED',
    };
    if (statusMap[opts.status]) {
      variables.status = statusMap[opts.status];
      extraFilters.push('$status: MediaStatus');
    }
  }

  const varDecl = ['$page: Int', '$perPage: Int', '$sort: [MediaSort]', ...extraFilters].join(', ');
  const args = [
    'type: ANIME',
    'isAdult: false',
    'sort: $sort',
    opts.isMovie ? 'format: $format' : '',
    opts.genre ? 'genre: $genre' : '',
    variables.seasonYear ? 'seasonYear: $seasonYear' : '',
    variables.minScore ? 'averageScore_greater: $minScore' : '',
    variables.status ? 'status: $status' : '',
  ]
    .filter(Boolean)
    .join(', ');

  const query = `
    query (${varDecl}) {
      Page(page: $page, perPage: $perPage) {
        pageInfo { hasNextPage total }
        media(${args}) {
          ${SUMMARY_FIELDS}
        }
      }
    }
  `;

  const cacheKey = `al:discover:${JSON.stringify(variables)}`;
  const data = await queryAniList<{
    Page?: { pageInfo?: { hasNextPage?: boolean; total?: number }; media?: any[] };
  }>(query, variables, cacheKey, 15 * 60 * 1000);

  const items = (data?.Page?.media || []).map(normalizeAniListMedia);
  return {
    items,
    hasMore: Boolean(data?.Page?.pageInfo?.hasNextPage),
    total: data?.Page?.pageInfo?.total || items.length,
  };
}

export async function getAniListPostersByMalIds(malIds: number[]): Promise<Map<string, string | null>> {
  const result = new Map<string, string | null>();
  if (malIds.length === 0) return result;

  const query = `
    query ($ids: [Int]) {
      Page(page: 1, perPage: 50) {
        media(idMal_in: $ids, type: ANIME) {
          idMal
          coverImage { extraLarge large }
        }
      }
    }
  `;
  const sortedKey = [...malIds].sort((a, b) => a - b).join(',');
  const data = await queryAniList<{ Page?: { media?: any[] } }>(
    query,
    { ids: malIds },
    `al:posters:${sortedKey}`,
    60 * 60 * 1000
  );

  for (const m of data?.Page?.media || []) {
    if (m.idMal) {
      result.set(String(m.idMal), m.coverImage?.extraLarge || m.coverImage?.large || null);
    }
  }
  return result;
}

const REGION_NAMES: Record<string, string> = {
  IN: 'India',
  US: 'United States',
  GB: 'United Kingdom',
  KR: 'South Korea',
  JP: 'Japan',
  CA: 'Canada',
  AU: 'Australia',
  DE: 'Germany',
  FR: 'France',
  ES: 'Spain',
  IT: 'Italy',
  TR: 'Turkey',
  TH: 'Thailand',
  TW: 'Taiwan',
  PH: 'Philippines',
};

export async function getAniListDetail(externalId: string, region: string): Promise<MediaDetail | null> {
  const isAlId = externalId.startsWith('al_');
  const numericId = Number(isAlId ? externalId.slice(3) : externalId);
  if (!Number.isFinite(numericId) || numericId <= 0) return null;

  const lookupArg = isAlId ? 'id: $id' : 'idMal: $id';
  const query = `
    query ($id: Int) {
      Media(${lookupArg}, type: ANIME) {
        ${SUMMARY_FIELDS}
        season
        trailer { id site thumbnail }
        studios(isMain: false) {
          nodes { name isAnimationStudio }
        }
        characters(sort: [ROLE, RELEVANCE], perPage: 14) {
          edges {
            role
            node {
              id
              name { full }
              image { medium }
            }
            voiceActors(language: JAPANESE, sort: RELEVANCE) {
              id
              name { full }
              image { medium }
            }
          }
        }
        staff(sort: RELEVANCE, perPage: 12) {
          edges {
            role
            node {
              id
              name { full }
            }
          }
        }
        relations {
          edges {
            relationType(version: 2)
            node {
              id
              idMal
              type
              format
              seasonYear
              title { english romaji }
              coverImage { large }
            }
          }
        }
        recommendations(sort: RATING_DESC, perPage: 10) {
          nodes {
            mediaRecommendation {
              ${SUMMARY_FIELDS}
            }
          }
        }
        externalLinks {
          id
          site
          url
          type
          icon
        }
        streamingEpisodes {
          title
          thumbnail
          url
          site
        }
        nextAiringEpisode {
          episode
          airingAt
        }
        airingSchedule(perPage: 50) {
          nodes {
            episode
            airingAt
          }
        }
      }
    }
  `;

  const data = await queryAniList<{ Media?: any }>(
    query,
    { id: numericId },
    `al:detail:${externalId}`,
    15 * 60 * 1000
  );

  const item = data?.Media;
  if (!item) return null;

  const summary = normalizeAniListMedia(item);

  // Build verified episode list from streamingEpisodes + airingSchedule + confirmed episode count
  const streamingEps: any[] = Array.isArray(item.streamingEpisodes) ? item.streamingEpisodes : [];
  const scheduleByEp = new Map<number, number>();
  for (const node of item.airingSchedule?.nodes || []) {
    if (typeof node.episode === 'number' && typeof node.airingAt === 'number') {
      scheduleByEp.set(node.episode, node.airingAt * 1000);
    }
  }
  const nextEpNum = item.nextAiringEpisode?.episode || null;
  const confirmedTotal =
    typeof item.episodes === 'number' && item.episodes > 0
      ? item.episodes
      : nextEpNum
        ? nextEpNum
        : streamingEps.length;

  const streamingByEp = new Map<number, { title: string; thumbnail: string | null }>();
  for (const se of streamingEps) {
    const match = String(se.title || '').match(/Episode\s+(\d+)\s*[-:]?\s*(.*)/i);
    if (match) {
      const n = Number(match[1]);
      if (n > 0) {
        streamingByEp.set(n, {
          title: match[2]?.trim() || se.title,
          thumbnail: se.thumbnail || null,
        });
      }
    }
  }

  const nowMs = Date.now();
  const episodes: EpisodeItem[] = [];
  if (summary.mediaType !== 'movie' && confirmedTotal > 0) {
    const cap = Math.min(confirmedTotal, 500);
    for (let epNum = 1; epNum <= cap; epNum++) {
      const airMs = scheduleByEp.get(epNum);
      const airDate = airMs ? new Date(airMs).toISOString().slice(0, 10) : null;
      let isReleased = false;
      if (airMs) {
        isReleased = airMs <= nowMs;
      } else if (item.status === 'FINISHED') {
        isReleased = true;
      } else if (item.status === 'RELEASING' && nextEpNum) {
        isReleased = epNum < nextEpNum;
      } else if (streamingByEp.has(epNum)) {
        isReleased = true;
      }

      const se = streamingByEp.get(epNum);
      episodes.push({
        episodeKey: `${summary.titleKey}_s1_e${epNum}`,
        seasonNumber: 1,
        episodeNumber: epNum,
        isSpecial: false,
        name: se?.title || `Episode ${epNum}`,
        overview: null,
        airDate,
        isReleased,
        runtimeMinutes: summary.runtimeMinutes || 24,
        thumbnailUrl: se?.thumbnail || null,
        rating: null,
      });
    }
  }

  const seasons: SeasonGroup[] =
    episodes.length > 0
      ? [
          {
            seasonNumber: 1,
            name: 'Season 1',
            isSpecials: false,
            episodeCount: episodes.length,
            releasedEpisodeCount: episodes.filter((e) => e.isReleased).length,
            airDate: summary.releaseDate,
            posterUrl: summary.posterUrl,
            episodes,
          },
        ]
      : [];

  const cast: CastMember[] = (item.characters?.edges || []).map((edge: any) => {
    const va = edge.voiceActors?.[0];
    return {
      id: String(edge.node?.id || Math.random()),
      name: va?.name?.full || edge.node?.name?.full || 'Unknown',
      character: edge.node?.name?.full
        ? `${edge.node.name.full} (${edge.role === 'MAIN' ? 'Main' : 'Supporting'})`
        : 'Cast',
      profileUrl: va?.image?.medium || edge.node?.image?.medium || null,
    };
  });

  const crew: CrewMember[] = (item.staff?.edges || []).map((edge: any) => ({
    id: `${edge.node?.id || Math.random()}_${edge.role}`,
    name: edge.node?.name?.full || 'Unknown',
    role: edge.role || 'Staff',
    department: 'Production',
  }));

  const trailer: TrailerInfo | null =
    item.trailer?.site === 'youtube' && item.trailer?.id
      ? {
          name: 'Official Trailer',
          site: 'YouTube',
          url: `https://www.youtube.com/watch?v=${item.trailer.id}`,
          embedUrl: `https://www.youtube.com/embed/${item.trailer.id}`,
        }
      : null;

  const relatedFranchise: RelatedFranchiseLink[] = (item.relations?.edges || [])
    .filter((e: any) => e.node?.type === 'ANIME')
    .slice(0, 14)
    .map((e: any) => {
      const n = e.node;
      const extId = n.idMal ? String(n.idMal) : `al_${n.id}`;
      const mType: MediaType = n.format === 'MOVIE' ? 'movie' : 'anime';
      const relLabel = String(e.relationType || 'Related')
        .toLowerCase()
        .replace(/_/g, ' ')
        .replace(/\b\w/g, (c) => c.toUpperCase());
      return {
        relationType: relLabel,
        titleKey: `jikan_${mType}_${extId}`,
        source: 'jikan' as const,
        mediaType: mType,
        externalId: extId,
        title: n.title?.english || n.title?.romaji || 'Related Anime',
        releaseYear: n.seasonYear || null,
        posterUrl: n.coverImage?.large || null,
      };
    });

  const similarTitles: MediaSummary[] = (item.recommendations?.nodes || [])
    .map((n: any) => n.mediaRecommendation)
    .filter(Boolean)
    .map(normalizeAniListMedia);

  const streamingLinks: StreamingProviderOption[] = (item.externalLinks || [])
    .filter((l: any) => l?.type === 'STREAMING' && l?.site && l?.url)
    .map((l: any) => ({
      providerId: `al_stream_${l.id}`,
      providerName: l.site,
      logoUrl: l.icon || null,
      type: 'subscription' as const,
      link: l.url,
    }));

  const regionName = REGION_NAMES[region] || region;
  const availability: StreamingAvailability =
    streamingLinks.length > 0
      ? {
          region,
          regionName,
          source: 'AniList Official Streaming Links',
          updatedAt: new Date().toISOString(),
          available: true,
          link: streamingLinks[0].link,
          providers: streamingLinks,
          note: `Official streaming partners registered on AniList. Regional catalog rights in ${regionName} may vary by licensor.`,
        }
      : {
          region,
          regionName,
          source: 'AniList / MyAnimeList',
          updatedAt: new Date().toISOString(),
          available: false,
          link: null,
          providers: [],
          note: null,
        };

  const studios = (item.studios?.nodes || []).map((s: any) => s.name).filter(Boolean);
  const animStudios = (item.studios?.nodes || [])
    .filter((s: any) => s.isAnimationStudio)
    .map((s: any) => s.name);

  return {
    ...summary,
    tagline:
      item.season && item.seasonYear
        ? `${item.season[0]}${item.season.slice(1).toLowerCase()} ${item.seasonYear}`
        : null,
    productionCompanies: studios,
    networkOrStudio: (animStudios.length > 0 ? animStudios : studios).slice(0, 2).join(', ') || null,
    cast,
    crew,
    trailer,
    seasons,
    relatedFranchise,
    similarTitles,
    availability,
  };
}
