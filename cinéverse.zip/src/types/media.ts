export type MetadataSource = 'tmdb' | 'jikan' | 'tvmaze';
export type MediaType = 'movie' | 'tv' | 'anime';
export type WatchStatus = 'want_to_watch' | 'watching' | 'completed' | 'on_hold' | 'dropped';

export type FranchiseOrderKey = 'recommended' | 'release' | 'chronological' | 'complete';

export type FranchiseRelationship =
  | 'Core Entry'
  | 'Sequel'
  | 'Prequel'
  | 'Spin-off'
  | 'Crossover'
  | 'Shared Universe'
  | 'Special'
  | 'Alternate Timeline';

export interface MediaSummary {
  titleKey: string; // e.g., "jikan_anime_5114", "tvmaze_tv_82", "tmdb_movie_550"
  source: MetadataSource;
  mediaType: MediaType;
  externalId: string;
  title: string;
  originalTitle: string;
  synopsis: string;
  posterUrl: string | null;
  backdropUrl: string | null;
  releaseDate: string | null;
  releaseYear: number | null;
  country: string;
  countryCode: string;
  language: string;
  genres: string[];
  rating: number | null;
  voteCount: number | null;
  popularity: number | null;
  status: string | null;
  runtimeMinutes: number | null;
  totalSeasons: number | null;
  totalEpisodes: number | null;
  sourceAttribution: string;
  fetchedAt: string;
}

export interface CastMember {
  id: string;
  name: string;
  character: string;
  profileUrl: string | null;
}

export interface CrewMember {
  id: string;
  name: string;
  role: string;
  department: string;
}

export interface TrailerInfo {
  name: string;
  site: string;
  url: string;
  embedUrl: string | null;
}

export interface EpisodeItem {
  episodeKey: string; // deterministic: `${titleKey}_s${seasonNumber}_e${episodeNumber}`
  seasonNumber: number;
  episodeNumber: number;
  isSpecial: boolean;
  name: string;
  overview: string | null;
  airDate: string | null;
  isReleased: boolean;
  runtimeMinutes: number | null;
  thumbnailUrl: string | null;
  rating: number | null;
  isFiller?: boolean;
  isRecap?: boolean;
}

export interface SeasonGroup {
  seasonNumber: number;
  name: string;
  isSpecials: boolean;
  episodeCount: number;
  releasedEpisodeCount: number;
  airDate: string | null;
  posterUrl: string | null;
  episodes: EpisodeItem[];
}

export interface StreamingProviderOption {
  providerId: string;
  providerName: string;
  logoUrl: string | null;
  type: 'subscription' | 'free' | 'rent' | 'buy';
  link: string | null;
}

export interface StreamingAvailability {
  region: string;
  regionName: string;
  source: string;
  updatedAt: string;
  available: boolean;
  link: string | null;
  providers: StreamingProviderOption[];
  note: string | null;
}

export interface RelatedFranchiseLink {
  relationType: string; // e.g., "Prequel", "Sequel", "Spin-off", "Side story", "Collection"
  titleKey: string;
  source: MetadataSource;
  mediaType: MediaType;
  externalId: string;
  title: string;
  releaseYear: number | null;
  posterUrl: string | null;
}

export interface ParentFranchiseRef {
  id: string;
  name: string;
  originCountry: string;
  orderAttribution: string;
  entryCount: number;
  positionInRecommended: number | null;
}

export interface MediaDetail extends MediaSummary {
  tagline: string | null;
  productionCompanies: string[];
  networkOrStudio: string | null;
  cast: CastMember[];
  crew: CrewMember[];
  trailer: TrailerInfo | null;
  seasons: SeasonGroup[];
  relatedFranchise: RelatedFranchiseLink[];
  parentFranchises?: ParentFranchiseRef[];
  similarTitles: MediaSummary[];
  availability: StreamingAvailability;
}

export interface FranchiseEntry {
  position: number;
  titleKey: string;
  source: MetadataSource;
  mediaType: MediaType;
  externalId: string;
  title: string;
  releaseYear: number | null;
  entryType: string; // Movie, Series, Sequel, Prequel, Special, Spin-off
  relationships: string[]; // Multi-relationship support: Core Entry, Sequel, Prequel, Spin-off, Crossover, Shared Universe, Special
  description: string;
  relationNote: string;
  posterUrl: string | null;
  totalSeasons?: number | null;
  totalEpisodes?: number | null;
  runtimeMinutes?: number | null;
  streamingProviders?: StreamingProviderOption[];
  availabilityRegion?: string | null;
}

export interface FranchiseDetail {
  id: string;
  name: string;
  description: string;
  originCountry: string;
  mediaScope: string;
  posterUrl?: string | null;
  backdropUrl?: string | null;
  orderAttribution: 'Verified Official Order' | 'Community-Curated Order' | 'Admin Verified Order';
  sourceNote: string;
  disputedOrderNote?: string | null;
  orderNotes?: Partial<Record<FranchiseOrderKey, string>>;
  searchAliases: string[];
  relatedFranchiseIds?: string[];
  confirmedMovieCount: number;
  confirmedSeriesCount: number;
  spinoffCount: number;
  prequelSequelCount: number;
  isCustom?: boolean;
  isPublished?: boolean;
  orders: {
    recommended: FranchiseEntry[];
    release: FranchiseEntry[];
    chronological: FranchiseEntry[];
    complete: FranchiseEntry[];
  };
}

export interface UserProfile {
  uid: string;
  displayName: string;
  preferredRegion: string;
  preferredLanguage: string;
  favoriteGenres: string[];
  preferredCountries: string[];
  excludeCompletedRecs: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface UserTitleRecord {
  userId: string;
  titleKey: string;
  source: MetadataSource;
  mediaType: MediaType;
  externalId: string;
  title: string;
  originalTitle: string;
  posterUrl: string;
  releaseYear: number;
  country: string;
  language: string;
  genres: string[];
  runtimeMinutes: number;
  totalReleasedEpisodes: number;
  completedEpisodesCount: number;
  status: WatchStatus;
  isFavorite: boolean;
  personalRating: number;
  notes: string;
  startedAt: string;
  completedAt: string;
  lastWatchedEpisodeCode: string;
  lastWatchedEpisodeName: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface UserEpisodeRecord {
  userId: string;
  titleKey: string;
  episodeKey: string;
  seasonNumber: number;
  episodeNumber: number;
  isSpecial: boolean;
  episodeTitle: string;
  runtimeMinutes: number;
  watchedAt?: unknown;
  watchedMonth: string; // YYYY-MM
  watchedYear: number;
}

export interface UserCollectionRecord {
  id: string;
  userId: string;
  name: string;
  description: string;
  titleKeys: string[];
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface HomeFeedResponse {
  tmdbConfigured: boolean;
  featured: MediaSummary | null;
  trendingWorldwide: MediaSummary[];
  popularMovies: MediaSummary[];
  popularSeries: MediaSummary[];
  popularAnime: MediaSummary[];
  topRatedDramas: MediaSummary[];
  hiddenGems: MediaSummary[];
  recentlyReleased: MediaSummary[];
  upcomingReleases: MediaSummary[];
  fetchedAt: string;
}

export interface DiscoverResponse {
  tmdbConfigured: boolean;
  items: MediaSummary[];
  page: number;
  hasMore: boolean;
  totalResults: number;
  sourceNotice: string | null;
}

export interface FranchiseSearchMatch {
  id: string;
  name: string;
  description: string;
  originCountry: string;
  posterUrl: string | null;
  orderAttribution: string;
  entryCount: number;
  movieCount: number;
  seriesCount: number;
  matchReason: string;
  relatedGuides?: Array<{ id: string; name: string }>;
}

export interface SearchResponse {
  tmdbConfigured: boolean;
  query: string;
  results: MediaSummary[];
  peopleMatches: Array<{
    id: string;
    name: string;
    role: string;
    country: string | null;
    imageUrl: string | null;
    knownForTitleKey: string | null;
  }>;
  franchiseMatches: FranchiseSearchMatch[];
}

export type ReleaseCategory = 'movie' | 'series' | 'drama' | 'anime';
export type ReleaseBucket = 'new_release' | 'airing_now' | 'upcoming';

export interface DetectedFranchiseMatch {
  franchiseId: string;
  franchiseName: string;
  matchReason: string;
  confidence: 'high' | 'medium';
  suggestedRelationships: string[];
  suggestedOrderNote: string;
  alreadyInFranchise: boolean;
}

export interface NewReleaseItem extends MediaSummary {
  category: ReleaseCategory;
  releaseBucket: ReleaseBucket;
  detectedFranchise: DetectedFranchiseMatch | null;
}

export interface CatalogUpdatesResponse {
  tmdbConfigured: boolean;
  syncedAt: string;
  counts: {
    total: number;
    movies: number;
    series: number;
    dramas: number;
    anime: number;
    franchiseRelated: number;
    pendingFranchiseAdditions: number;
  };
  items: NewReleaseItem[];
}

