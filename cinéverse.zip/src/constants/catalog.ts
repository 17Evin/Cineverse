export const GENERATED_ASSETS = {
  heroBackdrop: '/src/assets/images/hero_cinema_atelier_1795076169952.jpg',
  posterFallback: '/src/assets/images/cinema_poster_fallback_1795076163796.jpg',
  franchiseBanner: '/src/assets/images/franchise_chronicle_banner_1795076210955.jpg',
} as const;

export interface CountryOption {
  code: string;
  name: string;
  language: string;
  languageCode: string;
  regionLabel: string;
}

export const GLOBAL_COUNTRIES: CountryOption[] = [
  { code: 'IN', name: 'India', language: 'Hindi', languageCode: 'hi', regionLabel: 'South Asia' },
  { code: 'KR', name: 'South Korea', language: 'Korean', languageCode: 'ko', regionLabel: 'East Asia' },
  { code: 'JP', name: 'Japan', language: 'Japanese', languageCode: 'ja', regionLabel: 'East Asia' },
  { code: 'CN', name: 'China', language: 'Chinese', languageCode: 'zh', regionLabel: 'East Asia' },
  { code: 'US', name: 'United States', language: 'English', languageCode: 'en', regionLabel: 'North America' },
  { code: 'GB', name: 'United Kingdom', language: 'English', languageCode: 'en', regionLabel: 'Europe' },
  { code: 'TH', name: 'Thailand', language: 'Thai', languageCode: 'th', regionLabel: 'Southeast Asia' },
  { code: 'TR', name: 'Turkey', language: 'Turkish', languageCode: 'tr', regionLabel: 'Eurasia' },
  { code: 'ES', name: 'Spain', language: 'Spanish', languageCode: 'es', regionLabel: 'Europe' },
  { code: 'FR', name: 'France', language: 'French', languageCode: 'fr', regionLabel: 'Europe' },
  { code: 'DE', name: 'Germany', language: 'German', languageCode: 'de', regionLabel: 'Europe' },
  { code: 'IT', name: 'Italy', language: 'Italian', languageCode: 'it', regionLabel: 'Europe' },
  { code: 'TW', name: 'Taiwan', language: 'Chinese', languageCode: 'zh', regionLabel: 'East Asia' },
  { code: 'PH', name: 'Philippines', language: 'Tagalog', languageCode: 'tl', regionLabel: 'Southeast Asia' },
  { code: 'CA', name: 'Canada', language: 'English', languageCode: 'en', regionLabel: 'North America' },
  { code: 'SE', name: 'Sweden', language: 'Swedish', languageCode: 'sv', regionLabel: 'Europe' },
  { code: 'MX', name: 'Mexico', language: 'Spanish', languageCode: 'es', regionLabel: 'Latin America' },
  { code: 'BR', name: 'Brazil', language: 'Portuguese', languageCode: 'pt', regionLabel: 'Latin America' },
];

export const GLOBAL_GENRES = [
  'Drama',
  'Romance',
  'Thriller',
  'Mystery',
  'Fantasy',
  'Science Fiction',
  'Horror',
  'Comedy',
  'Action',
  'Adventure',
  'Historical',
  'Crime',
  'Animation',
  'Supernatural',
  'Psychological',
  'Slice of Life',
  'Family',
  'Documentary',
] as const;

export const STREAMING_REGIONS = [
  { code: 'IN', name: 'India' },
  { code: 'US', name: 'United States' },
  { code: 'GB', name: 'United Kingdom' },
  { code: 'KR', name: 'South Korea' },
  { code: 'JP', name: 'Japan' },
  { code: 'CA', name: 'Canada' },
  { code: 'AU', name: 'Australia' },
  { code: 'DE', name: 'Germany' },
  { code: 'FR', name: 'France' },
  { code: 'ES', name: 'Spain' },
  { code: 'IT', name: 'Italy' },
  { code: 'TR', name: 'Turkey' },
  { code: 'TH', name: 'Thailand' },
  { code: 'TW', name: 'Taiwan' },
  { code: 'PH', name: 'Philippines' },
] as const;

export const CONFIGURABLE_PROVIDERS = [
  { id: '8', name: 'Netflix' },
  { id: '119', name: 'Amazon Prime Video' },
  { id: '122', name: 'JioHotstar' },
  { id: '283', name: 'Crunchyroll' },
  { id: '232', name: 'ZEE5' },
  { id: '237', name: 'Sony LIV' },
  { id: '350', name: 'Apple TV+' },
  { id: '337', name: 'Disney+' },
] as const;

export const LANGUAGES_LIST = [
  { code: 'en', name: 'English' },
  { code: 'hi', name: 'Hindi' },
  { code: 'ko', name: 'Korean' },
  { code: 'ja', name: 'Japanese' },
  { code: 'zh', name: 'Chinese' },
  { code: 'th', name: 'Thai' },
  { code: 'tr', name: 'Turkish' },
  { code: 'es', name: 'Spanish' },
  { code: 'fr', name: 'French' },
  { code: 'de', name: 'German' },
  { code: 'it', name: 'Italian' },
  { code: 'tl', name: 'Tagalog' },
  { code: 'ta', name: 'Tamil' },
  { code: 'te', name: 'Telugu' },
  { code: 'ml', name: 'Malayalam' },
] as const;

export const WATCH_STATUS_LABELS: Record<string, string> = {
  want_to_watch: 'Want to Watch',
  watching: 'Currently Watching',
  completed: 'Completed',
  on_hold: 'On Hold',
  dropped: 'Dropped',
};
