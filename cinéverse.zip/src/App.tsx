import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Layout } from './components/Layout';
import { UserDataProvider } from './context/UserDataContext';
import { HomePage } from './pages/HomePage';
import { DiscoverPage } from './pages/DiscoverPage';
import { CountriesPage } from './pages/CountriesPage';
import { FranchisesPage } from './pages/FranchisesPage';
import { FranchiseAdminPage } from './pages/FranchiseAdminPage';
import { TitleDetailPage } from './pages/TitleDetailPage';
import { WatchlistPage } from './pages/WatchlistPage';
import { ContinueWatchingPage } from './pages/ContinueWatchingPage';
import { CollectionsPage } from './pages/CollectionsPage';
import { StatisticsPage } from './pages/StatisticsPage';
import { SettingsPage } from './pages/SettingsPage';
import { SearchPage } from './pages/SearchPage';
import { UpdatesPage } from './pages/UpdatesPage';

export default function App() {
  return (
    <ErrorBoundary>
      <UserDataProvider>
        <BrowserRouter>
          <Layout>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/discover" element={<DiscoverPage />} />
              <Route
                path="/movies"
                element={
                  <DiscoverPage
                    lockedMediaType="movie"
                    heading="Movies"
                    subheading="Explore feature films worldwide with verified runtimes, cast, and regional streaming platforms."
                  />
                }
              />
              <Route
                path="/series"
                element={
                  <DiscoverPage
                    lockedMediaType="tv"
                    heading="Television Series & Dramas"
                    subheading="Track seasons and individual released episodes across Korean, Indian, Japanese, European, and global television."
                  />
                }
              />
              <Route
                path="/anime"
                element={
                  <DiscoverPage
                    lockedMediaType="anime"
                    heading="Anime"
                    subheading="Live Jikan / MyAnimeList anime catalog with episode guides, filler labels, studios, and franchise relations."
                  />
                }
              />
              <Route path="/countries" element={<CountriesPage />} />
              <Route path="/franchises" element={<FranchisesPage />} />
              <Route path="/franchises/admin" element={<FranchiseAdminPage />} />
              <Route path="/franchises/:id" element={<FranchisesPage />} />
              <Route path="/updates" element={<UpdatesPage />} />
              <Route path="/watchlist" element={<WatchlistPage />} />
              <Route path="/continue-watching" element={<ContinueWatchingPage />} />
              <Route path="/collections" element={<CollectionsPage />} />
              <Route path="/statistics" element={<StatisticsPage />} />
              <Route path="/settings" element={<SettingsPage />} />
              <Route path="/search" element={<SearchPage />} />
              <Route path="/title/:source/:mediaType/:externalId" element={<TitleDetailPage />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </Layout>
        </BrowserRouter>
      </UserDataProvider>
    </ErrorBoundary>
  );
}
