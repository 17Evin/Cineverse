import type {
  CatalogUpdatesResponse,
  DiscoverResponse,
  FranchiseDetail,
  HomeFeedResponse,
  MediaDetail,
  MediaSummary,
  MediaType,
  MetadataSource,
  SearchResponse,
} from '../types/media';

async function fetchJson<T>(url: string, signal?: AbortSignal): Promise<T> {
  const res = await fetch(url, { signal });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${res.status})`);
  }
  return (await res.json()) as T;
}

export function getHomeFeedApi(signal?: AbortSignal): Promise<HomeFeedResponse> {
  return fetchJson<HomeFeedResponse>('/api/home', signal);
}

export interface DiscoverQuery {
  mediaType?: 'all' | 'movie' | 'tv' | 'anime';
  country?: string;
  language?: string;
  genre?: string;
  year?: string;
  minRating?: number;
  status?: string;
  provider?: string;
  region?: string;
  sortBy?: 'popularity' | 'rating' | 'release_date' | 'title';
  page?: number;
}

export function discoverTitlesApi(query: DiscoverQuery, signal?: AbortSignal): Promise<DiscoverResponse> {
  const params = new URLSearchParams();
  if (query.mediaType) params.set('mediaType', query.mediaType);
  if (query.country) params.set('country', query.country);
  if (query.language) params.set('language', query.language);
  if (query.genre) params.set('genre', query.genre);
  if (query.year) params.set('year', query.year);
  if (query.minRating && query.minRating > 0) params.set('minRating', String(query.minRating));
  if (query.status) params.set('status', query.status);
  if (query.provider) params.set('provider', query.provider);
  if (query.region) params.set('region', query.region);
  if (query.sortBy) params.set('sortBy', query.sortBy);
  if (query.page) params.set('page', String(query.page));

  return fetchJson<DiscoverResponse>(`/api/discover?${params.toString()}`, signal);
}

export function searchAllApi(q: string, signal?: AbortSignal): Promise<SearchResponse> {
  return fetchJson<SearchResponse>(`/api/search?q=${encodeURIComponent(q)}`, signal);
}

export function getTitleDetailApi(
  source: MetadataSource,
  mediaType: MediaType,
  externalId: string,
  region = 'IN',
  signal?: AbortSignal
): Promise<MediaDetail> {
  return fetchJson<MediaDetail>(
    `/api/title/${encodeURIComponent(source)}/${encodeURIComponent(mediaType)}/${encodeURIComponent(externalId)}?region=${encodeURIComponent(region)}`,
    signal
  );
}

export async function getFranchisesApi(
  id?: string,
  region = 'IN',
  signal?: AbortSignal
): Promise<FranchiseDetail[]> {
  const params = new URLSearchParams();
  if (id) params.set('id', id);
  if (region) params.set('region', region);
  const qs = params.toString() ? `?${params.toString()}` : '';
  const data = await fetchJson<{ franchises: FranchiseDetail[] }>(`/api/franchises${qs}`, signal);
  return data.franchises;
}

export async function getFranchiseDetailApi(
  id: string,
  region = 'IN',
  signal?: AbortSignal
): Promise<FranchiseDetail | null> {
  const res = await fetch(
    `/api/franchises/${encodeURIComponent(id)}?region=${encodeURIComponent(region)}`,
    { signal }
  );
  if (res.status === 404) return null;
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${res.status})`);
  }
  const data = (await res.json()) as { franchise: FranchiseDetail };
  return data.franchise;
}

export function getRandomTitleApi(excludeKeys: string[] = []): Promise<MediaSummary> {
  const qs = excludeKeys.length > 0 ? `?exclude=${encodeURIComponent(excludeKeys.slice(0, 100).join(','))}` : '';
  return fetchJson<MediaSummary>(`/api/random${qs}`);
}

export function getTitleRoute(item: Pick<MediaSummary, 'source' | 'mediaType' | 'externalId'>): string {
  return `/title/${item.source}/${item.mediaType}/${item.externalId}`;
}

export function getFranchiseRoute(franchiseId: string): string {
  return `/franchises/${encodeURIComponent(franchiseId)}`;
}

export function getCatalogUpdatesApi(
  region = 'IN',
  signal?: AbortSignal
): Promise<CatalogUpdatesResponse> {
  return fetchJson<CatalogUpdatesResponse>(
    `/api/updates?region=${encodeURIComponent(region)}`,
    signal
  );
}

export async function refreshCatalogUpdatesApi(region = 'IN'): Promise<CatalogUpdatesResponse> {
  const res = await fetch(`/api/updates/refresh?region=${encodeURIComponent(region)}`, {
    method: 'POST',
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Refresh failed (${res.status})`);
  }
  return (await res.json()) as CatalogUpdatesResponse;
}

