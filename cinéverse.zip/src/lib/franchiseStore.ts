import type { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  where,
  writeBatch,
} from 'firebase/firestore';
import type {
  FranchiseDetail,
  FranchiseEntry,
  FranchiseOrderKey,
  FranchiseSearchMatch,
  MediaSummary,
  MediaType,
  MetadataSource,
  NewReleaseItem,
} from '../types/media';
import { getFranchiseDetailApi } from '../services/api';
import { db, handleFirestoreError, OperationType } from './firebase';

const BOOTSTRAPPED_ADMIN_EMAIL = 'nivetharamesh1710@gmail.com';
const ORDER_KEYS: FranchiseOrderKey[] = ['recommended', 'release', 'chronological', 'complete'];

export function isBootstrappedAdminClient(user: User | null | undefined): boolean {
  return Boolean(user && user.emailVerified && user.email === BOOTSTRAPPED_ADMIN_EMAIL);
}

export async function checkIsAdminUser(user: User | null | undefined): Promise<boolean> {
  if (!user || !user.emailVerified) return false;
  if (isBootstrappedAdminClient(user)) return true;
  try {
    const snap = await getDoc(doc(db, 'admins', user.uid));
    return snap.exists();
  } catch {
    return false;
  }
}

export function sanitizeSlug(raw: string): string {
  return raw
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .trim()
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .slice(0, 80);
}

function sanitizeId(raw: string): string {
  return raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 120);
}

function computeFranchiseStats(entries: FranchiseEntry[]) {
  const unique = new Map<string, FranchiseEntry>();
  for (const e of entries) {
    if (!unique.has(e.titleKey)) unique.set(e.titleKey, e);
  }
  const list = Array.from(unique.values());
  const confirmedMovieCount = list.filter((e) => e.mediaType === 'movie').length;
  const confirmedSeriesCount = list.filter((e) => e.mediaType !== 'movie').length;
  const spinoffCount = list.filter(
    (e) =>
      e.entryType.toLowerCase().includes('spin-off') ||
      (e.relationships || []).some((r) => r.toLowerCase().includes('spin-off'))
  ).length;
  const prequelSequelCount = list.filter((e) =>
    (e.relationships || []).some((r) => {
      const l = r.toLowerCase();
      return l.includes('prequel') || l.includes('sequel');
    })
  ).length;
  return { confirmedMovieCount, confirmedSeriesCount, spinoffCount, prequelSequelCount };
}

export async function fetchFirestoreFranchises(
  options: { includeDrafts?: boolean } = {}
): Promise<FranchiseDetail[]> {
  const includeDrafts = Boolean(options.includeDrafts);
  try {
    const frCol = collection(db, 'franchises');
    const frQuery = includeDrafts ? frCol : query(frCol, where('isPublished', '==', true));
    const frSnap = await getDocs(frQuery);

    if (frSnap.empty) return [];

    const results = await Promise.all(
      frSnap.docs.map(async (frDoc) => {
        const d = frDoc.data();
        const franchiseId = String(d.id || frDoc.id);

        const entriesCol = collection(db, 'franchises', franchiseId, 'entries');
        const ordersCol = collection(db, 'franchises', franchiseId, 'watchOrders');

        const [entriesSnap, ordersSnap] = await Promise.all([
          getDocs(includeDrafts ? entriesCol : query(entriesCol, where('isPublished', '==', true))),
          getDocs(includeDrafts ? ordersCol : query(ordersCol, where('isPublished', '==', true))),
        ]);

        const entryMap = new Map<string, Omit<FranchiseEntry, 'position'>>();
        entriesSnap.docs.forEach((edoc) => {
          const ed = edoc.data();
          const titleKey = String(ed.titleKey || edoc.id);
          entryMap.set(titleKey, {
            titleKey,
            source: (ed.source || 'tmdb') as MetadataSource,
            mediaType: (ed.mediaType || 'movie') as MediaType,
            externalId: String(ed.externalId || ''),
            title: String(ed.title || ''),
            releaseYear: typeof ed.releaseYear === 'number' && ed.releaseYear > 0 ? ed.releaseYear : null,
            entryType: String(ed.entryType || 'Movie'),
            relationships: Array.isArray(ed.relationships) ? ed.relationships.map(String) : ['Core Entry'],
            description: String(ed.description || ''),
            relationNote: String(ed.relationNote || ''),
            posterUrl: ed.posterUrl ? String(ed.posterUrl) : null,
            totalSeasons: typeof ed.totalSeasons === 'number' && ed.totalSeasons > 0 ? ed.totalSeasons : null,
            totalEpisodes: typeof ed.totalEpisodes === 'number' && ed.totalEpisodes > 0 ? ed.totalEpisodes : null,
          });
        });

        const ordersRaw: Record<FranchiseOrderKey, Array<{ position: number; titleKey: string; orderNote: string }>> = {
          recommended: [],
          release: [],
          chronological: [],
          complete: [],
        };

        ordersSnap.docs.forEach((odoc) => {
          const od = odoc.data();
          const orderType = od.orderType as FranchiseOrderKey;
          if (!ORDER_KEYS.includes(orderType)) return;
          ordersRaw[orderType].push({
            position: Number(od.position) || 1,
            titleKey: String(od.titleKey || ''),
            orderNote: String(od.orderNote || ''),
          });
        });

        const buildEntries = (key: FranchiseOrderKey): FranchiseEntry[] =>
          ordersRaw[key]
            .sort((a, b) => a.position - b.position)
            .map((item, idx) => {
              const base = entryMap.get(item.titleKey);
              if (!base) return null;
              return {
                ...base,
                position: idx + 1,
                relationNote: item.orderNote || base.relationNote,
              };
            })
            .filter((x): x is FranchiseEntry => Boolean(x));

        const recommended = buildEntries('recommended');
        const release = buildEntries('release');
        const chronological = buildEntries('chronological');
        let complete = buildEntries('complete');
        if (complete.length === 0) {
          // Synthesize complete from entryMap if not explicitly ordered
          complete = Array.from(entryMap.values()).map((e, idx) => ({ ...e, position: idx + 1 }));
        }

        const stats = computeFranchiseStats([...complete, ...recommended, ...release, ...chronological]);

        const detail: FranchiseDetail = {
          id: franchiseId,
          name: String(d.name || franchiseId),
          description: String(d.description || ''),
          originCountry: String(d.originCountry || 'International'),
          mediaScope: String(d.mediaScope || 'Verified Franchise Guide'),
          posterUrl: d.posterUrl ? String(d.posterUrl) : recommended[0]?.posterUrl || complete[0]?.posterUrl || null,
          backdropUrl: d.backdropUrl ? String(d.backdropUrl) : null,
          orderAttribution:
            d.orderAttribution === 'Verified Official Order' ||
            d.orderAttribution === 'Community-Curated Order' ||
            d.orderAttribution === 'Admin Verified Order'
              ? d.orderAttribution
              : 'Admin Verified Order',
          sourceNote: String(d.sourceNote || ''),
          disputedOrderNote: d.disputedOrderNote ? String(d.disputedOrderNote) : null,
          searchAliases: Array.isArray(d.searchAliases) ? d.searchAliases.map(String) : [],
          relatedFranchiseIds: Array.isArray(d.relatedFranchiseIds) ? d.relatedFranchiseIds.map(String) : [],
          confirmedMovieCount: stats.confirmedMovieCount,
          confirmedSeriesCount: stats.confirmedSeriesCount,
          spinoffCount: stats.spinoffCount,
          prequelSequelCount: stats.prequelSequelCount,
          isCustom: true,
          isPublished: Boolean(d.isPublished),
          orders: {
            recommended,
            release,
            chronological,
            complete,
          },
        };
        return detail;
      })
    );

    return results;
  } catch (err) {
    // Non-fatal fallback for public readers if Firestore has permission or network lag
    console.warn('Unable to read Firestore custom franchises:', err);
    return [];
  }
}

export async function saveFirestoreFranchise(
  user: User,
  franchise: FranchiseDetail
): Promise<FranchiseDetail> {
  const slug = sanitizeSlug(franchise.id);
  if (!slug || slug.length < 2) {
    throw new Error('Franchise ID slug must be at least 2 lowercase letters, digits, or hyphens.');
  }
  const name = franchise.name.trim().slice(0, 160);
  const description = franchise.description.trim().slice(0, 1200);
  if (!name || !description) {
    throw new Error('Franchise name and description are required.');
  }

  const isPublished = franchise.isPublished !== false;
  const frRef = doc(db, 'franchises', slug);

  // Collect all unique entries across all 4 orders
  const uniqueEntryMap = new Map<string, FranchiseEntry>();
  for (const key of ORDER_KEYS) {
    for (const entry of franchise.orders[key] || []) {
      if (!uniqueEntryMap.has(entry.titleKey)) {
        uniqueEntryMap.set(entry.titleKey, entry);
      }
    }
  }
  if (uniqueEntryMap.size === 0) {
    throw new Error('Add at least one verified movie or series entry before saving.');
  }

  const franchisePayloadBase = {
    name,
    description,
    originCountry: (franchise.originCountry || 'International').trim().slice(0, 64),
    mediaScope: (franchise.mediaScope || 'Verified Franchise Guide').trim().slice(0, 120),
    posterUrl: (franchise.posterUrl || '').slice(0, 500),
    backdropUrl: (franchise.backdropUrl || '').slice(0, 500),
    orderAttribution: franchise.orderAttribution || 'Admin Verified Order',
    sourceNote: (franchise.sourceNote || '').slice(0, 1000),
    disputedOrderNote: (franchise.disputedOrderNote || '').slice(0, 1000),
    searchAliases: (franchise.searchAliases || [])
      .map((s) => s.trim())
      .filter(Boolean)
      .slice(0, 30),
    relatedFranchiseIds: (franchise.relatedFranchiseIds || [])
      .map((s) => sanitizeSlug(s))
      .filter(Boolean)
      .slice(0, 12),
    isPublished,
    verifiedBy: user.uid,
  };

  try {
    const existingFrSnap = await getDoc(frRef);
    const existingEntriesSnap = existingFrSnap.exists()
      ? await getDocs(collection(db, 'franchises', slug, 'entries'))
      : null;
    const existingOrdersSnap = existingFrSnap.exists()
      ? await getDocs(collection(db, 'franchises', slug, 'watchOrders'))
      : null;

    const existingEntryIds = new Set(existingEntriesSnap ? existingEntriesSnap.docs.map((d) => d.id) : []);
    const existingOrderIds = new Set(existingOrdersSnap ? existingOrdersSnap.docs.map((d) => d.id) : []);

    const batch = writeBatch(db);

    if (existingFrSnap.exists()) {
      batch.update(frRef, {
        ...franchisePayloadBase,
        updatedAt: serverTimestamp(),
      });
    } else {
      batch.set(frRef, {
        id: slug,
        ...franchisePayloadBase,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }

    // Sync entries subcollection
    const nextEntryIds = new Set<string>();
    for (const entry of uniqueEntryMap.values()) {
      const entryId = sanitizeId(entry.titleKey);
      nextEntryIds.add(entryId);
      const entryRef = doc(db, 'franchises', slug, 'entries', entryId);

      const entryFields = {
        titleKey: sanitizeId(entry.titleKey).slice(0, 100),
        source: entry.source,
        mediaType: entry.mediaType,
        externalId: String(entry.externalId).slice(0, 64),
        title: entry.title.trim().slice(0, 200),
        releaseYear: typeof entry.releaseYear === 'number' && entry.releaseYear >= 0 ? entry.releaseYear : 0,
        entryType: (entry.entryType || 'Movie').trim().slice(0, 40),
        relationships: (entry.relationships && entry.relationships.length > 0 ? entry.relationships : ['Core Entry'])
          .map((r) => r.trim())
          .filter(Boolean)
          .slice(0, 8),
        description: (entry.description || '').slice(0, 600),
        relationNote: (entry.relationNote || '').slice(0, 400),
        posterUrl: (entry.posterUrl || '').slice(0, 500),
        totalSeasons: typeof entry.totalSeasons === 'number' && entry.totalSeasons >= 0 ? entry.totalSeasons : 0,
        totalEpisodes: typeof entry.totalEpisodes === 'number' && entry.totalEpisodes >= 0 ? entry.totalEpisodes : 0,
        isPublished,
      };

      if (existingEntryIds.has(entryId)) {
        batch.update(entryRef, {
          ...entryFields,
          updatedAt: serverTimestamp(),
        });
      } else {
        batch.set(entryRef, {
          franchiseId: slug,
          entryId,
          ...entryFields,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    }

    for (const oldId of existingEntryIds) {
      if (!nextEntryIds.has(oldId)) {
        batch.delete(doc(db, 'franchises', slug, 'entries', oldId));
      }
    }

    // Sync watchOrders subcollection
    const nextOrderIds = new Set<string>();
    for (const orderType of ORDER_KEYS) {
      const list = franchise.orders[orderType] || [];
      list.forEach((entry, idx) => {
        const position = idx + 1;
        const orderEntryId = sanitizeId(`${orderType}_${String(position).padStart(3, '0')}_${entry.titleKey}`);
        nextOrderIds.add(orderEntryId);
        const orderRef = doc(db, 'franchises', slug, 'watchOrders', orderEntryId);

        const orderFields = {
          orderType,
          position,
          titleKey: sanitizeId(entry.titleKey).slice(0, 100),
          orderNote: (entry.relationNote || '').slice(0, 400),
          isPublished,
        };

        if (existingOrderIds.has(orderEntryId)) {
          batch.update(orderRef, {
            ...orderFields,
            updatedAt: serverTimestamp(),
          });
        } else {
          batch.set(orderRef, {
            franchiseId: slug,
            orderEntryId,
            ...orderFields,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
      });
    }

    for (const oldOrderId of existingOrderIds) {
      if (!nextOrderIds.has(oldOrderId)) {
        batch.delete(doc(db, 'franchises', slug, 'watchOrders', oldOrderId));
      }
    }

    await batch.commit();

    const stats = computeFranchiseStats(Array.from(uniqueEntryMap.values()));
    return {
      ...franchise,
      id: slug,
      isCustom: true,
      isPublished,
      ...stats,
    };
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `franchises/${slug}`);
  }
}

export async function deleteFirestoreFranchise(franchiseId: string): Promise<void> {
  const slug = sanitizeSlug(franchiseId);
  try {
    const [entriesSnap, ordersSnap] = await Promise.all([
      getDocs(collection(db, 'franchises', slug, 'entries')),
      getDocs(collection(db, 'franchises', slug, 'watchOrders')),
    ]);

    const batch = writeBatch(db);
    entriesSnap.docs.forEach((d) => batch.delete(d.ref));
    ordersSnap.docs.forEach((d) => batch.delete(d.ref));
    batch.delete(doc(db, 'franchises', slug));
    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, `franchises/${slug}`);
  }
}

export function mergeFranchiseLists(
  apiFranchises: FranchiseDetail[],
  firestoreFranchises: FranchiseDetail[]
): FranchiseDetail[] {
  const map = new Map<string, FranchiseDetail>();
  for (const f of apiFranchises) map.set(f.id, f);
  for (const f of firestoreFranchises) {
    const existing = map.get(f.id);
    map.set(f.id, {
      ...f,
      posterUrl: f.posterUrl || existing?.posterUrl || null,
      backdropUrl: f.backdropUrl || existing?.backdropUrl || null,
    });
  }
  return Array.from(map.values());
}

export function matchCustomFranchisesClient(
  rawQuery: string,
  customFranchises: FranchiseDetail[]
): FranchiseSearchMatch[] {
  const q = rawQuery
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  if (q.length < 2) return [];

  const matches: FranchiseSearchMatch[] = [];
  for (const fr of customFranchises) {
    const normName = fr.name.toLowerCase();
    const aliasHit = (fr.searchAliases || []).some((a) => a.toLowerCase().includes(q) || q.includes(a.toLowerCase()));
    const entryHit = fr.orders.complete.find((e) => e.title.toLowerCase().includes(q));
    if (normName.includes(q) || aliasHit || entryHit) {
      matches.push({
        id: fr.id,
        name: fr.name,
        description: fr.description,
        originCountry: fr.originCountry,
        posterUrl: fr.posterUrl || fr.orders.recommended[0]?.posterUrl || null,
        orderAttribution: fr.orderAttribution,
        entryCount: fr.orders.complete.length,
        movieCount: fr.confirmedMovieCount,
        seriesCount: fr.confirmedSeriesCount,
        matchReason: normName.includes(q)
          ? 'Admin Verified Guide'
          : entryHit
            ? `Includes “${entryHit.title}”`
            : 'Verified Universe Match',
      });
    }
  }
  return matches;
}

function buildFranchiseEntryFromMedia(
  item: MediaSummary,
  position: number,
  relationships: string[],
  relationNote: string
): FranchiseEntry {
  const entryType =
    item.mediaType === 'movie'
      ? 'Movie'
      : item.mediaType === 'anime'
        ? 'Anime Series'
        : 'Series';

  return {
    position,
    titleKey: item.titleKey,
    source: item.source,
    mediaType: item.mediaType,
    externalId: item.externalId,
    title: item.title,
    releaseYear: item.releaseYear,
    entryType,
    relationships: relationships.length > 0 ? relationships.slice(0, 6) : ['Shared Universe'],
    description: (item.synopsis || '').slice(0, 500),
    relationNote: relationNote.slice(0, 380),
    posterUrl: item.posterUrl,
    totalSeasons: item.totalSeasons ?? null,
    totalEpisodes: item.totalEpisodes ?? null,
  };
}

function insertEntryIntoOrders(
  franchise: FranchiseDetail,
  item: MediaSummary,
  relationships: string[],
  relationNote: string
): FranchiseDetail {
  const alreadyPresent = franchise.orders.complete.some((e) => e.titleKey === item.titleKey);
  if (alreadyPresent) return franchise;

  const appendUnique = (list: FranchiseEntry[], sortByRelease = false): FranchiseEntry[] => {
    if (list.some((e) => e.titleKey === item.titleKey)) return list;
    const nextEntry = buildFranchiseEntryFromMedia(item, list.length + 1, relationships, relationNote);
    const merged = [...list, nextEntry];
    if (sortByRelease) {
      merged.sort((a, b) => (a.releaseYear || 9999) - (b.releaseYear || 9999));
    }
    return merged.map((e, i) => ({ ...e, position: i + 1 }));
  };

  const nextOrders = {
    recommended: appendUnique(franchise.orders.recommended, false),
    release: appendUnique(franchise.orders.release, true),
    chronological: appendUnique(franchise.orders.chronological, false),
    complete: appendUnique(franchise.orders.complete, false),
  };

  const stats = computeFranchiseStats(nextOrders.complete);
  return {
    ...franchise,
    ...stats,
    orderAttribution:
      franchise.orderAttribution === 'Verified Official Order'
        ? 'Verified Official Order'
        : 'Admin Verified Order',
    orders: nextOrders,
  };
}

/**
 * Loads the latest copy of a franchise (Firestore override if present, else live built-in catalog),
 * appends a newly released movie/series/drama cleanly without duplicates, and saves to Firestore.
 */
export async function appendReleaseToFranchise(
  user: User,
  franchiseId: string,
  item: MediaSummary | NewReleaseItem,
  options: {
    region?: string;
    relationships?: string[];
    relationNote?: string;
    existingCustomFranchises?: FranchiseDetail[];
  } = {}
): Promise<{ franchise: FranchiseDetail; added: boolean }> {
  const slug = sanitizeSlug(franchiseId);
  const region = options.region || 'IN';

  const customList =
    options.existingCustomFranchises || (await fetchFirestoreFranchises({ includeDrafts: true }));
  let baseFranchise = customList.find((f) => f.id === slug) || null;

  if (!baseFranchise) {
    baseFranchise = await getFranchiseDetailApi(slug, region);
  }
  if (!baseFranchise) {
    throw new Error(`Franchise "${franchiseId}" was not found.`);
  }

  if (baseFranchise.orders.complete.some((e) => e.titleKey === item.titleKey)) {
    return { franchise: baseFranchise, added: false };
  }

  const detected = 'detectedFranchise' in item ? item.detectedFranchise : null;
  const relationships =
    options.relationships ||
    detected?.suggestedRelationships ||
    ['Shared Universe', item.mediaType === 'movie' ? 'Sequel' : 'Spin-off'];
  const relationNote =
    options.relationNote ||
    detected?.suggestedOrderNote ||
    `Added via Live Catalog Updates (${item.releaseYear || 'Upcoming'}).`;

  const updated = insertEntryIntoOrders(baseFranchise, item, relationships, relationNote);
  const saved = await saveFirestoreFranchise(user, updated);
  return { franchise: saved, added: true };
}

/**
 * Batch-syncs all newly detected franchise-related releases into their respective Firestore franchises,
 * issuing a single batched Firestore save per affected franchise.
 */
export async function batchSyncReleasesToFranchises(
  user: User,
  releases: NewReleaseItem[],
  region = 'IN'
): Promise<{ syncedCount: number; updatedFranchises: FranchiseDetail[] }> {
  const pendingByFranchise = new Map<string, NewReleaseItem[]>();
  for (const item of releases) {
    if (!item.detectedFranchise) continue;
    const fid = item.detectedFranchise.franchiseId;
    const arr = pendingByFranchise.get(fid) || [];
    arr.push(item);
    pendingByFranchise.set(fid, arr);
  }

  if (pendingByFranchise.size === 0) {
    return { syncedCount: 0, updatedFranchises: [] };
  }

  const existingCustom = await fetchFirestoreFranchises({ includeDrafts: true });
  let syncedCount = 0;
  const updatedFranchises: FranchiseDetail[] = [];

  for (const [franchiseId, group] of pendingByFranchise.entries()) {
    let base =
      existingCustom.find((f) => f.id === franchiseId) ||
      (await getFranchiseDetailApi(franchiseId, region));
    if (!base) continue;

    let current = base;
    let addedHere = 0;
    for (const item of group) {
      if (current.orders.complete.some((e) => e.titleKey === item.titleKey)) continue;
      current = insertEntryIntoOrders(
        current,
        item,
        item.detectedFranchise?.suggestedRelationships || ['Shared Universe'],
        item.detectedFranchise?.suggestedOrderNote || `Added via Live Catalog Sync.`
      );
      addedHere += 1;
    }

    if (addedHere > 0) {
      const saved = await saveFirestoreFranchise(user, current);
      updatedFranchises.push(saved);
      syncedCount += addedHere;
    }
  }

  return { syncedCount, updatedFranchises };
}

